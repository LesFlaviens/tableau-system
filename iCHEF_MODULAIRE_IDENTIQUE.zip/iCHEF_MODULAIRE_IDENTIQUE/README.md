# iCHEF — version modulaire identique

Cette version a été générée à partir du fichier iCHEF complet fourni dans la conversation.

## Objectif

- Garder le même HTML, le même ordre d'exécution et les mêmes fonctions.
- Sortir les blocs CSS et JavaScript du fichier principal pour rendre le projet plus facile à maintenir.
- Aucun renommage de fonction ni réécriture métier n'a été effectué.

## Structure

- `index.html` : structure HTML principale.
- `css/` : 92 blocs CSS extraits, dans leur ordre d'origine.
- `js/` : 80 blocs JavaScript internes extraits, dans leur ordre d'origine.
- Le script Socket.IO externe reste chargé depuis son URL d'origine.

## Fichiers déjà attendus par iCHEF mais non contenus dans le HTML fourni

Le code fourni référence aussi :

- `manifest.json`
- `/sw.js`
- `icon-192.png`
- `anti-rush.html`

Ces fichiers doivent rester dans votre dépôt GitHub aux emplacements habituels. Ils n'ont pas été inventés ni remplacés ici.

## Déploiement GitHub

Copiez `index.html`, le dossier `css/` et le dossier `js/` dans le même répertoire de votre projet. Gardez les autres fichiers iCHEF existants (`anti-rush.html`, manifest, service worker, icônes, server.js, etc.).

## Sécurité

La protection d'hôte de la version production est conservée telle quelle. Elle autorise `os.ichef.ch`, `localhost` et `127.0.0.1`.

## Vérification

SHA-256 du HTML source nettoyé des balises Markdown :
`70d9dc610603834364498c633d1be67890e74e6471915b0a0e21da51f1adb5e5`
