# CHECKLIST DEPLOIEMENT

1. Sauvegarder le dépôt actuel.
2. Copier `index.html`.
3. Copier les dossiers `css/` et `js/`.
4. Ne pas supprimer `anti-rush.html`, `manifest.json`, `/sw.js`, les icônes, ni le serveur existant.
5. Tester d'abord sur un environnement de test / branche Git.
6. Tester : PIN, Architecture, Tables/Zones, Commande, Qui mange quoi, Anti-Rush, réservations, ticket, tactile/souris.
7. Puis déployer sur `os.ichef.ch`.
