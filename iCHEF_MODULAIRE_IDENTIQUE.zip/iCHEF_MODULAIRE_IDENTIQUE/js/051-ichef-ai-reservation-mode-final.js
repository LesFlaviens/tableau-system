(function(){
"use strict";

const STORAGE_KEY='ichef_reservation_ai_auto';
let autoBusy=false;

function aiAutoEnabled(){
    return localStorage.getItem(STORAGE_KEY)==='1';
}

function updateToggle(){
    const btn=document.getElementById('ichef-ai-auto-toggle');
    const desc=document.getElementById('ichef-ai-auto-desc');
    if(!btn)return;

    const on=aiAutoEnabled();
    btn.textContent=on?'ON':'OFF';
    btn.style.borderColor=on?'#a855f7':'#64748b';
    btn.style.background=on?'rgba(168,85,247,.16)':'#111';
    btn.style.color=on?'#e9d5ff':'#94a3b8';

    if(desc){
        desc.textContent=on
            ? "ON — l'IA peut attribuer automatiquement les tables disponibles."
            : "OFF — l'IA conseille, le manager valide.";
    }
}

async function findSuggestions(){
    const today=new Date().toISOString().split('T')[0];
    const pending=(Array.isArray(reservationsData)?reservationsData:[])
        .filter(r=>{
            const table=String(r?.assignedTable||r?.tableId||r?.table||'').trim();
            return r && r.date===today &&
                String(r.status||'confirmed').toLowerCase()==='confirmed' &&
                !table;
        });

    if(!pending.length)return [];

    const state=await API.getState();
    const orders=state?.activeOrders||{};
    const suggestions=[];
    const held=new Set();

    for(const resa of pending){
        const pax=parseInt(resa.couverts||resa.pax||resa.personnes)||1;

        const candidates=(Array.isArray(tables)?tables:[])
            .filter(t=>{
                if(!t||t.isExtra||held.has(t.label))return false;

                const o=orders[t.label];
                const occupied=!!(
                    o && Array.isArray(o.items) && o.items.some(i=>{
                        const qty=Number(i?.qty??i?.quantity??1);
                        const name=String(i?.n??i?.name??i?.productName??'').trim();
                        return name && qty>0;
                    })
                );
                if(occupied)return false;

                const alreadyReserved=(Array.isArray(reservationsData)?reservationsData:[])
                    .some(other=>{
                        if(!other||other===resa)return false;
                        const status=String(other.status||other.reservationStatus||'').toLowerCase();
                        if(['rejected','cancelled','canceled','annule','annulee','completed','done','noshow','no show'].includes(status))return false;
                        const table=String(other.assignedTable||other.tableId||other.table||'').trim();
                        return other.date===today && table===String(t.label);
                    });

                return !alreadyReserved && (parseInt(t.pax)||0)>=pax;
            })
            .sort((a,b)=>{
                const wasteA=(parseInt(a.pax)||0)-pax;
                const wasteB=(parseInt(b.pax)||0)-pax;
                if(wasteA!==wasteB)return wasteA-wasteB;
                const currentA=a.room===currentRoom?0:1;
                const currentB=b.room===currentRoom?0:1;
                return currentA-currentB;
            });

        if(candidates.length){
            const best=candidates[0];
            held.add(best.label);
            suggestions.push({reservation:resa,table:best,pax});
        }
    }

    return suggestions;
}

async function applySuggestions(suggestions,silent=false){
    let count=0;

    for(const s of suggestions){
        const r=s.reservation;
        const label=s.table.label;
        const rid=String(
            r.id||r.reservationId||r.bookingId||
            `RESA_${Date.now()}_${Math.random().toString(36).slice(2,7)}`
        );

        r.id=r.id||rid;
        r.reservationId=rid;
        r.bookingId=r.bookingId||rid;
        r.assignedTable=label;
        r.tableId=label;
        r.table=label;
        r.status=r.status||'confirmed';
        r.assignmentMode='AI';
        r.assignedAt=new Date().toISOString();
        count++;
    }

    if(count){
        await API.update('RESERVATIONS_MASTER',reservationsData,false,{
            reason:'Placement réservation IA',
            operationType:'RESERVATION_ASSIGNMENT'
        });

        if(typeof renderFloor==='function')renderFloor();
        if(typeof renderPlanning==='function'){
            const modal=document.getElementById('planning-modal');
            if(modal?.classList.contains('open'))renderPlanning('today');
        }
        if(typeof window.ichefRefreshReservationTableColors==='function'){
            window.ichefRefreshReservationTableColors();
        }
        if(typeof updateReservationQuickBadge==='function'){
            updateReservationQuickBadge();
        }

        if(!silent)alert(`✅ ${count} réservation(s) placée(s) par l'IA.`);
    }

    return count;
}

async function runAutoIfNeeded(){
    if(!aiAutoEnabled()||autoBusy)return;
    if(!currentUser||currentUser.role!=='Manager')return;

    autoBusy=true;
    try{
        const suggestions=await findSuggestions();
        if(suggestions.length){
            await applySuggestions(suggestions,true);
        }
    }catch(err){
        console.warn('[iCHEF] Placement IA automatique',err);
    }finally{
        autoBusy=false;
    }
}

window.smartPlacementAssistant=async function(){
    if(!currentUser||currentUser.role!=='Manager'){
        return alert('⛔ Accès Manager requis pour le placement IA.');
    }

    const suggestions=await findSuggestions();

    if(!suggestions.length){
        return alert("✅ Aucune réservation en attente de placement.");
    }

    if(aiAutoEnabled()){
        await applySuggestions(suggestions,false);
        return;
    }

    const preview=suggestions.map(s=>{
        const r=s.reservation;
        const phone=r.phone?` · ${r.phone}`:'';
        return `${r.time||'??:??'} — ${r.name||'Client'}${phone}\n`
             + `${s.pax} pers. → TABLE ${s.table.label} (${s.table.pax} places)`;
    }).join('\n\n');

    if(confirm(
        `🧠 CONSEIL IA — LE MANAGER GARDE LA MAIN\n\n${preview}\n\n`
        + `Valider ces propositions ?`
    )){
        await applySuggestions(suggestions,false);
    }
};

window.ichefSuggestOneReservation=async function(reservationId){
    if(!currentUser||currentUser.role!=='Manager'){
        return alert('⛔ Accès Manager requis.');
    }

    const target=(Array.isArray(reservationsData)?reservationsData:[])
        .find(r=>String(r.id||r.reservationId||r.bookingId)===String(reservationId));

    if(!target)return alert('Réservation introuvable.');

    const previous=reservationsData;
    const today=new Date().toISOString().split('T')[0];

    // Suggestion ciblée, sans modifier le reste.
    const state=await API.getState();
    const orders=state?.activeOrders||{};
    const pax=parseInt(target.couverts||target.pax||target.personnes)||1;

    const candidates=(Array.isArray(tables)?tables:[])
        .filter(t=>{
            if(!t||t.isExtra)return false;

            const o=orders[t.label];
            const occupied=!!(o&&Array.isArray(o.items)&&o.items.length>0);
            if(occupied)return false;

            const conflict=(Array.isArray(reservationsData)?reservationsData:[])
                .some(other=>{
                    if(!other||other===target)return false;
                    const table=String(other.assignedTable||other.tableId||other.table||'').trim();
                    return other.date===target.date && table===String(t.label);
                });

            return !conflict&&(parseInt(t.pax)||0)>=pax;
        })
        .sort((a,b)=>(parseInt(a.pax)||0)-(parseInt(b.pax)||0));

    if(!candidates.length)return alert('⚠️ Aucune table compatible disponible.');

    const best=candidates[0];

    if(aiAutoEnabled()){
        await applySuggestions([{reservation:target,table:best,pax}],false);
        return;
    }

    if(confirm(
        `🧠 CONSEIL IA\n\n`
        + `${target.name||'Client'} · ${pax} personne(s) · ${target.time||''}\n`
        + `→ Table conseillée : ${best.label} (${best.pax} places)\n\n`
        + `Valider cette table ?`
    )){
        await applySuggestions([{reservation:target,table:best,pax}],false);
    }
};

document.addEventListener('click',e=>{
    if(e.target?.id==='ichef-ai-auto-toggle'){
        const next=!aiAutoEnabled();
        localStorage.setItem(STORAGE_KEY,next?'1':'0');
        updateToggle();
        if(next)setTimeout(runAutoIfNeeded,100);
    }
},true);

function boot(){
    updateToggle();
    setInterval(()=>{
        updateToggle();
        if(aiAutoEnabled()){
            const planning=document.getElementById('planning-modal');
            if(planning?.classList.contains('open'))runAutoIfNeeded();
        }
    },4000);
}

if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',boot,{once:true});
}else{
    boot();
}
})();
