(function(){
'use strict';
if(window.__ICHEF_CONFIG_TABLE_CENTERED__) return;
window.__ICHEF_CONFIG_TABLE_CENTERED__=true;

function arrange(){
    const modal=document.getElementById('table-config-modal');
    if(!modal) return;

    let shell=modal.querySelector(':scope > .ichef-table-config-shell');
    if(!shell){
        shell=document.createElement('div');
        shell.className='ichef-table-config-shell';
        const children=[...modal.children];
        children.forEach(node=>shell.appendChild(node));
        modal.appendChild(shell);
    }

    const direct=[...shell.children];
    const title=direct.find(el=>el.tagName==='H2');
    if(title) title.classList.add('ichef-table-config-title');

    const main=direct.find(el=>el.tagName==='DIV' && !el.classList.contains('ichef-table-config-actions'));
    if(main) main.classList.add('ichef-table-config-main');

    const save=direct.find(el=>el.tagName==='BUTTON' && /SAUVEGARDER LA TABLE/i.test(el.textContent||''));
    if(save) save.classList.add('ichef-table-config-save');

    const actions=direct.find(el=>el.tagName==='DIV' && [...el.querySelectorAll(':scope > button')].some(b=>/SUPPRIMER|FERMER/i.test(b.textContent||'')));
    if(actions) actions.classList.add('ichef-table-config-actions');
}

function centerOnOpen(){
    arrange();
    const modal=document.getElementById('table-config-modal');
    const shell=modal?.querySelector(':scope > .ichef-table-config-shell');
    if(shell) shell.scrollTop=0;
}

arrange();
const oldOpen=window.openTableConfigModal;
if(typeof oldOpen==='function'){
    window.openTableConfigModal=function(){
        const r=oldOpen.apply(this,arguments);
        requestAnimationFrame(()=>requestAnimationFrame(centerOnOpen));
        return r;
    };
}

const modal=document.getElementById('table-config-modal');
if(modal){
    let raf=0;
    new MutationObserver(()=>{
        if(raf) return;
        raf=requestAnimationFrame(()=>{raf=0;arrange();});
    }).observe(modal,{childList:true});
}
})();
