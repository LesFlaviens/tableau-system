(function(){
    function shapeFromButton(btn){
        const txt = btn?.getAttribute('onclick') || '';
        const m = txt.match(/setShape\('([^']+)'\)/);
        return m ? m[1] : null;
    }

    document.addEventListener('pointerup', function(e){
        const btn = e.target && e.target.closest ? e.target.closest('#table-config-modal .shape-btn') : null;
        if(!btn) return;
        const shape = shapeFromButton(btn);
        if(!shape) return;
        e.preventDefault();
        e.stopPropagation();
        window.setShape ? window.setShape(shape) : setShape(shape);
    }, true);

    document.addEventListener('touchend', function(e){
        const btn = e.target && e.target.closest ? e.target.closest('#table-config-modal .shape-btn') : null;
        if(!btn) return;
        const shape = shapeFromButton(btn);
        if(!shape) return;
        e.preventDefault();
        e.stopPropagation();
        window.setShape ? window.setShape(shape) : setShape(shape);
    }, {capture:true, passive:false});
})();
