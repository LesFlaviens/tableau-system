(function(){
"use strict";

let currentChooserReservation = null;

function tcNorm(v){ return String(v == null ? "" : v).trim(); }
function tcId(r){ return String(r?.id || r?.reservationId || r?.bookingId || ""); }
function tcPax(r){ return parseInt(r?.couverts || r?.pax || r?.personnes || r?.guests || 0) || 1; }
function tcCap(t){ return parseInt(t?.pax || t?.capacity || t?.seats || 0) || 0; }

function tcActiveReservation(r){
    const s=tcNorm(r?.status || r?.reservationStatus).toLowerCase();
    return !["rejected","cancelled","canceled","annule","annulee","completed","done","noshow","no show"].includes(s);
}

function tcHasRealOrder(order){
    const items=Array.isArray(order?.items) ? order.items : [];
    return items.some(i=>{
        const name=tcNorm(i?.n ?? i?.name ?? i?.productName ?? i?.title);
        const qty=Number(i?.qty ?? i?.quantity ?? 1);
        return !!name && qty>0;
    });
}

function tcGetReservation(id){
    return (Array.isArray(reservationsData) ? reservationsData : [])
        .find(r=>tcId(r)===String(id)) || null;
}

async function tcGetState(){
    if(window.API && typeof API.getState==="function"){
        return await API.getState();
    }
    const r=await fetch(`${window.SERVER_URL}/get-current-state?tenantID=${getTenantParam()}`,{cache:"no-store"});
    if(!r.ok) throw new Error("STATE_"+r.status);
    return r.json();
}

function tcTables(state){
    const fromState=state?.activeOrders?.ARCHITECTURE?.data?.tables;
    if(Array.isArray(fromState)) return fromState;
    return Array.isArray(window.tables) ? window.tables : [];
}

function tcReservedByOther(resas,label,target){
    return (resas||[]).some(r=>{
        if(!r || r===target || !tcActiveReservation(r)) return false;
        return tcNorm(r.assignedTable || r.tableId || r.table)===label;
    });
}

function tcRankTables(state,target){
    const resas=state?.activeOrders?.RESERVATIONS_MASTER?.data || reservationsData || [];
    const pax=tcPax(target);
    const current=tcNorm(target?.assignedTable || target?.tableId || target?.table);

    const all=tcTables(state);

    const empty=all.filter(t=>{
        if(!t || t.isExtra) return false;
        const label=tcNorm(t.label);
        if(!label) return false;

        // Current table is excluded from alternatives when changing.
        if(current && label===current) return false;

        // Real open order = occupied.
        if(tcHasRealOrder(state?.activeOrders?.[label])) return false;

        // Another active reservation = unavailable.
        if(tcReservedByOther(resas,label,target)) return false;

        return true;
    });

    const compatible=empty
        .filter(t=>tcCap(t)>=pax)
        .map(t=>{
            const capacity=tcCap(t);
            const waste=capacity-pax;

            // Lower score is better. Exact fit = 0.
            let score=waste*100;

            // Prefer same room currently displayed only as a tie-breaker.
            if(window.currentRoom && t.room && t.room!==window.currentRoom) score+=1;

            return {
                table:t,
                capacity,
                waste,
                score,
                exact:waste===0
            };
        })
        .sort((a,b)=>{
            if(a.score!==b.score) return a.score-b.score;
            return String(a.table.label).localeCompare(String(b.table.label),"fr",{numeric:true});
        });

    const tooSmall=empty
        .filter(t=>tcCap(t)<pax)
        .sort((a,b)=>tcCap(b)-tcCap(a));

    return {pax,current,empty,compatible,tooSmall};
}

function tcEscape(v){
    return String(v??"").replace(/[&<>"']/g,c=>({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
}

window.ichefOpenReservationTableChooser=async function(resaId){
    if(!window.currentUser || currentUser.role!=="Manager"){
        return alert("⛔ Accès Manager requis.");
    }

    const reservation=tcGetReservation(resaId);
    if(!reservation) return alert("Réservation introuvable.");

    currentChooserReservation=reservation;

    const modal=document.getElementById("ichef-table-change-modal");
    const list=document.getElementById("ichef-table-change-list");
    const subtitle=document.getElementById("ichef-table-change-subtitle");
    const info=document.getElementById("ichef-table-change-info");

    modal?.classList.add("open");
    if(list) list.innerHTML='<div style="color:var(--text-muted);padding:18px;">Recherche des tables libres…</div>';

    try{
        const state=await tcGetState();
        const ranked=tcRankTables(state,reservation);

        if(subtitle){
            subtitle.textContent=
                `${reservation.name || "Client"} · ${ranked.pax} couvert(s)`
                + (ranked.current ? ` · actuellement table ${ranked.current}` : "");
        }

        if(!ranked.empty.length){
            if(info){
                info.style.display="block";
                info.style.borderColor="#ef4444";
                info.style.color="#fca5a5";
                info.innerHTML="🛑 <strong>AUCUNE TABLE VIDE</strong> — le restaurant est actuellement complet.";
            }
            if(list) list.innerHTML='';
            return;
        }

        if(!ranked.compatible.length){
            const largest=ranked.tooSmall[0];
            const largestCap=largest ? tcCap(largest) : 0;
            const missing=Math.max(1,ranked.pax-largestCap);

            if(info){
                info.style.display="block";
                info.style.borderColor="#f59e0b";
                info.style.color="#fbbf24";
                info.innerHTML=
                    `⚠️ <strong>CAPACITÉ INSUFFISANTE</strong> — `
                    + `plus grande table vide : ${largestCap} place(s). `
                    + `Il manque ${missing} place${missing>1?"s":""}.`;
            }
            if(list) list.innerHTML='';
            return;
        }

        if(info){
            info.style.display="block";
            info.style.borderColor="#10b981";
            info.style.color="#6ee7b7";
            info.innerHTML=
                `✅ ${ranked.compatible.length} table(s) compatible(s), `
                + `classées de la <strong>plus adaptée</strong> à la moins optimale.`;
        }

        if(list){
            list.innerHTML=ranked.compatible.map((entry,index)=>{
                const t=entry.table;
                const room=tcEscape(t.room || "");
                const zone=tcEscape(t.zone || "");
                const where=[room,zone].filter(Boolean).join(" · ");

                let tagClass="ok";
                let tagText=`+${entry.waste} place${entry.waste>1?"s":""}`;
                if(entry.exact){
                    tagClass="exact";
                    tagText="CAPACITÉ EXACTE";
                }else if(entry.waste<=1){
                    tagClass="good";
                }

                return `
                <button type="button"
                        class="ichef-table-choice-card ${index===0?"best":""} ${entry.exact?"exact":""}"
                        onclick="ichefChooseReservationTable('${tcEscape(String(t.label))}')">
                    <div class="ichef-table-choice-head">
                        <div class="ichef-table-choice-name">TABLE ${tcEscape(t.label)}</div>
                        <div class="ichef-table-choice-cap">${entry.capacity} places</div>
                    </div>
                    <div class="ichef-table-choice-score">
                        <span>${where || "Plan de salle"}</span>
                        <span class="ichef-table-choice-tag ${tagClass}">${index===0?"⭐ ":""}${tagText}</span>
                    </div>
                </button>`;
            }).join("");
        }
    }catch(err){
        console.error("[iCHEF TABLE CHOOSER]",err);
        if(info){
            info.style.display="block";
            info.style.borderColor="#ef4444";
            info.style.color="#fca5a5";
            info.textContent="Impossible de charger les tables du plan.";
        }
    }
};

window.ichefCloseReservationTableChooser=function(){
    document.getElementById("ichef-table-change-modal")?.classList.remove("open");
    currentChooserReservation=null;
};

window.ichefChooseReservationTable=async function(label){
    if(!currentChooserReservation) return;

    const reservation=currentChooserReservation;

    try{
        const state=await tcGetState();
        const ranked=tcRankTables(state,reservation);
        const selected=ranked.compatible.find(x=>tcNorm(x.table.label)===tcNorm(label));

        // Revalidation at click time: protects against another server taking the table.
        if(!selected){
            alert("⚠️ Cette table n'est plus disponible. La liste va être actualisée.");
            return window.ichefOpenReservationTableChooser(tcId(reservation));
        }

        const rid=tcId(reservation);
        const idx=(Array.isArray(reservationsData)?reservationsData:[])
            .findIndex(r=>tcId(r)===rid);

        if(idx<0) return alert("Réservation introuvable.");

        reservationsData[idx].assignedTable=selected.table.label;
        reservationsData[idx].tableId=selected.table.label;
        reservationsData[idx].table=selected.table.label;
        reservationsData[idx].assignmentMode="MANAGER_CAPACITY";
        reservationsData[idx].assignedAt=new Date().toISOString();

        if(window.API && typeof API.update==="function"){
            await API.update("RESERVATIONS_MASTER",reservationsData,false,{
                reason:"Changement table réservation",
                operationType:"RESERVATION_ASSIGNMENT"
            });
        }else{
            const r=await fetch(`${window.SERVER_URL}/update-order?tenantID=${getTenantParam()}`,{
                method:"POST",
                headers:{"Content-Type":"application/json"},
                body:JSON.stringify({tableId:"RESERVATIONS_MASTER",order:{data:reservationsData}})
            });
            if(!r.ok) throw new Error("SAVE_FAILED");
        }

        window.ichefCloseReservationTableChooser();

        if(typeof window.ichefReservationSyncNow==="function")
            await window.ichefReservationSyncNow(true);

        if(typeof renderPlanning==="function") renderPlanning("today");
        if(typeof renderFloor==="function") renderFloor();
        if(typeof window.ichefRefreshTableStatusSummary==="function")
            await window.ichefRefreshTableStatusSummary();
        if(typeof window.ichefRefreshReservationTableColors==="function")
            await window.ichefRefreshReservationTableColors();

    }catch(err){
        console.error("[iCHEF CHANGER TABLE]",err);
        alert("❌ Impossible de changer la table.");
    }
};

window.ichefUsePlanForReservationChoice=function(){
    if(!currentChooserReservation) return;
    const id=tcId(currentChooserReservation);
    window.ichefCloseReservationTableChooser();

    // Preserve the existing manual floor-plan selection as an optional fallback.
    if(typeof startAssignResa==="function") startAssignResa(id);
};

})();
