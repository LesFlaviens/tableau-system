(function(){
    "use strict";

    let dashboardTimer = null;
    let dashboardRefreshing = false;

    function localDayKey(value){
        const d = value instanceof Date ? value : new Date(value);
        if(!Number.isFinite(d.getTime())) return "";
        const y=d.getFullYear();
        const m=String(d.getMonth()+1).padStart(2,"0");
        const day=String(d.getDate()).padStart(2,"0");
        return `${y}-${m}-${day}`;
    }

    function moneyValue(v){
        const n=Number(v);
        return Number.isFinite(n) ? n : 0;
    }

    function transactionDate(t){
        const candidates=[
            t?.date,
            t?.time,
            t?.createdAt,
            t?.closedAt,
            t?.paidAt,
            t?.fiscalTicket?.createdAt
        ].filter(Boolean);

        for(const value of candidates){
            const d=new Date(value);
            if(Number.isFinite(d.getTime())) return d;
        }
        return null;
    }

    function transactionTableKey(t){
        const direct=String(
            t?.table ??
            t?.tableId ??
            t?.tableLabel ??
            ""
        ).trim();

        if(direct) return direct;

        const source=String(t?.source||"").trim();

        /* Pad Serveur (T3) -> T3 */
        const m=source.match(/\(([^()]+)\)\s*$/);
        if(m?.[1]) return m[1].trim();

        /* QR/web : chaque transaction doit rester distincte */
        if(/QR|WEB/i.test(source)){
            return String(t?.id || source);
        }

        return source || String(t?.id || "");
    }

    function isDashboardSystemKey(key){
        const k=String(key||"").toUpperCase();
        return (
            k==="FINANCIAL_HISTORY" ||
            k==="ARCHITECTURE" ||
            k.includes("_MASTER") ||
            k.startsWith("MENU_") ||
            k.startsWith("SETTINGS_") ||
            k.startsWith("FINANCIAL_") ||
            k.startsWith("RESERVATIONS_") ||
            k.startsWith("ALERTS_")
        );
    }

    function hasDashboardRealItems(order){
        const items=Array.isArray(order?.items)?order.items:[];
        return items.some(i=>{
            if(!i || typeof i!=="object") return false;
            const name=String(i.n ?? i.name ?? i.productName ?? i.title ?? "").trim();
            const qty=Number(i.qty ?? i.quantity ?? 1);
            return !!name && Number.isFinite(qty) && qty>0;
        });
    }

    function getLiveServiceOrders(state){
        const orders=state?.activeOrders || {};
        return Object.entries(orders)
            .filter(([key,order])=>{
                if(isDashboardSystemKey(key)) return false;
                if(!order || typeof order!=="object") return false;
                return hasDashboardRealItems(order);
            });
    }

    function getFinancialHistory(state){
        const node=state?.activeOrders?.FINANCIAL_HISTORY;

        if(Array.isArray(node)) return node.filter(Boolean);
        if(Array.isArray(node?.data)) return node.data.filter(Boolean);
        if(Array.isArray(node?.items)) return node.items.filter(Boolean);

        return [];
    }

    function escapeHtml(v){
        return String(v ?? "")
            .replace(/&/g,"&amp;")
            .replace(/</g,"&lt;")
            .replace(/>/g,"&gt;")
            .replace(/"/g,"&quot;");
    }

    function renderDashboardTransaction(t){
        const dateObj=transactionDate(t);
        const timeStr=dateObj
            ? dateObj.toLocaleDateString('fr-FR')+' '+
              dateObj.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})
            : "Date inconnue";

        const items=Array.isArray(t?.items)?t.items:[];

        const itemsHtml=items.map(i=>{
            const qty=Number(i?.qty||1)||1;
            const price=moneyValue(i?.price ?? i?.p);
            const name=escapeHtml(i?.name ?? i?.n ?? "Article");
            const seat=Number(i?.seat||0)>0 ? ` · 👤︎ ${Number(i.seat)}` : "";
            return `<div style="display:flex;justify-content:space-between;font-size:.85rem;color:var(--text-muted);gap:12px;">
                <span>${qty}x ${name}${seat}</span>
                <span>${(price*qty).toFixed(2)}€</span>
            </div>`;
        }).join("");

        const tableKey=transactionTableKey(t);
        const source=String(t?.source||"");
        const isWeb=/QR|WEB/i.test(source) || /^WEB_|^QR_/i.test(tableKey);
        const title=isWeb
            ? `📱 QR CODE ${tableKey && !/^WEB_|^QR_/i.test(tableKey) ? '· '+escapeHtml(tableKey) : ''}`
            : `TABLE ${escapeHtml(tableKey || source || "—")}`;

        const total=moneyValue(t?.totalTTC ?? t?.total);
        const method=escapeHtml(t?.method || t?.typePaiement || t?.paymentMethod || "Inconnu");

        return `
        <div style="background:transparent;border:1px solid var(--border-strong);padding:15px;border-radius:4px;margin-bottom:10px;">
            <div style="display:flex;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:10px;gap:12px;">
                <div style="color:var(--text-main);font-weight:600;font-size:1.1rem;letter-spacing:1px;">${title}</div>
                <div style="color:var(--text-muted);font-size:.8rem;white-space:nowrap;">${timeStr}</div>
            </div>
            <div style="margin-bottom:10px;line-height:1.6;">
                ${itemsHtml || '<div style="color:var(--text-muted);font-size:.8rem;">Détail articles indisponible</div>'}
            </div>
            <div style="display:flex;justify-content:space-between;color:var(--gold);font-weight:600;border-top:1px dashed var(--border);padding-top:10px;">
                <span style="font-size:.8rem;letter-spacing:1px;">TOTAL</span>
                <span>${total.toFixed(2)}€</span>
            </div>
            <div style="font-size:.7rem;color:var(--text-muted);text-align:right;margin-top:5px;text-transform:uppercase;">
                Paiement: ${method}
            </div>
        </div>`;
    }

    window.refreshDashboardDirection=async function(showLoading=false){
        const modal=document.getElementById("dashboard-modal");
        if(!modal?.classList.contains("open") || dashboardRefreshing) return;

        dashboardRefreshing=true;

        const container=document.getElementById("dashboard-content");
        if(showLoading && container){
            container.innerHTML='<div style="color:var(--text-muted);text-align:center;">Connexion au serveur…</div>';
        }

        try{
            const state=await API.getState();
            let history=getFinancialHistory(state);

            if(typeof window.ichefFilterGhostT3History==="function"){
                history=window.ichefFilterGhostT3History(history);
            }

            history.sort((a,b)=>{
                const da=transactionDate(a)?.getTime()||0;
                const db=transactionDate(b)?.getTime()||0;
                return db-da;
            });

            const today=localDayKey(new Date());
            const todayClosed=history.filter(t=>{
                const d=transactionDate(t);
                return d && localDayKey(d)===today;
            });

            /* CA du jour = uniquement transactions clôturées/payées aujourd'hui */
            const todayCA=todayClosed.reduce(
                (sum,t)=>sum+moneyValue(t?.totalTTC ?? t?.total),
                0
            );

            /* Une table physique n'est comptée qu'une fois.
               Chaque retrait QR est une commande servie distincte. */
            const servedKeys=new Set(
                todayClosed
                    .map(transactionTableKey)
                    .filter(Boolean)
            );

            const liveOrders=getLiveServiceOrders(state);

            const ca=document.getElementById("dash-ca");
            const count=document.getElementById("dash-tables-count");
            const live=document.getElementById("dash-live-tables");
            const histCount=document.getElementById("dash-history-count");

            if(ca) ca.textContent=todayCA.toFixed(2)+" €";
            if(count) count.textContent=String(servedKeys.size);
            if(live) live.textContent=String(liveOrders.length);
            if(histCount) histCount.textContent=String(history.length);

            if(container){
                container.innerHTML=history.length
                    ? history.slice(0,250).map(renderDashboardTransaction).join("")
                    : '<div style="color:var(--text-muted);text-align:center;padding:20px;">Aucune commande clôturée disponible.</div>';
            }

            window.ICHEF_DASHBOARD_LAST_SYNC={
                at:new Date().toISOString(),
                todayCA,
                tablesServedToday:servedKeys.size,
                historyCount:history.length,
                liveTables:liveOrders.length
            };

        }catch(err){
            console.error("[iCHEF] Dashboard Direction :",err);
            if(container){
                container.innerHTML=
                    '<div style="color:#ef4444;text-align:center;padding:20px;">⚠️ Impossible de charger les données du serveur.</div>';
            }
        }finally{
            dashboardRefreshing=false;
        }
    };

    function startDashboardLive(){
        clearInterval(dashboardTimer);
        dashboardTimer=setInterval(()=>{
            const modal=document.getElementById("dashboard-modal");
            if(modal?.classList.contains("open")){
                window.refreshDashboardDirection(false);
            }
        },5000);
    }

    document.addEventListener("DOMContentLoaded",startDashboardLive,{once:true});

    /* Dès qu'une clôture/commande arrive par Socket.IO, le Dashboard se recalcule. */
    document.addEventListener("ichef:financial-history-updated",()=>{
        window.refreshDashboardDirection(false);
    });

    /* Intercepte les événements socket déjà connectés sans créer une 2e socket. */
    const hookTimer=setInterval(()=>{
        try{
            if(typeof socket!=="undefined" && socket && !socket.__ichefDashboardHooked){
                socket.__ichefDashboardHooked=true;
                ["updateState","orderLifecycle"].forEach(evt=>{
                    socket.on(evt,()=>{
                        const modal=document.getElementById("dashboard-modal");
                        if(modal?.classList.contains("open")){
                            setTimeout(()=>window.refreshDashboardDirection(false),120);
                        }
                    });
                });
                clearInterval(hookTimer);
            }
        }catch(_){}
    },500);

})();
