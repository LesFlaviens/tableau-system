(function(){
"use strict";

function syncButtonState(){
    const btn = document.getElementById("ichef-anti-rush-drawer-btn");
    const panel = document.getElementById("anti-rush-server-panel");
    if(!btn) return;

    const open = !!panel?.classList.contains("open");
    btn.classList.toggle("active", open);

    /*
      Le bouton LIVE garde toujours son texte/calcul dynamique.
      syncButtonState ne gère désormais QUE l'état ouvert/fermé.
    */
    if(typeof window.ichefUpdateAntiRushSignal === "function"){
        window.ichefUpdateAntiRushSignal(true);
    }
}

function ensureDrawerAntiRushButton(){
    const drawer = document.getElementById("order-drawer");
    if(!drawer) return;

    let btn = document.getElementById("ichef-anti-rush-drawer-btn");
    if(btn){
        syncButtonState();
        return;
    }

    /*
      Priorité : barre des catégories centrale.
      Garde le bouton visible entre les tables à gauche et le ticket à droite.
    */
    const cats = 
        document.getElementById("dynamic-categories-container") || 
        drawer.querySelector(".swipe-row") || 
        drawer.querySelector(".menu-tabs");

    if(!cats) return;

    btn = document.createElement("button");
    btn.type = "button";
    btn.id = "ichef-anti-rush-drawer-btn";
    btn.title = "Ouvrir / fermer le moniteur Anti-Rush";
    
    // Pré-structure visuelle pour accueillir les données du signal LIVE
    btn.innerHTML = `
        <span class="ichef-ar-live-dot"></span>
        <span class="ichef-ar-drawer-copy">
            <span class="ichef-ar-drawer-main">⚡ ANTI-RUSH</span>
            <span class="ichef-ar-drawer-sector">Initialisation...</span>
        </span>
    `;

    // Le clic est attaché à la racine du bouton, il ne cassera pas lors 
    // du remplacement de l'innerHTML par le script du signal LIVE.
    btn.addEventListener("click", function(e){
        e.preventDefault();
        e.stopPropagation();

        try {
            if(typeof window.toggleAntiRushPanel === "function"){
                window.toggleAntiRushPanel();
            } else if(typeof toggleAntiRushPanel === "function"){
                toggleAntiRushPanel();
            }
        } catch(err) {
            console.warn("[iCHEF] Erreur ouverture Anti-Rush:", err);
        }

        setTimeout(() => {
            syncButtonState();
            if(typeof window.ichefUpdateAntiRushSignal === "function"){
                window.ichefUpdateAntiRushSignal(true);
            }
        }, 30);
    });

    cats.insertBefore(btn, cats.firstChild);
    syncButtonState();
}

window.ichefEnsureDrawerAntiRushButton = ensureDrawerAntiRushButton;

/* Aucun polling permanent : le MutationObserver ci-dessous suffit. */
const drawer = document.getElementById("order-drawer");
if(drawer){
    let __ichefBtnRaf = 0;
    new MutationObserver((mutations) => {
        if(!drawer.classList.contains("open")) return;

        /*
          On n'agit que si le bouton a réellement disparu ou si le drawer
          vient de s'ouvrir. Un seul RAF maximum, même si beaucoup de DOM change.
        */
        const missing = !document.getElementById("ichef-anti-rush-drawer-btn");
        const classChanged = mutations.some(m => m.type === "attributes" && m.attributeName === "class");

        if(!missing && !classChanged) return;
        if(__ichefBtnRaf) return;

        __ichefBtnRaf = requestAnimationFrame(() => {
            __ichefBtnRaf = 0;
            ensureDrawerAntiRushButton();
        });
    }).observe(drawer, {attributes: true, attributeFilter: ["class"], childList: true, subtree: true});
}

if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", () => {
        setTimeout(ensureDrawerAntiRushButton, 250);
    }, {once: true});
} else {
    setTimeout(ensureDrawerAntiRushButton, 250);
}

})();
