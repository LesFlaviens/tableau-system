(function(){
"use strict";

const TYPES = [
    ["TABLE","🍽️ Table"],
    ["CHAMBRE","🛏️ Chambre"],
    ["SUITE","🛎️ Suite"],
    ["SALON","🛋️ Salon"],
    ["BAR","🍸 Bar"],
    ["ROOM_SERVICE","🛎️ Room service"],
    ["TERRASSE","🌿 Terrasse"],
    ["SPA","🧖 Spa"],
    ["PETIT_DEJEUNER","☕ Petit-déjeuner"]
];

let currentType="TABLE";

function visible(el){
    if(!el)return false;
    const cs=getComputedStyle(el);
    return cs.display!=="none" && cs.visibility!=="hidden" && el.getClientRects().length>0;
}

function configPanel(){
    return [...document.querySelectorAll("div,section,dialog")].find(el=>{
        if(!visible(el))return false;
        const t=(el.innerText||"").toUpperCase();
        return t.includes("CONFIG. TABLE") && t.includes("CAPACITÉ");
    }) || null;
}

function findTarget(panel){
    if(!panel)return null;

    const input=[...panel.querySelectorAll("input,textarea")].find(visible);
    if(input)return input;

    return [...panel.querySelectorAll("div,span,p")].find(el=>{
        if(!visible(el) || el.closest("button"))return false;
        const r=el.getBoundingClientRect();
        const t=(el.textContent||"").trim();
        return t.length<=16 && r.width>250 && r.height>45;
    }) || null;
}

function getLabelValue(target){
    if(!target)return "";
    return ("value" in target) ? String(target.value||"") : String(target.textContent||"").trim();
}

function updateContext(panel){
    const ctx=panel?.querySelector("#ichef-space-context");
    if(!ctx)return;

    const examples={
        TABLE:"Exemples : T1, 12, A3",
        CHAMBRE:"Exemples : 101, 204, 305",
        SUITE:"Exemples : S1, SUITE2, 501",
        SALON:"Exemples : SALON1, VIP2",
        BAR:"Exemples : BAR1, B2",
        ROOM_SERVICE:"Exemples : RS101, RS204",
        TERRASSE:"Exemples : TERR1, T12",
        SPA:"Exemples : SPA1, CAB2",
        PETIT_DEJEUNER:"Exemples : PDJ1, BREAKFAST2"
    };
    ctx.textContent=examples[currentType] || "";
}

function build(){
    const panel=configPanel();
    if(!panel || panel.querySelector("#ichef-space-type-panel"))return;

    const target=findTarget(panel);
    if(!target)return;

    const wrap=document.createElement("div");
    wrap.id="ichef-space-type-panel";
    wrap.innerHTML=`
      <div id="ichef-space-type-title">TYPE D'ESPACE</div>
      <div id="ichef-space-type-grid"></div>
      <div id="ichef-space-context"></div>
    `;

    const grid=wrap.querySelector("#ichef-space-type-grid");
    TYPES.forEach(([value,label])=>{
        const b=document.createElement("button");
        b.type="button";
        b.dataset.type=value;
        b.textContent=label;
        if(value===currentType)b.classList.add("active");

        b.onclick=()=>{
            currentType=value;
            grid.querySelectorAll("button").forEach(x=>x.classList.remove("active"));
            b.classList.add("active");
            updateContext(panel);

            panel.dataset.ichefSpaceType=currentType;

            /* Expose au moteur architecture sans casser les anciens champs. */
            window.ICHEF_CURRENT_SPACE_TYPE=currentType;
        };

        grid.appendChild(b);
    });

    /* Inséré avant le pavé numérique propre */
    const keypad=panel.querySelector("#ichef-config-table-keypad-clean");
    if(keypad){
        keypad.insertAdjacentElement("beforebegin",wrap);
    }else{
        panel.appendChild(wrap);
    }

    panel.dataset.ichefSpaceType=currentType;
    window.ICHEF_CURRENT_SPACE_TYPE=currentType;
    updateContext(panel);
}

/* Utilitaire commun pour restaurant/hôtel */
window.ichefGetSpaceLabel=function(type,label){
    const map={
        TABLE:"TABLE",
        CHAMBRE:"CHAMBRE",
        SUITE:"SUITE",
        SALON:"SALON",
        BAR:"BAR",
        ROOM_SERVICE:"ROOM SERVICE",
        TERRASSE:"TERRASSE",
        SPA:"SPA",
        PETIT_DEJEUNER:"PETIT-DÉJEUNER"
    };
    return `${map[type]||"ESPACE"} ${label||""}`.trim();
};

window.ichefGetCurrentSpaceType=function(){
    return window.ICHEF_CURRENT_SPACE_TYPE || "TABLE";
};

document.addEventListener("click",()=>setTimeout(build,20),true);
{
  const __ichefSpaceModal=document.getElementById('table-config-modal');
  if(__ichefSpaceModal){
    let __ichefSpaceRaf=0;
    new MutationObserver(()=>{
      if(__ichefSpaceRaf) return;
      __ichefSpaceRaf=requestAnimationFrame(()=>{__ichefSpaceRaf=0;build();});
    }).observe(__ichefSpaceModal,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  }
}
setTimeout(build,250);
})();
