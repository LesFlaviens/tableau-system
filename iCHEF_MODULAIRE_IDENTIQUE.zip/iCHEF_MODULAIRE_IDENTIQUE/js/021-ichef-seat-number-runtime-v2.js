(function(){
    "use strict";

    function numberSeats(){
        document.querySelectorAll('.table-wrapper').forEach(function(table){
            const chairs = Array.from(table.querySelectorAll('.chair'));
            
            chairs.forEach(function(chair, index){
                const num = String(index + 1);
                
                // On force le data-seat systématiquement pour garantir le CSS
                if (chair.getAttribute('data-seat') !== num) {
                    chair.setAttribute('data-seat', num);
                }
                
                // Nettoyage radical des anciens textes internes pour éviter les doublons visuels
                chair.textContent = ''; 
                chair.setAttribute('aria-label', 'Place ' + num);
            });
        });
    }

    const originalRender = window.renderFloor;
    if(typeof originalRender === 'function'){
        window.renderFloor = function(){
            const result = originalRender.apply(this, arguments);
            requestAnimationFrame(numberSeats);
            return result;
        };
    }

    document.addEventListener('DOMContentLoaded', numberSeats);
    setTimeout(numberSeats, 250);
    setTimeout(numberSeats, 900);
})();
