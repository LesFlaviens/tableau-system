(function(){
    "use strict";

    const HOLD_MS = 900;
    const MOVE_LIMIT = 12;

    let holdTimer = null;
    let activeCard = null;
    let startX = 0;
    let startY = 0;

    function getMainSpan(card){
        if(!card) return null;
        return Array.from(card.children).find(el =>
            el.tagName === 'SPAN' &&
            !el.classList.contains('price') &&
            !el.classList.contains('stock-badge')
        ) || card.querySelector('span:not(.price):not(.stock-badge)');
    }

    function firstThreeWords(text){
        return String(text || '')
            .replace(/\s+/g,' ')
            .trim()
            .split(' ')
            .filter(Boolean)
            .slice(0,3)
            .join(' ');
    }

    function prepareCard(card){
        if(!card || card.dataset.ichefCardPrepared === '1') return;

        const span = getMainSpan(card);
        if(!span) return;

        const full = (span.textContent || '').trim();
        if(!full) return;

        span.dataset.ichefFullText = full;
        span.dataset.ichefShortText = firstThreeWords(full);
        span.textContent = span.dataset.ichefShortText;

        card.dataset.ichefCardPrepared = '1';
        card.classList.remove('ichef-card-expanded');
    }

    function prepareAll(){
        document.querySelectorAll('#menu-grid .btn-item').forEach(prepareCard);
    }

    function expandCard(card){
        const span = getMainSpan(card);
        if(!span) return;

        span.textContent = span.dataset.ichefFullText || span.textContent;
        card.classList.add('ichef-card-expanded');
        card.dataset.ichefSuppressNextClick = '1';

        try{
            if(navigator.vibrate) navigator.vibrate(20);
        }catch(_){}
    }

    function collapseCard(card){
        const span = getMainSpan(card);
        if(!span) return;

        span.textContent =
            span.dataset.ichefShortText ||
            firstThreeWords(span.dataset.ichefFullText || span.textContent);

        card.classList.remove('ichef-card-expanded');
    }

    function cancelHold(){
        clearTimeout(holdTimer);
        holdTimer = null;
        activeCard = null;
    }

    function install(){
        const grid = document.getElementById('menu-grid');
        if(!grid || grid.dataset.ichefLongPressFinalV3 === '1') return;

        grid.dataset.ichefLongPressFinalV3 = '1';
        prepareAll();

        grid.addEventListener('pointerdown', function(e){
            const card = e.target.closest('.btn-item');
            if(!card || !grid.contains(card) || card.classList.contains('sold-out')) return;
            if(card.classList.contains('ichef-card-expanded')) return;

            cancelHold();
            activeCard = card;
            startX = e.clientX;
            startY = e.clientY;

            holdTimer = setTimeout(function(){
                if(activeCard === card){
                    expandCard(card);
                }
                holdTimer = null;
            }, HOLD_MS);
        }, {passive:true});

        grid.addEventListener('pointermove', function(e){
            if(!activeCard || !holdTimer) return;
            if(
                Math.abs(e.clientX - startX) > MOVE_LIMIT ||
                Math.abs(e.clientY - startY) > MOVE_LIMIT
            ){
                cancelHold();
            }
        }, {passive:true});

        ['pointerup','pointercancel','pointerleave'].forEach(type=>{
            grid.addEventListener(type,cancelHold,{passive:true});
        });

        grid.addEventListener('click', function(e){
            const card = e.target.closest('.btn-item');
            if(!card || !grid.contains(card)) return;

            if(card.classList.contains('ichef-card-expanded')){
                collapseCard(card);
                delete card.dataset.ichefSuppressNextClick;
                e.preventDefault();
                e.stopPropagation();
                if(typeof e.stopImmediatePropagation === 'function'){
                    e.stopImmediatePropagation();
                }
                return;
            }

            if(card.dataset.ichefSuppressNextClick === '1'){
                delete card.dataset.ichefSuppressNextClick;
                e.preventDefault();
                e.stopPropagation();
                if(typeof e.stopImmediatePropagation === 'function'){
                    e.stopImmediatePropagation();
                }
            }
        }, true);

        grid.addEventListener('contextmenu', function(e){
            if(e.target.closest('.btn-item')) e.preventDefault();
        });

        new MutationObserver(function(){
            requestAnimationFrame(prepareAll);
        }).observe(grid,{childList:true,subtree:true});
    }

    function init(){
        install();
        prepareAll();
    }

    if(document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded',init,{once:true});
    }else{
        init();
    }

    setTimeout(init,300);
    setTimeout(init,1000);
})();
