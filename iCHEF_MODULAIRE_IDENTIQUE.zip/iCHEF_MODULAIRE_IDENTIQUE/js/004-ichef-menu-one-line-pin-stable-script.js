(function(){
    function placeMenuInHeader(){
        const header = document.querySelector('header');
        const dock = document.getElementById('service-tools-bar');
        const left = header ? header.querySelector('.header-left') : null;

        if(!header || !dock || !left) return;
        if(dock.dataset.pinStableFused === '1') return;

        // Déplacement DOM uniquement. Aucun changement de fonction métier.
        header.insertBefore(dock, left.nextSibling);
        dock.dataset.pinStableFused = '1';

        const nav = header.querySelector('.nav-btns');
        if(nav && nav.children.length === 0){
            nav.style.display = 'none';
        }
    }

    if(document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', placeMenuInHeader);
    } else {
        placeMenuInHeader();
    }

    setTimeout(placeMenuInHeader, 300);
    setTimeout(placeMenuInHeader, 1000);
})();
