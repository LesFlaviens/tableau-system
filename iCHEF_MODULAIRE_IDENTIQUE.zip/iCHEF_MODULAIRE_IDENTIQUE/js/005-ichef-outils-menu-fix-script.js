(function(){
    function positionToolsPanel(){
        const btn = document.querySelector(
            ".service-dock-folders .folder-btn[onclick*='folder-outils']"
        );
        const panel = document.getElementById('folder-outils');

        if(!btn || !panel || window.innerWidth <= 900) return;

        const rect = btn.getBoundingClientRect();
        const panelWidth = 280;

        let left = rect.right - panelWidth;
        left = Math.max(8, Math.min(left, window.innerWidth - panelWidth - 8));

        panel.style.setProperty('top', (rect.bottom + 6) + 'px', 'important');
        panel.style.setProperty('left', left + 'px', 'important');
        panel.style.setProperty('right', 'auto', 'important');
    }

    const oldToggle = window.toggleQuickFolder;

    window.toggleQuickFolder = function(id, button){
        const panel = document.getElementById(id);
        if(!panel) return;

        const shouldOpen = !panel.classList.contains('open');

        document.querySelectorAll('.quick-folder-panel.open')
            .forEach(p => p.classList.remove('open'));

        document.querySelectorAll('.folder-btn.open')
            .forEach(b => b.classList.remove('open'));

        if(shouldOpen){
            panel.classList.add('open');
            if(button) button.classList.add('open');

            if(id === 'folder-outils'){
                positionToolsPanel();
            }
        }
    };

    window.addEventListener('resize', function(){
        const panel = document.getElementById('folder-outils');
        if(panel && panel.classList.contains('open')){
            positionToolsPanel();
        }
    });
})();
