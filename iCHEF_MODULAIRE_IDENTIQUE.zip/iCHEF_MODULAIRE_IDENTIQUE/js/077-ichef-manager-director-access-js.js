(function(){
    "use strict";

    let accessPin = "";
    let busy = false;
    let failureCount = 0;
    let blockedUntil = 0;
    const managerRoles = new Set(["master","admin","manager","director","directeur"]);

    function modal(){ return document.getElementById("manager-director-access-modal"); }
    function display(){ return document.getElementById("manager-access-pin-display"); }
    function message(){ return document.getElementById("manager-access-message"); }

    function updateButton(){
        const btn = document.getElementById("btn-manager-director-access");
        const label = document.getElementById("manager-director-access-label");
        if(!btn || !label) return;
        const isManager = !!window.currentUser ? window.currentUser?.role === "Manager" : (typeof currentUser !== "undefined" && currentUser?.role === "Manager");
        btn.classList.toggle("manager-active", !!isManager);
        label.textContent = isManager ? "ESPACE MANAGER" : "MANAGER / DIRECTEUR";
    }

    function renderPin(){
        const el = display();
        if(el) el.textContent = "•".repeat(accessPin.length);
    }

    function setMessage(text, tone){
        const el = message();
        if(!el) return;
        el.textContent = text || "";
        el.style.color = tone === "error" ? "var(--alert)" : tone === "ok" ? "#22c55e" : tone === "wait" ? "var(--gold)" : "var(--text-muted)";
    }

    function clear(){
        accessPin = "";
        renderPin();
    }

    function close(){
        const m = modal();
        if(m){
            m.classList.remove("open");
            m.setAttribute("aria-hidden","true");
        }
        clear();
        setMessage("Accès sécurisé");
    }

    function currentIsManager(){
        try { return !!currentUser && currentUser.role === "Manager"; } catch(_) { return false; }
    }

    window.openManagerDirectorAccess = function(){
        if(currentIsManager()){
            updateButton();
            if(typeof openAdminCatalog === "function") openAdminCatalog();
            return;
        }
        const m = modal();
        if(!m) return alert("Accès Manager indisponible.");
        clear();
        setMessage("Entrez le PIN Manager / Directeur");
        m.classList.add("open");
        m.setAttribute("aria-hidden","false");
    };

    window.closeManagerDirectorAccess = close;

    async function submit(){
        if(busy) return;
        if(Date.now() < blockedUntil){
            setMessage("⏳ Trop de tentatives. Patientez 30 secondes.","error");
            return;
        }
        const pin = String(accessPin || "").trim();
        if(!/^\d{4,12}$/.test(pin)){
            setMessage("❌ PIN invalide : 4 chiffres minimum.","error");
            clear();
            return;
        }

        busy = true;
        setMessage("⏳ Vérification Manager / Directeur...","wait");
        try{
            if(typeof secureFetch !== "function") throw new Error("secureFetch indisponible");
            const response = await secureFetch("/api/verify-pin", {
                method:"POST",
                headers:{"Accept":"application/json"},
                body:JSON.stringify({
                    tenantID: appTenantID,
                    pin,
                    deviceId: window.ICHEF_SECURITY?.deviceId || null
                })
            });
            const data = await response.json().catch(()=>({}));
            if(!response.ok || !data.success){
                failureCount += 1;
                if(failureCount >= 5){
                    blockedUntil = Date.now() + 30000;
                    failureCount = 0;
                }
                try{ if(typeof auditEvent === "function") await auditEvent("MANAGER_ACCESS_DENIED",{reason:"INVALID_PIN"},false); }catch(_){}
                setMessage(`❌ ${data.error || "Code PIN incorrect."}`,"error");
                clear();
                return;
            }

            const role = String(data.role || "staff").trim().toLowerCase();
            if(!managerRoles.has(role)){
                try{ if(typeof auditEvent === "function") await auditEvent("MANAGER_ACCESS_DENIED",{reason:"ROLE_NOT_ALLOWED",role},false); }catch(_){}
                setMessage("⛔ Ce PIN appartient à un profil Serveur.","error");
                clear();
                return;
            }

            failureCount = 0;
            if(data.sessionToken) window.ICHEF_SECURITY.sessionToken = data.sessionToken;
            if(data.csrfToken) window.ICHEF_SECURITY.csrfToken = data.csrfToken;

            const name = role === "master" ? "Directeur" : "Manager";
            currentUser = { name, role:"Manager", serverRole:role };
            window.ICHEF_SECURITY.user = currentUser;
            window.ICHEF_SECURITY.authenticatedAt = Date.now();
            window.ICHEF_SECURITY.permissions = new Set([
                "ADMIN_ACCESS",
                "FLOORPLAN_DELETE",
                "ORDER_ITEM_CANCEL",
                "ORDER_VOID",
                "TERMINAL_MAINTENANCE"
            ]);

            const badge = document.getElementById("user-badge");
            if(badge) badge.textContent = `Badge: ${name}`;
            document.querySelectorAll(".admin").forEach(el=>el.style.display="block");
            updateButton();
            try{ if(typeof resetInactivityTimer === "function") resetInactivityTimer(); }catch(_){}
            try{ if(typeof auditEvent === "function") await auditEvent("MANAGER_ACCESS_GRANTED",{role},false); }catch(_){}

            setMessage(`✅ Accès ${name} autorisé`,"ok");
            setTimeout(()=>{
                close();
                if(typeof openAdminCatalog === "function") openAdminCatalog();
            },250);
        }catch(err){
            console.error("Accès Manager / Directeur",err);
            setMessage("❌ Impossible de vérifier le PIN auprès du serveur.","error");
            clear();
        }finally{
            busy = false;
        }
    }

    function bind(){
        const m = modal();
        if(!m || m.dataset.boundManagerAccess === "1") return;
        m.dataset.boundManagerAccess = "1";
        document.getElementById("manager-access-close")?.addEventListener("click", close);
        document.getElementById("manager-access-keypad")?.addEventListener("click", e=>{
            const btn = e.target.closest("button");
            if(!btn) return;
            const digit = btn.dataset.managerPin;
            const action = btn.dataset.managerAction;
            if(digit != null){
                if(accessPin.length < 12){ accessPin += digit; renderPin(); }
                return;
            }
            if(action === "clear"){ clear(); setMessage("PIN effacé"); return; }
            if(action === "submit") submit();
        });
        m.addEventListener("click", e=>{ if(e.target === m) close(); });
        updateButton();
    }

    if(document.readyState === "loading") document.addEventListener("DOMContentLoaded",bind,{once:true});
    else bind();

    // Synchronise le bouton lorsque le badge utilisateur change après un login normal.
    const badge = document.getElementById("user-badge");
    if(badge) new MutationObserver(updateButton).observe(badge,{childList:true,subtree:true,characterData:true});
})();
