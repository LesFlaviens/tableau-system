(function(){
    "use strict";

    const TENANT_RE=/^[A-Za-z0-9_-]{2,80}$/;
    let curtainTimer=0;
    let lastViolationAt=0;

    function currentTenant(){
        try{
            const urlTenant=new URLSearchParams(location.search).get("tenantID");
            const stored=localStorage.getItem("ichef_tenant_id");
            return urlTenant || stored || "";
        }catch(_){ return ""; }
    }

    function tenantValid(){
        const tenant=currentTenant();
        return !!tenant && TENANT_RE.test(tenant);
    }

    function shortDevice(){
        const d=String(window.ICHEF_SECURITY?.deviceId || "");
        return d ? d.slice(-10) : "NO-DEVICE";
    }

    function addWatermark(){
        if(document.getElementById("ichef-security-watermark")) return;
        const wm=document.createElement("div");
        wm.id="ichef-security-watermark";
        wm.textContent=`iCHEF • ${currentTenant()} • ${shortDevice()}`;
        document.body.appendChild(wm);
    }

    function ensureCurtain(){
        let c=document.getElementById("ichef-security-curtain");
        if(c) return c;

        c=document.createElement("div");
        c.id="ichef-security-curtain";
        c.innerHTML=`
            <strong>🔒 iCHEF — ÉCRAN PROTÉGÉ</strong>
            <span id="ichef-security-curtain-ref"></span>
        `;
        document.body.appendChild(c);
        return c;
    }

    function showCurtain(ms=1100, label="PROTECTION CONFIDENTIALITÉ"){
        const c=ensureCurtain();
        const ref=c.querySelector("#ichef-security-curtain-ref");
        if(ref) ref.textContent=`${label} • TENANT ${currentTenant()} • ${shortDevice()}`;

        c.classList.add("show");
        clearTimeout(curtainTimer);
        curtainTimer=setTimeout(()=>c.classList.remove("show"),ms);
    }

    async function audit(action,details={}){
        try{
            if(typeof reportClientSecurityEvent==="function"){
                return reportClientSecurityEvent(action,details);
            }
        }catch(_){}
    }

    function securityViolation(type, extra={}){
        const now=Date.now();
        if(now-lastViolationAt>800){
            lastViolationAt=now;
            audit("CLIENT_SECURITY_VIOLATION",{type,...extra});
        }
        showCurtain(900,"ACCÈS BLOQUÉ");
    }

    /* Vérifie que le tenant URL et le tenant local ne divergent pas. */
    function enforceTenantBinding(){
        let urlTenant="",stored="";
        try{
            const p=new URLSearchParams(location.search);
            urlTenant=p.get("tenantID") || "";
            stored=localStorage.getItem("ichef_tenant_id") || "";
        }catch(_){}

        if(urlTenant && !TENANT_RE.test(urlTenant)){
            document.documentElement.classList.add("ichef-security-locked");
            const c=ensureCurtain();
            c.classList.add("show");
            c.innerHTML="<strong>⛔ TENANT INVALIDE</strong><span>Accès refusé.</span>";
            audit("INVALID_TENANT_FORMAT",{tenant:String(urlTenant).slice(0,100)});
            return false;
        }

        if(urlTenant && stored && urlTenant!==stored){
            /* Le bootstrap existant remettra le tenant en cohérence.
               Ici on efface seulement les données locales potentiellement croisées. */
            try{
                localStorage.removeItem("EMPIRE_GLOBAL_SYNC");
                sessionStorage.clear();
            }catch(_){}
            audit("TENANT_CONTEXT_CHANGED",{from:stored,to:urlTenant});
        }

        return tenantValid();
    }

    /* Dissuasion DevTools : ne remplace pas la sécurité serveur. */
    function blockDevShortcut(e){
        const key=String(e.key || "").toLowerCase();
        const blocked =
            key==="f12" ||
            ((e.ctrlKey || e.metaKey) && e.shiftKey && ["i","j","c","k"].includes(key)) ||
            ((e.ctrlKey || e.metaKey) && ["u","s"].includes(key));

        if(!blocked) return;

        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        securityViolation("DEVTOOLS_SHORTCUT",{key});
    }

    document.addEventListener("keydown",blockDevShortcut,true);
    document.addEventListener("contextmenu",function(e){
        e.preventDefault();
    },true);

    /* PrintScreen : le Web ne peut pas garantir le blocage OS.
       On masque immédiatement l'interface et journalise la tentative. */
    document.addEventListener("keyup",function(e){
        if(String(e.key || "").toLowerCase()==="printscreen"){
            showCurtain(1600,"CAPTURE D'ÉCRAN DISSUADÉE");
            audit("PRINTSCREEN_KEY",{});
        }
    },true);

    /* Quand l'app perd la visibilité, aucun contenu sensible ne reste affiché. */
    document.addEventListener("visibilitychange",function(){
        if(document.hidden){
            ensureCurtain().classList.add("show");
        }else{
            setTimeout(()=>ensureCurtain().classList.remove("show"),180);
        }
    },{passive:true});

    window.addEventListener("blur",function(){
        showCurtain(650,"CONFIDENTIALITÉ");
    },{passive:true});

    /* Détecte un tenant modifié à chaud dans l'URL. */
    let tenantSnapshot=currentTenant();
    setInterval(function(){
        const nowTenant=currentTenant();
        if(nowTenant!==tenantSnapshot){
            audit("TENANT_RUNTIME_CHANGE",{from:tenantSnapshot,to:nowTenant});
            tenantSnapshot=nowTenant;
            enforceTenantBinding();
            addWatermark();
        }
    },3000);

    function boot(){
        enforceTenantBinding();
        addWatermark();
        ensureCurtain();

        /* Enregistrement PWA. Le SW ne cache jamais API/commandes. */
        if("serviceWorker" in navigator &&
           (location.protocol==="https:" ||
            location.hostname==="localhost" ||
            location.hostname==="127.0.0.1")){
            navigator.serviceWorker.register("/sw.js",{scope:"/"})
                .catch(err=>console.warn("[iCHEF] Service Worker:",err));
        }
    }

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",boot,{once:true});
    }else{
        boot();
    }
})();
