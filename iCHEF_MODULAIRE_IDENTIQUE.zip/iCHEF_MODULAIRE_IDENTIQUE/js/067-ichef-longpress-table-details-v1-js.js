(function(){
'use strict';

const HOLD_MS=500;
const MOVE_CANCEL_PX=14;
let press=null;
let suppressUntil=0;
let currentDetailLabel='';

const overlay=document.getElementById('ichef-table-detail-overlay');
const bodyEl=document.getElementById('ichef-td-body');
const titleEl=document.getElementById('ichef-td-title');
const subtitleEl=document.getElementById('ichef-td-subtitle');

function esc(value){
    return String(value ?? '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
function norm(v){return String(v ?? '').trim().toLowerCase().replace(/[^a-z0-9]/g,'');}
function labelOfTarget(target){
    const wrapper=target?.closest?.('#floor-plan .table-wrapper');
    return String(wrapper?.dataset?.id ?? wrapper?.dataset?.table ?? wrapper?.dataset?.label ?? '').trim();
}
function findOrder(label){
    try{
        if(typeof activeOrders==='undefined' || !activeOrders) return null;
        const wanted=norm(label);
        const key=Object.keys(activeOrders).find(k=>norm(k)===wanted || norm('t'+k)===wanted || norm(k)===norm(String(label).replace(/^t/i,'')));
        return key ? activeOrders[key] : null;
    }catch(_){return null;}
}
function findTable(label){
    try{return Array.isArray(tables) ? tables.find(t=>t && norm(t.label)===norm(label)) || null : null;}catch(_){return null;}
}
function findZone(table){
    try{
        if(!table || !Array.isArray(zones)) return null;
        const direct=zones.find(z=>z && (z.id===table.zoneId || z.label===table.zone || z.id===table.zone));
        if(direct) return direct;
        const cx=Number(table.l||0)+Number(table.w||80)/2;
        const cy=Number(table.t||0)+Number(table.h||120)/2;
        return zones.find(z=>z && (!z.room || !table.room || z.room===table.room) && cx>=Number(z.l||0) && cx<=Number(z.l||0)+Number(z.w||0) && cy>=Number(z.t||0) && cy<=Number(z.t||0)+Number(z.h||0)) || null;
    }catch(_){return null;}
}
function todayKey(){return new Date().toISOString().split('T')[0];}
function findReservation(label){
    try{
        if(!Array.isArray(reservationsData)) return null;
        return reservationsData.find(r=>{
            if(!r) return false;
            const assigned=String(r.assignedTable ?? r.tableId ?? r.table ?? '').trim();
            const st=String(r.status ?? r.reservationStatus ?? '').toLowerCase();
            if(['rejected','cancelled','canceled','annule','annulee','completed','done','noshow','no show'].includes(st)) return false;
            return norm(assigned)===norm(label) && (!r.date || r.date===todayKey());
        }) || null;
    }catch(_){return null;}
}
function itemName(i){return String(i?.originalName ?? i?.n ?? i?.name ?? i?.label ?? i?.title ?? 'Article').replace(/\[BR\]/g,' ').trim();}
function qty(i){const q=Number(i?.qty ?? i?.quantity ?? 1);return Number.isFinite(q)&&q>0?q:1;}
function seat(i){
    try{if(typeof window.ichefSeatNumber==='function') return Number(window.ichefSeatNumber(i))||0;}catch(_){ }
    const n=Number(i?.seat ?? i?.guestSeat ?? i?.seatNumber ?? 0);
    return Number.isFinite(n)&&n>=1&&n<=20?Math.floor(n):0;
}
function visibleItem(i){
    if(!i || qty(i)<=0 || !itemName(i)) return false;
    const s=String(i.status ?? i.sequenceStatus ?? '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    if(i.cancelled===true || i.canceled===true || i.deleted===true || i.voided===true || i.removed===true) return false;
    return !/CANCEL|ANNULE|VOID|SUPPRIM|REMOVED|DELETED/.test(s);
}
function itemState(i){
    const raw=String(i?.status ?? i?.sequenceStatus ?? '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    if(i?.served===true || /SERVI|SERVED/.test(raw)) return ['served','SERVI'];
    if(i?.done===true || /READY|PRET/.test(raw)) return ['ready','PRÊT'];
    if(i?.isSent===true || i?.fired===true || /PRODUCTION|CUISINE|EN COURS/.test(raw)) return ['production','CUISINE'];
    return ['waiting','ATTENTE'];
}
function money(v){
    const n=Number(v);
    return Number.isFinite(n)?n.toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2}):'';
}
function totalOf(order){
    if(!order) return '0,00';
    if(order.totalStr) return String(order.totalStr);
    const direct=Number(order.total ?? order.totalAmount ?? order.amount);
    if(Number.isFinite(direct)) return money(direct)+(String(order.currency||'').trim()?` ${esc(order.currency)}`:'');
    const t=(Array.isArray(order.items)?order.items:[]).filter(visibleItem).reduce((sum,i)=>sum+Number(i.p ?? i.price ?? i.unitPrice ?? 0)*qty(i),0);
    return money(t)+' €';
}
function paxOf(table,order){
    const direct=Number(order?.pax ?? order?.covers ?? order?.guests ?? table?.pax ?? 0);
    if(Number.isFinite(direct)&&direct>0) return Math.floor(direct);
    const obs=String(order?.observations ?? '');
    const m=obs.match(/(\d+)\s*Couvert/i);
    return m?Number(m[1]):0;
}
function openedAt(order){
    if(!order) return null;
    const candidates=[order.createdAt,order.created_at,order.timestamp,order.openedAt,order.dateCreated];
    for(const c of candidates){
        if(!c) continue;
        const n=Number(c); const d=Number.isFinite(n)?new Date(n):new Date(c);
        if(!isNaN(d.getTime())) return d;
    }
    const ids=(Array.isArray(order.items)?order.items:[]).map(i=>Number(i?.itemId)).filter(n=>Number.isFinite(n)&&n>1000000000000);
    return ids.length?new Date(Math.min(...ids)):null;
}
function elapsedText(date){
    if(!date) return '—';
    const min=Math.max(0,Math.floor((Date.now()-date.getTime())/60000));
    if(min<60) return `${min} min`;
    return `${Math.floor(min/60)} h ${min%60} min`;
}
function serverOf(order){
    const raw=order?.serverName ?? order?.waiterName ?? order?.employeeName ?? order?.userName ?? order?.server ?? order?.waiter ?? '';
    if(typeof raw==='object') return String(raw.name ?? raw.displayName ?? raw.firstName ?? '').trim() || '—';
    return String(raw||'').trim() || '—';
}
function orderStatus(order){
    if(!order) return 'LIBRE';
    if(order.alerteRouge) return 'ALERTE';
    if(String(order.status||'').toUpperCase()==='EN ATTENTE PAIEMENT') return 'PAIEMENT';
    const items=(Array.isArray(order.items)?order.items:[]).filter(visibleItem);
    if(!items.length) return 'OUVERTE';
    if(items.every(i=>i.served===true)) return 'SERVIE';
    if(items.every(i=>i.done===true || i.served===true)) return 'PRÊTE';
    if(items.some(i=>i.isSent===true || i.fired===true)) return 'EN SERVICE';
    return 'SAISIE';
}
function courseLabel(item){
    const raw=item?.courseName ?? item?.courseLabel ?? item?.course ?? item?.sequence ?? item?.sequenceName ?? 'Commande';
    const s=String(raw).trim();
    const map={'1':'ENTRÉES','2':'PLATS','3':'DESSERTS','4':'BOISSONS'};
    return map[s] || s || 'COMMANDE';
}
function extrasHtml(i){
    const parts=[];
    if(i?.cooking) parts.push(`Cuisson : ${esc(i.cooking)}`);
    if(i?.obs) parts.push(`Obs : ${esc(i.obs)}`);
    const add=Array.isArray(i?.modifiers?.add)?i.modifiers.add:[];
    const rem=Array.isArray(i?.modifiers?.remove)?i.modifiers.remove:[];
    if(add.length) parts.push(`+ ${esc(add.join(', '))}`);
    if(rem.length) parts.push(`− ${esc(rem.join(', '))}`);
    return parts.join(' · ');
}
function metaBox(label,value){return `<div class="ichef-td-meta-box"><div class="ichef-td-meta-label">${esc(label)}</div><div class="ichef-td-meta-value">${esc(value)}</div></div>`;}

function renderDetails(label){
    const order=findOrder(label);
    const table=findTable(label);
    const zone=findZone(table);
    const resa=findReservation(label);
    currentDetailLabel=label;

    titleEl.textContent=`TABLE ${label}`;
    subtitleEl.textContent=[table?.room || (typeof currentRoom!=='undefined'?currentRoom:''),zone?.label||''].filter(Boolean).join(' · ') || 'Plan interactif';

    const pax=paxOf(table,order);
    const opened=openedAt(order);
    let html='<div class="ichef-td-meta">';
    html+=metaBox('STATUT',orderStatus(order));
    html+=metaBox('COUVERTS',pax||'—');
    html+=metaBox('SERVEUR',serverOf(order));
    html+=metaBox('OUVERTE DEPUIS',elapsedText(opened));
    html+=metaBox('ZONE',zone?.label||'—');
    html+=metaBox('SALLE',table?.room || (typeof currentRoom!=='undefined'?currentRoom:'') || '—');
    html+=metaBox('TOTAL',totalOf(order));
    html+=metaBox('ORIGINE',order?.isWeb?'WEB / QR':'SERVEUR');
    html+='</div>';

    if(resa){
        const name=resa.name ?? resa.clientName ?? resa.customerName ?? 'Client';
        const time=resa.time ?? resa.hour ?? '';
        const rpax=resa.pax ?? resa.covers ?? resa.guests ?? '';
        html+=`<div class="ichef-td-reservation"><strong>📅 RÉSERVATION</strong> — ${esc(name)}${time?` · ${esc(time)}`:''}${rpax?` · ${esc(rpax)} couvert(s)`:''}</div>`;
    }

    const items=(Array.isArray(order?.items)?order.items:[]).filter(visibleItem);
    if(!items.length){
        html+='<div class="ichef-td-empty">Aucun plat dans cette table pour le moment.</div>';
    }else{
        const groups=new Map();
        items.forEach(i=>{const c=courseLabel(i);if(!groups.has(c))groups.set(c,[]);groups.get(c).push(i);});
        groups.forEach((arr,course)=>{
            html+=`<section class="ichef-td-section"><div class="ichef-td-section-title">${esc(course)}</div>`;
            arr.forEach(i=>{
                const s=seat(i); const [stateClass,stateLabel]=itemState(i); const extra=extrasHtml(i);
                const seatHtml=s?`<span class="ichef-td-seat ichef-seat-${s}" data-ichef-seat="${s}">👤︎ ${s}</span>`:'<span class="ichef-td-seat none">—</span>';
                html+=`<div class="ichef-td-item">${seatHtml}<div><div class="ichef-td-item-name">${qty(i)>1?`${qty(i)}× `:''}${esc(itemName(i))}</div>${extra?`<div class="ichef-td-item-extra">${extra}</div>`:''}</div><span class="ichef-td-state ${stateClass}">${stateLabel}</span></div>`;
            });
            html+='</section>';
        });
    }
    bodyEl.innerHTML=html;
}

function openDetails(label,tableEl){
    if(!label || !overlay) return;
    renderDetails(label);
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden','false');
    tableEl?.classList.add('ichef-longpress-opened');
    setTimeout(()=>tableEl?.classList.remove('ichef-longpress-opened'),240);
    suppressUntil=Date.now()+950;
    try{navigator.vibrate?.(18);}catch(_){ }
}
function closeDetails(){
    overlay?.classList.remove('open');
    overlay?.setAttribute('aria-hidden','true');
}
function cancelPress(){
    if(!press) return;
    clearTimeout(press.timer);
    press.el?.classList.remove('ichef-longpress-arming');
    press=null;
}

/* Appui long tactile/souris : uniquement sur les tables du plan et hors édition. */
document.addEventListener('pointerdown',e=>{
    const el=e.target?.closest?.('#floor-plan .table-obj');
    if(!el) return;
    if(document.body.classList.contains('edit-mode')) return;
    try{if(typeof pendingAssignResa!=='undefined' && pendingAssignResa) return;}catch(_){ }
    cancelPress();
    const label=labelOfTarget(el);
    if(!label) return;
    press={el,label,startX:e.clientX,startY:e.clientY,pointerId:e.pointerId,timer:null,opened:false};
    el.classList.add('ichef-longpress-arming');
    press.timer=setTimeout(()=>{
        if(!press || press.label!==label) return;
        press.opened=true;
        el.classList.remove('ichef-longpress-arming');
        openDetails(label,el);
    },HOLD_MS);
},true);

document.addEventListener('pointermove',e=>{
    if(!press || e.pointerId!==press.pointerId || press.opened) return;
    const dx=e.clientX-press.startX,dy=e.clientY-press.startY;
    if(Math.hypot(dx,dy)>MOVE_CANCEL_PX) cancelPress();
},true);

document.addEventListener('pointercancel',cancelPress,true);
document.addEventListener('pointerup',e=>{
    if(!press || e.pointerId!==press.pointerId) return;
    const opened=press.opened;
    cancelPress();
    if(opened){
        suppressUntil=Date.now()+950;
        e.preventDefault();
        e.stopImmediatePropagation();
    }
},true);

/* Bloque uniquement le tap/click synthétique qui suit un appui long.
   Le tap court existant reste inchangé. */
function suppressAfterLongPress(e){
    if(Date.now()>suppressUntil) return;
    if(!e.target?.closest?.('#floor-plan .table-obj')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
}
document.addEventListener('touchend',suppressAfterLongPress,{capture:true,passive:false});
document.addEventListener('click',suppressAfterLongPress,true);

document.getElementById('ichef-td-close')?.addEventListener('click',closeDetails);
document.getElementById('ichef-td-dismiss')?.addEventListener('click',closeDetails);
overlay?.addEventListener('click',e=>{if(e.target===overlay) closeDetails();});
document.addEventListener('keydown',e=>{if(e.key==='Escape' && overlay?.classList.contains('open')) closeDetails();});

document.getElementById('ichef-td-open-order')?.addEventListener('click',()=>{
    const label=currentDetailLabel;
    closeDetails();
    if(!label) return;
    setTimeout(()=>{
        try{
            if(typeof handleTableOrderTap==='function') handleTableOrderTap(label,label);
            else if(typeof openOrder==='function') openOrder(label);
        }catch(err){console.error('iCHEF ouverture commande depuis détail table',err);}
    },30);
});

window.ichefOpenTableDetails=openDetails;
window.ichefCloseTableDetails=closeDetails;
})();
