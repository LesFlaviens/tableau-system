(function(){
    "use strict";

    function expectedPax(table){
        let pax = parseInt(table?.dataset?.pax, 10);

        /* Secours : retrouver la table métier par son data-id si nécessaire. */
        if(!(pax > 0)){
            try{
                const id = String(table?.dataset?.id || '').trim();
                const source = Array.isArray(tables)
                    ? tables.find(t => t && String(t.label) === id)
                    : null;
                pax = parseInt(source?.pax, 10);
            }catch(_){ }
        }

        return Math.max(1, Math.min(50, Number.isFinite(pax) ? pax : 1));
    }

    function createChair(table, index, pax){
        const w = parseFloat(table.style.width) || table.offsetWidth || 80;
        const h = parseFloat(table.style.height) || table.offsetHeight || 120;
        const angle = (index / pax) * 2 * Math.PI - (Math.PI / 2);

        const c = document.createElement('div');
        c.className = 'chair';
        c.dataset.seat = String(index + 1);
        c.setAttribute('aria-label', 'Place ' + (index + 1));

        /* Position elliptique générique. Les moteurs de formes spécifiques
           (triangle, etc.) peuvent ensuite ajuster ces positions. */
        const rx = w / 2 + 16;
        const ry = h / 2 + 16;
        const cx = w / 2 + rx * Math.cos(angle) - 14;
        const cy = h / 2 + ry * Math.sin(angle) - 14;
        c.style.left = cx + 'px';
        c.style.top = cy + 'px';

        table.appendChild(c);
        return c;
    }

    function syncTableSeats(table){
        if(!table || table.closest('.rush-mode')) return;

        const pax = expectedPax(table);
        let chairs = Array.from(table.querySelectorAll(':scope > .chair'));

        /* Le bug venait d'ici : l'ancien moteur ne reconstruisait les chaises
           que lorsqu'il n'y en avait AUCUNE. Une table déjà créée avec 2 places
           restait donc à 2 même si son pax passait à 4 ou 7. */
        if(chairs.length !== pax){
            chairs.forEach(c => c.remove());
            chairs = [];
            for(let i=0; i<pax; i++){
                chairs.push(createChair(table, i, pax));
            }
        }

        chairs.forEach(function(chair, index){
            const num = String(index + 1);
            chair.dataset.seat = num;
            chair.textContent = '';
            chair.setAttribute('aria-label', 'Place ' + num + ' sur ' + pax);
        });

        table.dataset.renderedPax = String(pax);
    }

    function syncAllSeats(){
        if(document.body.classList.contains('rush-mode')) return;
        document.querySelectorAll('#floor-plan .table-wrapper').forEach(syncTableSeats);
    }

    let raf = 0;
    function schedule(){
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(syncAllSeats);
    }

    const floor = document.getElementById('floor-plan') || document.querySelector('.floor-plan');
    if(floor){
        const observer = new MutationObserver(schedule);
        observer.observe(floor, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['data-pax']
        });
    }

    /* Hook après chaque renderFloor pour synchroniser immédiatement les places. */
    const previousRenderFloor = window.renderFloor;
    if(typeof previousRenderFloor === 'function'){
        window.renderFloor = function(){
            const result = previousRenderFloor.apply(this, arguments);
            schedule();
            return result;
        };
    }

    document.addEventListener('DOMContentLoaded', schedule);
    setTimeout(schedule, 120);
    setTimeout(schedule, 500);
    setTimeout(schedule, 1200);
})();
