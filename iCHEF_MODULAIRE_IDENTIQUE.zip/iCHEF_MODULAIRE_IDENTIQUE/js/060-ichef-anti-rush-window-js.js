(function(){
"use strict";

let arTimer=null;

const META_KEYS=/MASTER|ARCHIVE|SETTINGS|RESERVATIONS|ALERTS|CATEGORIES|STAFF_ACCESS|LOYALTY|FINANCIAL|FISCAL|CANCEL_AUDIT/i;

function arState(v){
    return String(v==null?"":v)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g,"")
        .trim()
        .toUpperCase();
}

function arTs(v){
    if(v==null || v==="") return null;

    if(typeof v==="number" && Number.isFinite(v)){
        /* timestamps seconds -> ms */
        return v>0 && v<1e11 ? v*1000 : v;
    }

    if(typeof v==="string" && /^\d+$/.test(v.trim())){
        const n=Number(v);
        if(Number.isFinite(n)) return n<1e11?n*1000:n;
    }

    const p=Date.parse(v);
    return Number.isFinite(p)?p:null;
}

function arFmt(ms){
    if(!Number.isFinite(ms) || ms<0) ms=0;
    const total=Math.floor(ms/1000);
    const m=Math.floor(total/60);
    const s=total%60;
    return String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
}

function arAvg(arr){
    const a=arr.filter(v=>Number.isFinite(v)&&v>=0);
    if(!a.length) return 0;
    return a.reduce((x,y)=>x+y,0)/a.length;
}

function arPax(order){
    const n=Number(order?.couverts ?? order?.pax ?? order?.covers ?? 0);
    if(Number.isFinite(n)&&n>0) return Math.round(n);

    const obs=String(order?.observations||"");
    const m=obs.match(/🍽️\s*(\d+)/);
    return m?Number(m[1]):2;
}

function arItems(order){
    return (Array.isArray(order?.items)?order.items:[]).filter(i=>{
        if(!i || typeof i!=="object") return false;
        const name=String(i.n ?? i.name ?? i.productName ?? i.title ?? "").trim();
        const qty=Number(i.qty ?? i.quantity ?? 1);
        return !!name && Number.isFinite(qty) && qty>0;
    });
}

function arServed(i){
    const st=arState(i?.status);
    const seq=arState(i?.sequenceStatus);
    return i?.served===true ||
        st==="SERVI" ||
        st==="SERVED" ||
        seq==="SERVED";
}

function arTaken(i){
    const st=arState(i?.status);
    return i?.pickedByServer===true ||
        st==="PRIS_PAR_SERVEUR" ||
        st==="PRIS PAR SERVEUR" ||
        st==="TAKEN_BY_WAITER" ||
        st==="RUNNER_TAKEN";
}

function arReady(i){
    if(!i || arServed(i) || arTaken(i)) return false;
    const st=arState(i.status);
    const seq=arState(i.sequenceStatus);

    return i.done===true ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(st) ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(seq);
}

function arSent(i){
    const seq=arState(i?.sequenceStatus);
    const st=arState(i?.status);
    return i?.isSent===true ||
        ["PRODUCTION","READY","PRET_AU_PASS","PRET AU PASS","SERVED"].includes(seq) ||
        ["EN_PREPARATION","EN PREPARATION","READY","PRET_AU_PASS","PRET AU PASS","SERVI"].includes(st);
}

function arOrderStart(order,items){
    const direct=arTs(order?.createdAt ?? order?.openedAt ?? order?.startedAt);
    if(direct) return direct;

    const candidates=items
        .flatMap(i=>[
            arTs(i?.createdAt),
            arTs(i?.addedAt),
            arTs(i?.itemId),
            arTs(i?.sentAt)
        ])
        .filter(Boolean);

    return candidates.length?Math.min(...candidates):Date.now();
}

function arReadySince(items){
    const times=items
        .filter(arReady)
        .map(i=>arTs(i.readyAt ?? i.productionReadyAt ?? i.updatedAt))
        .filter(Boolean);
    return times.length?Math.min(...times):null;
}

function arLastEvolution(order,items,start){
    const vals=[
        arTs(order?.updatedAt),
        arTs(order?.modifiedAt),
        arTs(order?.lastActionAt),
        start
    ];

    items.forEach(i=>{
        vals.push(
            arTs(i?.updatedAt),
            arTs(i?.sentAt),
            arTs(i?.startedAt),
            arTs(i?.readyAt),
            arTs(i?.pickedAt),
            arTs(i?.pickedAtServer),
            arTs(i?.servedAt)
        );
    });

    const good=vals.filter(Boolean);
    return good.length?Math.max(...good):start;
}

function arRushLevel(){
    let serverLevel=0;

    try{
        if(typeof currentRushLevel!=="undefined"){
            serverLevel=Math.max(0,Math.min(5,Number(currentRushLevel)||0));
        }
    }catch(_){}

    try{
        serverLevel=Math.max(
            serverLevel,
            Math.max(0,Math.min(5,Number(window.systemSettings?.rushLevel)||0))
        );
    }catch(_){}

    /*
      Le bouton Anti-Rush calcule aussi un niveau LIVE local.
      Il sert d'alerte immédiate sans attendre l'ouverture d'anti-rush.html.
      Le serveur reste l'autorité pour les actions métier critiques.
    */
    const liveLevel=Math.max(
        0,
        Math.min(5,Number(window.__ichefAntiRushLiveLevel)||0)
    );

    return Math.max(serverLevel,liveLevel);
}

function arThresholds(){
    const level=arRushLevel();

    /* Le chrono est relié à l'Anti-Rush :
       plus la charge est forte, plus la tolérance s'adapte légèrement. */
    return {
        level,
        warnMin:18 + level*2,
        lateMin:30 + level*3,
        forgetMin:12 + level*2,
        readyWarningMin:4 + Math.min(level,3)
    };
}

function arOrders(){
    let all={};
    try{
        if(typeof activeOrders!=="undefined" && activeOrders){
            all=activeOrders;
        }
    }catch(_){}

    const now=Date.now();
    const th=arThresholds();
    const result=[];

    for(const [tableId,order] of Object.entries(all||{})){
        if(!tableId || META_KEYS.test(tableId)) continue;
        if(!order || typeof order!=="object") continue;

        try{
            if(typeof isRealServiceOrder==="function" && !isRealServiceOrder(tableId,order)){
                continue;
            }
        }catch(_){}

        const items=arItems(order);
        if(!items.length) continue;

        if(items.every(arServed)) continue;

        const start=arOrderStart(order,items);
        const age=Math.max(0,now-start);
        const last=arLastEvolution(order,items,start);
        const idle=Math.max(0,now-last);
        const readyItems=items.filter(arReady);
        const readyQty=readyItems.reduce((s,i)=>s+Math.max(1,Number(i.qty??i.quantity??1)||1),0);
        const readyAt=arReadySince(items);
        const readyWait=readyAt?Math.max(0,now-readyAt):0;
        const hasSent=items.some(arSent);

        let kind="good";
        let label="DANS LES TEMPS";
        let detail="Service normal";
        let priority=0;

        if(readyQty>0){
            kind="serve";
            label="À SERVIR";
            detail=readyQty+" plat"+(readyQty>1?"s":"")+" prêt"+(readyQty>1?"s":"")+" à récupérer";
            priority=5000000000 + readyWait;
        }else if(age >= th.lateMin*60000){
            kind="late";
            label="RETARD SERVICE";
            detail="Délai dépassé";
            priority=4000000000 + age;
        }else if(hasSent && idle >= th.forgetMin*60000){
            kind="forgot";
            label="OUBLI POSSIBLE";
            detail="Aucune évolution depuis "+arFmt(idle);
            priority=3000000000 + idle;
        }else if(age >= th.warnMin*60000){
            kind="watch";
            label="À SURVEILLER";
            detail="Approche du délai limite";
            priority=2000000000 + age;
        }

        const kitchenDurations=[];
        const serviceDurations=[];

        items.forEach(i=>{
            const sent=arTs(i.sentAt ?? i.productionStartedAt ?? i.startedAt);
            const ready=arTs(i.readyAt ?? i.productionReadyAt);
            const picked=arTs(i.pickedAt ?? i.pickedAtServer);

            if(sent){
                const end=ready || (arSent(i)&&!arServed(i)?now:null);
                if(end && end>=sent) kitchenDurations.push(end-sent);
            }

            if(ready){
                const end=picked || (arReady(i)?now:null);
                if(end && end>=ready) serviceDurations.push(end-ready);
            }
        });

        result.push({
            tableId:String(tableId),
            order,
            items,
            pax:arPax(order),
            start,
            age,
            idle,
            readyQty,
            readyAt,
            readyWait,
            kind,
            label,
            detail,
            priority,
            kitchenDurations,
            serviceDurations
        });
    }

    return result.sort((a,b)=>b.priority-a.priority || a.start-b.start);
}

function arLevelText(level){
    return ["CALME","NORMAL","ACTIF","TENDU","ÉLEVÉ","CRITIQUE"][level] || "CALME";
}

function arColor(kind){
    return {
        serve:"#f4d500",
        watch:"#ff9800",
        late:"#ef4444",
        forgot:"#9b5de5",
        good:"#27c957"
    }[kind] || "#777";
}

function arIcon(kind){
    return {
        serve:"🔔",
        watch:"◉",
        late:"◷",
        forgot:"?",
        good:"✓"
    }[kind] || "•";
}

function arEsc(s){
    return String(s==null?"":s)
        .replace(/&/g,"&amp;")
        .replace(/</g,"&lt;")
        .replace(/>/g,"&gt;")
        .replace(/"/g,"&quot;");
}

function arBuild(){
    let panel=document.getElementById("anti-rush-server-panel");

    if(panel){
        panel.remove();
    }

    panel=document.createElement("section");
    panel.id="anti-rush-server-panel";
    panel.className="ichef-ar-window";
    panel.setAttribute("aria-hidden","true");

    panel.innerHTML=`
        <div class="ichef-ar-head">
            <div class="ichef-ar-title">
                <span class="bolt">⚡</span>
                <span>ANTI-RUSH</span>
            </div>
            <div id="ichef-ar-level" class="ichef-ar-level">NIVEAU 0 · CALME</div>
            <div id="ichef-ar-meter" class="ichef-ar-meter">
                <i></i><i></i><i></i><i></i><i></i><i></i>
            </div>
            <button type="button" class="ichef-ar-close" id="ichef-ar-close">FERMER ×</button>
        </div>

        <div id="ichef-ar-summary-view" class="ichef-ar-scroll">
            <div class="ichef-ar-kpis">
                <div class="ichef-ar-kpi serve">
                    <small>À SERVIR</small>
                    <strong id="ichef-ar-count-serve">0</strong>
                    <span>tables</span>
                </div>
                <div class="ichef-ar-kpi watch">
                    <small>À SURVEILLER</small>
                    <strong id="ichef-ar-count-watch">0</strong>
                    <span>tables</span>
                </div>
                <div class="ichef-ar-kpi late">
                    <small>RETARD SERVICE</small>
                    <strong id="ichef-ar-count-late">0</strong>
                    <span>tables</span>
                </div>
                <div class="ichef-ar-kpi forgot">
                    <small>OUBLI POSSIBLE</small>
                    <strong id="ichef-ar-count-forgot">0</strong>
                    <span>tables</span>
                </div>
                <div class="ichef-ar-kpi good">
                    <small>DANS LES TEMPS</small>
                    <strong id="ichef-ar-count-good">0</strong>
                    <span>tables</span>
                </div>
            </div>

            <div class="ichef-ar-row">
                <div class="ichef-ar-box">
                    <div class="ichef-ar-box-title">TEMPS MOYENS ACTUELS</div>
                    <div class="ichef-ar-averages">
                        <div class="ichef-ar-avg"><span>CUISINE</span><strong id="ichef-ar-avg-kitchen">00:00</strong></div>
                        <div class="ichef-ar-avg"><span>SERVICE</span><strong id="ichef-ar-avg-service">00:00</strong></div>
                        <div class="ichef-ar-avg"><span>TABLE</span><strong id="ichef-ar-avg-table">00:00</strong></div>
                        <div class="ichef-ar-avg"><span>ATTENTE MOY.</span><strong id="ichef-ar-avg-wait">00:00</strong></div>
                    </div>
                </div>

                <div class="ichef-ar-box">
                    <div class="ichef-ar-box-title">RÉPARTITION DES TABLES</div>
                    <div class="ichef-ar-distribution">
                        <div id="ichef-ar-donut">
                            <div id="ichef-ar-donut-center">
                                <strong id="ichef-ar-total">0</strong>
                                <span>tables actives</span>
                            </div>
                        </div>
                        <div id="ichef-ar-legend" class="ichef-ar-legend"></div>
                    </div>
                </div>
            </div>

            <div class="ichef-ar-row">
                <div class="ichef-ar-box ichef-ar-priority-box">
                    <div class="ichef-ar-box-title">TABLES À TRAITER EN PRIORITÉ</div>
                    <div id="ichef-ar-priority-list" class="ichef-ar-list"></div>
                    <div class="ichef-ar-actions">
                        <button type="button" class="ichef-ar-action" id="ichef-ar-close-view">◉ VOIR LES TABLES</button>
                        <button type="button" class="ichef-ar-action" id="ichef-ar-refresh">↻ ACTUALISER</button>
                        <button type="button" class="ichef-ar-action" id="ichef-ar-full">⚙ COCKPIT COMPLET</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="ichef-ar-full-view">
            <div class="ichef-ar-framebar">
                <button type="button" id="ichef-ar-back-summary">← RETOUR AU RÉSUMÉ</button>
                <span style="font-size:.62rem;color:#999">anti-rush.html · même tenant · données serveur temps réel</span>
            </div>
            <iframe id="ichef-ar-iframe" title="Cockpit Anti-Rush complet"></iframe>
        </div>
    `;

    document.body.appendChild(panel);

    panel.querySelector("#ichef-ar-close")?.addEventListener("click",()=>arToggle(false));
    panel.querySelector("#ichef-ar-close-view")?.addEventListener("click",()=>arToggle(false));
    panel.querySelector("#ichef-ar-refresh")?.addEventListener("click",arRefresh);
    panel.querySelector("#ichef-ar-full")?.addEventListener("click",arOpenFull);
    panel.querySelector("#ichef-ar-back-summary")?.addEventListener("click",arBackSummary);

    panel.addEventListener("click",e=>{
        const btn=e.target.closest("[data-ar-table]");
        if(!btn) return;
        arOpenTable(btn.getAttribute("data-ar-table"));
    });

    return panel;
}

function arListHtml(rows,max=6){
    if(!rows.length){
        return `<div style="padding:18px;text-align:center;color:#7f898b;font-size:.65rem">Aucune alerte actuellement.</div>`;
    }

    return rows.slice(0,max).map(r=>{
        let timing="";
        if(r.kind==="serve"){
            timing="depuis "+arFmt(r.readyWait);
        }else if(r.kind==="forgot"){
            timing="("+arFmt(r.idle)+")";
        }else{
            timing="("+arFmt(r.age)+")";
        }

        return `
        <div class="ichef-ar-item ${r.kind}">
            <div class="ichef-ar-item-icon">${arIcon(r.kind)}</div>
            <div class="ichef-ar-item-table">${arEsc(r.tableId)}</div>
            <div class="ichef-ar-item-main">
                <strong>${arEsc(r.label)} <span style="color:${arColor(r.kind)}">${arEsc(timing)}</span></strong>
                <span>${arEsc(r.detail)} · ${r.pax} couvert${r.pax>1?"s":""}</span>
            </div>
            <button type="button" data-ar-table="${arEsc(r.tableId)}">VOIR</button>
        </div>`;
    }).join("");
}

let __ichefArRefreshBusy=false;
let __ichefArRefreshQueued=false;

function arRefresh(){
    if(__ichefArRefreshBusy){
        __ichefArRefreshQueued=true;
        return;
    }

    const panel=document.getElementById("anti-rush-server-panel");
    if(!panel?.classList.contains("open")) return;

    __ichefArRefreshBusy=true;

    try{
    const rows=arOrders();
    const level=arRushLevel();

    const counts={
        serve:rows.filter(r=>r.kind==="serve").length,
        watch:rows.filter(r=>r.kind==="watch").length,
        late:rows.filter(r=>r.kind==="late").length,
        forgot:rows.filter(r=>r.kind==="forgot").length,
        good:rows.filter(r=>r.kind==="good").length
    };

    const set=(id,v)=>{
        const el=document.getElementById(id);
        if(el && el.textContent!==String(v)) el.textContent=String(v);
    };

    set("ichef-ar-count-serve",counts.serve);
    set("ichef-ar-count-watch",counts.watch);
    set("ichef-ar-count-late",counts.late);
    set("ichef-ar-count-forgot",counts.forgot);
    set("ichef-ar-count-good",counts.good);
    set("ichef-ar-total",rows.length);

    const levelEl=document.getElementById("ichef-ar-level");
    if(levelEl){
        levelEl.textContent=`NIVEAU ${level} · ${arLevelText(level)}`;
        levelEl.style.background =
            level>=4 ? "rgba(190,35,35,.78)" :
            level===3 ? "rgba(199,91,15,.78)" :
            level===2 ? "rgba(177,135,8,.76)" :
            "rgba(30,120,60,.68)";
        levelEl.style.borderColor =
            level>=4 ? "rgba(255,80,80,.55)" :
            level>=2 ? "rgba(255,183,46,.45)" :
            "rgba(70,220,110,.38)";
    }

    document.querySelectorAll("#ichef-ar-meter i").forEach((el,idx)=>{
        el.classList.toggle("on",idx<=level);
    });

    const kitchen=rows.flatMap(r=>r.kitchenDurations);
    const service=rows.flatMap(r=>r.serviceDurations);
    const tableAges=rows.map(r=>r.age);
    const waits=rows.filter(r=>r.readyQty>0).map(r=>r.readyWait);

    set("ichef-ar-avg-kitchen",arFmt(arAvg(kitchen)));
    set("ichef-ar-avg-service",arFmt(arAvg(service)));
    set("ichef-ar-avg-table",arFmt(arAvg(tableAges)));
    set("ichef-ar-avg-wait",arFmt(arAvg(waits)));

    const total=Math.max(1,rows.length);
    const order=[
        ["serve",counts.serve],
        ["watch",counts.watch],
        ["late",counts.late],
        ["forgot",counts.forgot],
        ["good",counts.good]
    ];

    let cursor=0;
    const parts=[];
    order.forEach(([kind,count])=>{
        if(!count) return;
        const next=cursor+(count/total)*100;
        parts.push(`${arColor(kind)} ${cursor.toFixed(2)}% ${next.toFixed(2)}%`);
        cursor=next;
    });

    const donut=document.getElementById("ichef-ar-donut");
    if(donut){
        donut.style.background=parts.length
            ? `conic-gradient(${parts.join(",")})`
            : "#24292a";
    }

    const labels={
        serve:"À SERVIR",
        watch:"À SURVEILLER",
        late:"RETARD SERVICE",
        forgot:"OUBLI POSSIBLE",
        good:"DANS LES TEMPS"
    };

    const legend=document.getElementById("ichef-ar-legend");
    if(legend){
        legend.innerHTML=order.map(([kind,count])=>{
            const pct=rows.length?Math.round(count/rows.length*100):0;
            return `<div>
                <span class="ichef-ar-dot" style="background:${arColor(kind)}"></span>
                <span>${labels[kind]}</span>
                <strong>${count} (${pct}%)</strong>
            </div>`;
        }).join("");
    }

    /* Une table = une seule ligne dans le résumé Anti-Rush. */
    const seenPriority=new Set();
    const priority=rows.filter(r=>{
        if(r.kind==="good") return false;
        const key=String(r.tableId||"").trim().toUpperCase();
        if(!key || seenPriority.has(key)) return false;
        seenPriority.add(key);
        return true;
    });

    const p=document.getElementById("ichef-ar-priority-list");
    if(p) p.innerHTML=arListHtml(priority,10);

    }finally{
        __ichefArRefreshBusy=false;
        if(__ichefArRefreshQueued){
            __ichefArRefreshQueued=false;
            requestAnimationFrame(arRefresh);
        }
    }
}

function arOpenTable(tableId){
    if(!tableId) return;

    try{
        if(typeof handleTableOrderTap==="function"){
            handleTableOrderTap(tableId,tableId);
        }else if(typeof openOrder==="function"){
            openOrder(tableId);
        }
    }catch(err){
        console.warn("[iCHEF] Anti-Rush ouvrir table:",err);
    }

    /* La fenêtre reste ouverte : on garde l'Anti-Rush au centre
       et le ticket de la table apparaît à droite. */
    setTimeout(arRefresh,120);
}

function arOpenFull(){
    const summary=document.getElementById("ichef-ar-summary-view");
    const full=document.getElementById("ichef-ar-full-view");
    const frame=document.getElementById("ichef-ar-iframe");

    if(summary) summary.classList.add("hidden");
    if(full) full.classList.add("open");

    if(frame && !frame.getAttribute("src")){
        let tenant="";
        try{
            tenant=String(
                (typeof appTenantID!=="undefined" && appTenantID) ||
                window.appTenantID ||
                ""
            );
        }catch(_){}

        frame.src="anti-rush.html?tenantID="+encodeURIComponent(tenant)+"&embed=1";
    }
}

function arBackSummary(){
    document.getElementById("ichef-ar-summary-view")?.classList.remove("hidden");
    document.getElementById("ichef-ar-full-view")?.classList.remove("open");
    arRefresh();
}

function arToggle(force){
    let panel=document.getElementById("anti-rush-server-panel");
    if(!panel || !panel.classList.contains("ichef-ar-window")){
        panel=arBuild();
    }

    const open=typeof force==="boolean"
        ? force
        : !panel.classList.contains("open");

    panel.classList.toggle("open",open);
    panel.setAttribute("aria-hidden",open?"false":"true");

    const btn=document.getElementById("btn-anti-rush-panel");

    btn?.classList.toggle("ichef-ar-button-open",open);

    const drawerBtn=document.getElementById("ichef-anti-rush-drawer-btn");
    if(drawerBtn){
        drawerBtn.classList.toggle("active",open);
    }

    /*
      IMPORTANT :
      ne plus écrire "ANTI-RUSH" / "FERMER ANTI-RUSH" ici.
      Le moteur LIVE est seul responsable du texte du bouton.
    */
    setTimeout(()=>{
        if(typeof window.ichefUpdateAntiRushSignal==="function"){
            window.ichefUpdateAntiRushSignal(true);
        }
    },0);

    if(open){
        arBackSummary();
        arRefresh();

        if(arTimer) clearInterval(arTimer);
        arTimer=setInterval(()=>{
            if(document.hidden) return;
            const p=document.getElementById("anti-rush-server-panel");
            if(p?.classList.contains("open")) arRefresh();
        },2000);
    }else{
        if(arTimer){
            clearInterval(arTimer);
            arTimer=null;
        }
    }
}

/* Remplace l'ancien petit panneau Anti-Rush par la vraie fenêtre. */
window.toggleAntiRushPanel=function(){
    arToggle();
};

window.updateAntiRushServerPanel=function(){
    arRefresh();
};

window.ichefRefreshAntiRushWindow=arRefresh;

document.addEventListener("keydown",e=>{
    if(e.key==="Escape"){
        const panel=document.getElementById("anti-rush-server-panel");
        if(panel?.classList.contains("open")) arToggle(false);
    }
});

function arInit(){
    const btn=document.getElementById("btn-anti-rush-panel");
    if(btn){
        btn.title="Ouvrir / fermer la fenêtre Anti-Rush";
    }
}

/* Le serveur met déjà à jour activeOrders/currentRushLevel.
   La fenêtre lit ces mêmes données : aucune duplication de commandes. */
if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",arInit,{once:true});
}else{
    arInit();
}

})();
