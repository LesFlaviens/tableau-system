(function(){
    "use strict";

    const HOLD_MS = 900;
    const MOVE_LIMIT = 14;
    let timer = null;
    let pointerId = null;
    let startX = 0, startY = 0;
    let fired = false;
    let suppressClickUntil = 0;

    function list(){ return document.getElementById('ticket-list'); }

    function cancel(){
        if(timer){ clearTimeout(timer); timer=null; }
        const el=list();
        if(el) el.classList.remove('ichef-white-hold-armed');
        pointerId=null;
    }

    function toggle(){
        const el=list();
        if(!el) return;
        const opening=!el.classList.contains('ichef-white-fullscreen');
        el.classList.toggle('ichef-white-fullscreen', opening);
        document.body.classList.toggle('ichef-white-fullscreen-open', opening);
        // Remet le scroll en haut uniquement lors de l'ouverture si nécessaire.
        if(opening && el.scrollTop < 0) el.scrollTop=0;
    }

    function onDown(e){
        const el=list();
        if(!el || e.button>0) return;
        // Ne pas démarrer sur un contrôle interactif pour conserver les boutons normaux.
        if(e.target.closest('button,input,select,textarea,a,[role="button"]')) return;
        fired=false;
        pointerId=e.pointerId;
        startX=e.clientX; startY=e.clientY;
        el.classList.add('ichef-white-hold-armed');
        timer=setTimeout(function(){
            timer=null;
            fired=true;
            suppressClickUntil=Date.now()+550;
            el.classList.remove('ichef-white-hold-armed');
            toggle();
            try{ navigator.vibrate && navigator.vibrate(22); }catch(_){}
        },HOLD_MS);
    }

    function onMove(e){
        if(pointerId===null || e.pointerId!==pointerId || !timer) return;
        const dx=e.clientX-startX, dy=e.clientY-startY;
        if(Math.hypot(dx,dy)>MOVE_LIMIT) cancel();
    }

    function onEnd(e){
        if(pointerId!==null && e.pointerId===pointerId) cancel();
    }

    function install(){
        const el=list();
        if(!el || el.dataset.whiteFullscreenReady==='1') return;
        el.dataset.whiteFullscreenReady='1';
        el.addEventListener('pointerdown',onDown,{passive:true});
        el.addEventListener('pointermove',onMove,{passive:true});
        el.addEventListener('pointerup',onEnd,{passive:true});
        el.addEventListener('pointercancel',onEnd,{passive:true});
        el.addEventListener('pointerleave',function(e){ if(e.pointerType==='mouse') onEnd(e); },{passive:true});
        el.addEventListener('click',function(e){
            if(fired || Date.now()<suppressClickUntil){
                e.preventDefault();
                e.stopPropagation();
                fired=false;
            }
        },true);
    }

    function boot(){
        install();
        const drawer=document.getElementById('order-drawer');
        if(drawer){
            new MutationObserver(function(){ requestAnimationFrame(install); })
              .observe(drawer,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
        }
        setTimeout(install,300);
        setTimeout(install,900);
    }

    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
    else boot();
})();
