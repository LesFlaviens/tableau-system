(function(){
'use strict';
if(window.__ICHEF_DISH_DELAY_ALERT_V1__) return;
window.__ICHEF_DISH_DELAY_ALERT_V1__=true;

const BASE_WARNING_MIN=15;
const BASE_CRITICAL_MIN=25;
const REFRESH_MS=5000;
let latestAlerts=[];
let lastCriticalSignature='';
let latestTimerConfig=null;

/* =========================================================
   TIMER PLATS ↔ ANTI-RUSH
   Le niveau Anti-Rush devient la référence du chrono.
   N0 : 15/25 min · N1 : 15/25 · N2 : 18/28
   N3 : 20/30 · N4 : 25/35 · N5 : 30/40
   ========================================================= */
function getAntiRushTimerConfig(){
  let snap=null;
  try{
    if(typeof window.ichefGetAntiRushLiveSnapshot==='function'){
      snap=window.ichefGetAntiRushLiveSnapshot();
    }else{
      snap=window.__ichefAntiRushLiveSnapshot||null;
    }
  }catch(_){ snap=window.__ichefAntiRushLiveSnapshot||null; }

  let level=Number(snap?.level)||0;
  try{ level=Math.max(level,Number(window.__ichefAntiRushLiveLevel)||0); }catch(_){}
  try{ level=Math.max(level,Number(window.systemSettings?.rushLevel)||0); }catch(_){}
  try{ if(typeof currentRushLevel!=='undefined') level=Math.max(level,Number(currentRushLevel)||0); }catch(_){}
  level=Math.max(0,Math.min(5,Math.round(level)));

  const warningByLevel=[15,15,18,20,25,30];
  const criticalByLevel=[25,25,28,30,35,40];
  const stateByLevel=['CALME','VIGILANCE','ACTIF','TENDU','ÉLEVÉ','CRITIQUE'];

  const cfg={
    level,
    state:String(snap?.state||stateByLevel[level]||'CALME'),
    warningMin:warningByLevel[level] ?? BASE_WARNING_MIN,
    criticalMin:criticalByLevel[level] ?? BASE_CRITICAL_MIN,
    cuisine:Number(snap?.cuisine)||0,
    bar:Number(snap?.bar)||0,
    pass:Number(snap?.pass)||0,
    maxLoad:Number(snap?.maxLoad)||0,
    activeTables:Number(snap?.activeTables)||0,
    updatedAt:Date.now()
  };
  latestTimerConfig=cfg;
  return cfg;
}

function syncTimerToAntiRushUI(cfg){
  if(!cfg) return;
  let chip=document.getElementById('ichef-ar-dish-timer-chip');
  const panel=document.getElementById('anti-rush-server-panel');
  if(panel && !chip){
    chip=document.createElement('div');
    chip.id='ichef-ar-dish-timer-chip';
    chip.style.cssText='margin:8px 12px;padding:7px 10px;border:1px solid rgba(197,160,89,.42);border-radius:7px;background:rgba(197,160,89,.07);color:#fff;font-size:.66rem;font-weight:850;letter-spacing:.35px;text-align:center;';
    const target=panel.querySelector('.ichef-ar-head,.ichef-ar-framebar,.anti-rush-server-content')||panel.firstElementChild||panel;
    try{ target.appendChild(chip); }catch(_){}
  }
  if(chip){
    chip.textContent=`⏱ TIMER PLATS · ANTI-RUSH N${cfg.level} ${cfg.state} · ALERTE ${cfg.warningMin} min · CRITIQUE ${cfg.criticalMin} min`;
    chip.style.borderColor=cfg.level>=4?'rgba(239,68,68,.7)':cfg.level>=2?'rgba(245,158,11,.65)':'rgba(16,185,129,.55)';
  }

  /* Prépare aussi la synchronisation vers anti-rush.html lorsqu'il est ouvert en iframe. */
  try{
    const frame=document.getElementById('ichef-ar-iframe');
    if(frame?.contentWindow){
      frame.contentWindow.postMessage({
        type:'ICHEF_DISH_TIMER_SYNC',
        source:'pad',
        tenantID:String(window.appTenantID||localStorage.getItem('ichef_tenant_id')||''),
        timer:cfg,
        alerts:latestAlerts.map(a=>({table:a.label,name:a.name,minutes:Math.floor(a.minutes),level:a.level}))
      },window.location.origin);
    }
  }catch(_){}
}

const banner=document.getElementById('ichef-dish-delay-global');
const bannerTitle=document.getElementById('ichef-dish-delay-title');
const bannerSub=document.getElementById('ichef-dish-delay-sub');
const bannerCount=document.getElementById('ichef-dish-delay-count');

function norm(v){return String(v??'').trim().toLowerCase().replace(/[^a-z0-9]/g,'');}
function esc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function itemName(i){return String(i?.originalName??i?.n??i?.name??i?.label??i?.title??'Article').replace(/\[BR\]/g,' ').trim();}
function qty(i){const q=Number(i?.qty??i?.quantity??1);return Number.isFinite(q)&&q>0?q:1;}
function isCancelled(i){
  if(!i) return true;
  if(i.cancelled===true||i.canceled===true||i.deleted===true||i.voided===true||i.removed===true) return true;
  const s=String(i.status??i.sequenceStatus??'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  return /CANCEL|ANNULE|VOID|SUPPRIM|REMOVED|DELETED/.test(s);
}
function isReadyOrServed(i){
  if(i?.served===true||i?.done===true) return true;
  const s=String(i?.status??i?.sequenceStatus??'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  return /READY|PRET|SERVI|SERVED/.test(s);
}
function isInKitchen(i){
  if(!i||isCancelled(i)||isReadyOrServed(i)) return false;
  const s=String(i.status??i.sequenceStatus??'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  if(/WAITING|DRAFT|NON ENVOYE|NON_ENVOYE/.test(s) && i.isSent!==true) return false;
  return i.isSent===true || /PRODUCTION|CUISINE|SENT|ENVOYE/.test(s);
}
function toMs(v){
  if(v==null||v==='') return 0;
  if(typeof v==='number' && Number.isFinite(v)){
    if(v>1e12) return v;
    if(v>1e9) return v*1000;
    return 0;
  }
  const s=String(v).trim();
  if(/^\d{13,}$/.test(s)) return Number(s.slice(0,13));
  if(/^\d{10}$/.test(s)) return Number(s)*1000;
  const d=Date.parse(s);
  return Number.isFinite(d)?d:0;
}
function sentAt(i){
  return toMs(i?.kitchenSentAt)||toMs(i?.sentToKitchenAt)||toMs(i?.sentAt)||toMs(i?.requestedAt)||toMs(i?.productionStartedAt)||toMs(i?.itemId);
}
function orderEntries(){
  try{
    if(typeof activeOrders==='undefined'||!activeOrders) return [];
    return Object.entries(activeOrders);
  }catch(_){return [];}
}
function labelFor(key,order){
  return String(order?.tableLabel??order?.tableId??order?.table??order?.tableNumber??key??'').replace(/^table\s*/i,'').trim();
}
function collectAlerts(){
  const now=Date.now();
  try{ if(typeof window.ichefUpdateAntiRushSignal==='function') window.ichefUpdateAntiRushSignal(); }catch(_){}
  const timerCfg=getAntiRushTimerConfig();
  const out=[];
  orderEntries().forEach(([key,order])=>{
    if(!order||!Array.isArray(order.items)) return;
    const label=labelFor(key,order);
    order.items.forEach((item,index)=>{
      if(!isInKitchen(item)) return;
      const start=sentAt(item);
      if(!start||start>now) return;
      const minutes=(now-start)/60000;
      if(minutes<timerCfg.warningMin) return;
      out.push({
        key,label,item,index,minutes,
        level:minutes>=timerCfg.criticalMin?'critical':'warning',
        name:itemName(item),qty:qty(item),
        warningMin:timerCfg.warningMin,
        criticalMin:timerCfg.criticalMin,
        rushLevel:timerCfg.level,
        rushState:timerCfg.state,
        rushMaxLoad:timerCfg.maxLoad
      });
    });
  });
  out.sort((a,b)=>b.minutes-a.minutes);
  return out;
}
function findTableAlert(label){
  const n=norm(label);
  return latestAlerts.find(a=>norm(a.label)===n)||null;
}
function clearTableMarks(){
  document.querySelectorAll('.pro-table-card.ichef-dish-delay-warning,.pro-table-card.ichef-dish-delay-critical,#floor-plan .table-obj.ichef-dish-delay-warning,#floor-plan .table-obj.ichef-dish-delay-critical').forEach(el=>{
    el.classList.remove('ichef-dish-delay-warning','ichef-dish-delay-critical');
  });
  document.querySelectorAll('.ichef-dish-delay-badge').forEach(el=>el.remove());
}
function badgeFor(alert){
  const b=document.createElement('div');
  b.className=`ichef-dish-delay-badge ${alert.level}`;
  b.textContent=alert.level==='critical'?`⚠ ${Math.floor(alert.minutes)} min`:`⏱ ${Math.floor(alert.minutes)} min`;
  return b;
}
function markElement(el,alert){
  if(!el||!alert) return;
  el.classList.add(alert.level==='critical'?'ichef-dish-delay-critical':'ichef-dish-delay-warning');
  el.appendChild(badgeFor(alert));
}
function markTables(){
  clearTableMarks();
  const byTable=new Map();
  latestAlerts.forEach(a=>{
    const n=norm(a.label);
    const old=byTable.get(n);
    if(!old||a.minutes>old.minutes) byTable.set(n,a);
  });
  document.querySelectorAll('#pro-table-grid .pro-table-card[data-table]').forEach(card=>{
    const a=byTable.get(norm(card.dataset.table));
    if(a) markElement(card,a);
  });
  document.querySelectorAll('#floor-plan .table-wrapper').forEach(w=>{
    const label=w.dataset.id??w.dataset.table??w.dataset.label??'';
    const a=byTable.get(norm(label));
    const obj=w.querySelector('.table-obj');
    if(a&&obj) markElement(obj,a);
  });
}
function updateBanner(){
  if(!banner) return;
  if(!latestAlerts.length){
    banner.classList.remove('show','critical');
    banner.removeAttribute('data-table');
    return;
  }
  const worst=latestAlerts[0];
  const criticalCount=latestAlerts.filter(a=>a.level==='critical').length;
  banner.classList.toggle('critical',worst.level==='critical');
  banner.dataset.table=worst.label;
  bannerTitle.textContent=worst.level==='critical'?'⚠️ RETARD CRITIQUE CUISINE':'⏱ ATTENTION CUISINE';
  bannerSub.textContent=`Table ${worst.label} · ${worst.qty>1?worst.qty+'× ':''}${worst.name} · ${Math.floor(worst.minutes)} min · Anti-Rush N${worst.rushLevel} ${worst.rushState}${latestAlerts.length>1?' · +'+(latestAlerts.length-1)+' autre(s)':''}`;
  bannerCount.textContent=String(latestAlerts.length);
  banner.classList.add('show');

  /* Une seule vibration lors du passage à un nouvel état critique. */
  if(criticalCount>0){
    const sig=latestAlerts.filter(a=>a.level==='critical').map(a=>`${norm(a.label)}:${a.index}`).sort().join('|');
    if(sig && sig!==lastCriticalSignature){
      lastCriticalSignature=sig;
      try{navigator.vibrate?.([70,55,70]);}catch(_){ }
    }
  }else lastCriticalSignature='';
}
function decorateDetailModal(){
  const overlay=document.getElementById('ichef-table-detail-overlay');
  if(!overlay?.classList.contains('open')) return;
  const title=document.getElementById('ichef-td-title')?.textContent||'';
  const label=title.replace(/^TABLE\s*/i,'').trim();
  if(!label) return;
  const tableAlerts=latestAlerts.filter(a=>norm(a.label)===norm(label));
  if(!tableAlerts.length) return;
  const rows=Array.from(document.querySelectorAll('#ichef-td-body .ichef-td-item'));
  rows.forEach(row=>{
    row.classList.remove('ichef-detail-delay-warning','ichef-detail-delay-critical');
    row.querySelectorAll('.ichef-td-delay').forEach(x=>x.remove());
    const nameEl=row.querySelector('.ichef-td-item-name');
    if(!nameEl) return;
    const rowName=norm(nameEl.textContent.replace(/^\d+×\s*/,''));
    const match=tableAlerts.find(a=>norm(a.name)===rowName);
    if(!match) return;
    row.classList.add(match.level==='critical'?'ichef-detail-delay-critical':'ichef-detail-delay-warning');
    const d=document.createElement('span');
    d.className=`ichef-td-delay ${match.level}`;
    d.textContent=match.level==='critical'?`⚠ RETARD ${Math.floor(match.minutes)} min`:`⏱ ${Math.floor(match.minutes)} min`;
    nameEl.parentElement?.appendChild(d);
  });
}
function refresh(){
  latestAlerts=collectAlerts();
  markTables();
  updateBanner();
  decorateDetailModal();
  syncTimerToAntiRushUI(latestTimerConfig||getAntiRushTimerConfig());
}

banner?.addEventListener('click',()=>{
  const label=banner.dataset.table||'';
  if(!label) return;
  try{
    if(typeof window.ichefOpenTableDetails==='function') window.ichefOpenTableDetails(label,null);
    else if(typeof handleTableOrderTap==='function') handleTableOrderTap(label,label);
  }catch(err){console.error('iCHEF alerte retard ouverture table',err);}
});

/* Si la fiche est ouverte après l'appui long, ajoute le retard immédiatement. */
document.addEventListener('click',()=>setTimeout(decorateDetailModal,50),true);
document.addEventListener('pointerup',()=>setTimeout(decorateDetailModal,80),true);

window.ichefDishDelayAlert={
  refresh,
  getAlerts:()=>latestAlerts.slice(),
  getTimerConfig:()=>({...getAntiRushTimerConfig()}),
  get warningMinutes(){ return getAntiRushTimerConfig().warningMin; },
  get criticalMinutes(){ return getAntiRushTimerConfig().criticalMin; }
};

/* Si anti-rush.html renvoie un niveau par postMessage, le chrono se recalcule immédiatement. */
window.addEventListener('message',(event)=>{
  if(event.origin!==window.location.origin) return;
  const data=event.data||{};
  if(!['ICHEF_ANTI_RUSH_STATE','ICHEF_ANTI_RUSH_UPDATE','ANTI_RUSH_UPDATE'].includes(String(data.type||''))) return;
  const lvl=Number(data.level??data.rushLevel??data.snapshot?.level);
  if(Number.isFinite(lvl)){
    window.__ichefAntiRushLiveLevel=Math.max(0,Math.min(5,lvl));
    if(data.snapshot&&typeof data.snapshot==='object') window.__ichefAntiRushLiveSnapshot=data.snapshot;
    setTimeout(refresh,20);
  }
});

setTimeout(refresh,600);
setInterval(refresh,REFRESH_MS);
})();
