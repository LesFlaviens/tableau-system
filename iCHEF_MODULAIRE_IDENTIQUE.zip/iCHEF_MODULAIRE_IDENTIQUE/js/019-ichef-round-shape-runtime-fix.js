(function(){
  function applyRealShapes(){
    document.querySelectorAll('.table-wrapper').forEach(function(w){
      var id = w.dataset.tableId || w.getAttribute('data-id');
      var shape = w.dataset.shape || '';
      var obj = w.querySelector('.table-obj');

      // Cherche aussi la forme portée par l'objet lui-même.
      if(!shape && obj) shape = obj.dataset.shape || '';

      // Si le moteur a déjà une classe shape-*, on la respecte.
      if(w.classList.contains('shape-oval') || (obj && obj.classList.contains('shape-oval'))) shape='oval';

      if(shape === 'oval' && obj){
        obj.style.setProperty('border-radius','50%','important');
        obj.style.setProperty('clip-path','none','important');
      }
    });
  }

  // Après chaque rendu du plan.
  const oldRender = window.renderFloor;
  if(typeof oldRender === 'function'){
    window.renderFloor = function(){
      const r = oldRender.apply(this, arguments);
      requestAnimationFrame(applyRealShapes);
      return r;
    };
  }

  document.addEventListener('DOMContentLoaded', applyRealShapes);
  setTimeout(applyRealShapes,300);
  setTimeout(applyRealShapes,1000);
})();
