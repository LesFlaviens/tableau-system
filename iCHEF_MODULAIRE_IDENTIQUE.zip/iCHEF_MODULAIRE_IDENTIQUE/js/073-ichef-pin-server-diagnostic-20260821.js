(function(){
  "use strict";
  try {
    window.ICHEF_PIN_SERVER = (location.hostname === "localhost" || location.hostname === "127.0.0.1")
      ? "http://localhost:10000"
      : "https://tableau-system.onrender.com";
  } catch(_) {}
})();
