(function(){
    "use strict";

    const INNER_STYLE_ID = "ichef-inner-scrollbar-hard-fix";
    const INNER_CSS = `
        html,body{color-scheme:dark!important;scrollbar-width:thin!important;scrollbar-color:rgba(197,160,89,.72) #070909!important}
        *{scrollbar-width:thin!important;scrollbar-color:rgba(197,160,89,.72) #070909!important}
        html::-webkit-scrollbar,body::-webkit-scrollbar,*::-webkit-scrollbar{width:6px!important;height:6px!important;background:#070909!important;-webkit-appearance:none!important}
        html::-webkit-scrollbar-track,body::-webkit-scrollbar-track,*::-webkit-scrollbar-track{background:#070909!important;border:0!important;box-shadow:none!important}
        html::-webkit-scrollbar-thumb,body::-webkit-scrollbar-thumb,*::-webkit-scrollbar-thumb{background:rgba(197,160,89,.72)!important;border:1px solid #070909!important;border-radius:999px!important}
        html::-webkit-scrollbar-button,body::-webkit-scrollbar-button,*::-webkit-scrollbar-button,
        html::-webkit-scrollbar-button:single-button,body::-webkit-scrollbar-button:single-button,*::-webkit-scrollbar-button:single-button,
        html::-webkit-scrollbar-button:vertical:decrement,html::-webkit-scrollbar-button:vertical:increment,
        body::-webkit-scrollbar-button:vertical:decrement,body::-webkit-scrollbar-button:vertical:increment,
        *::-webkit-scrollbar-button:vertical:decrement,*::-webkit-scrollbar-button:vertical:increment{
            width:0!important;height:0!important;min-width:0!important;min-height:0!important;display:none!important;visibility:hidden!important;opacity:0!important;
            border:0!important;padding:0!important;margin:0!important;background:transparent!important;background-image:none!important;-webkit-appearance:none!important
        }
        @media(pointer:coarse){
            html,body,*{scrollbar-width:none!important;-ms-overflow-style:none!important}
            html::-webkit-scrollbar,body::-webkit-scrollbar,*::-webkit-scrollbar{width:0!important;height:0!important;display:none!important}
        }
    `;

    function injectIntoFrame(frame){
        if(!frame) return;
        try{
            const doc = frame.contentDocument || frame.contentWindow?.document;
            if(!doc || !doc.documentElement) return;
            doc.documentElement.style.colorScheme = "dark";
            if(doc.getElementById(INNER_STYLE_ID)) return;
            const style = doc.createElement("style");
            style.id = INNER_STYLE_ID;
            style.textContent = INNER_CSS;
            (doc.head || doc.documentElement).appendChild(style);
        }catch(_){
            /* iframe cross-origin : impossible à styliser depuis le parent */
        }
    }

    function hookFrame(frame){
        if(!frame || frame.dataset.ichefScrollbarHook === "1") return;
        frame.dataset.ichefScrollbarHook = "1";
        frame.addEventListener("load", () => {
            injectIntoFrame(frame);
            setTimeout(() => injectIntoFrame(frame), 120);
        });
        injectIntoFrame(frame);
    }

    function scan(){
        document.querySelectorAll("iframe").forEach(hookFrame);
    }

    scan();
    const obs = new MutationObserver((mutations)=>{
        for(const m of mutations){
            for(const n of m.addedNodes||[]){
                if(n?.nodeType!==1) continue;
                if(n.tagName==='IFRAME' || n.querySelector?.('iframe')){ scan(); return; }
            }
        }
    });
    obs.observe(document.body||document.documentElement, {childList:true, subtree:true});
    setTimeout(scan, 300);
    setTimeout(scan, 1200);
})();
