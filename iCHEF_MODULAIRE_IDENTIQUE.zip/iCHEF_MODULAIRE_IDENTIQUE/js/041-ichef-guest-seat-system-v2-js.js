(function(){
    "use strict";

    function safeInt(v){
        const n=Number(v);
        return Number.isFinite(n) && n>=0 ? Math.floor(n) : 0;
    }

    function normalizeQrGuestFields(item){
        if(!item || typeof item!=="object") return item;

        /* Compatibilité avec différentes formes QR / API */
        if(!safeInt(item.seat)){
            item.seat=safeInt(
                item.guestSeat ??
                item.seatNumber ??
                item.convive ??
                item.person ??
                item.personIndex ??
                item.guestIndex ??
                0
            );
        }

        if(!item.guestName){
            item.guestName=String(
                item.conviveName ??
                item.personName ??
                item.guestName ??
                item.customerName ??
                ""
            ).trim();
        }

        item.guestSeat=safeInt(item.seat);
        item.seatNumber=safeInt(item.seat);

        return item;
    }

    window.ichefNormalizeQrGuestFields=function(order){
        if(!order || typeof order!=="object") return order;
        if(!Array.isArray(order.items)) return order;

        order.items.forEach(normalizeQrGuestFields);
        return order;
    };

    function isQrOrder(order,key){
        return !!(
            order?.isWeb ||
            order?.isQR ||
            String(order?.origin || order?.orderMeta?.origin || "").toUpperCase()==="QR" ||
            /^WEB_|^QR_/i.test(String(key||""))
        );
    }

    function currentOrder(){
        try{
            return activeOrders?.[currentTableId] || null;
        }catch(_){return null}
    }

    function currentPax(){
        let pax=0;

        try{
            const t=(Array.isArray(tables)?tables:[])
                .find(x=>x && String(x.label)===String(currentTableId));
            pax=Number(t?.pax||t?.seats||t?.capacity||0);
        }catch(_){}

        if(!pax){
            try{
                const o=currentOrder();
                pax=Number(
                    o?.pax || o?.covers || o?.guests ||
                    o?.people || o?.reservation?.pax || 0
                );
            }catch(_){}
        }

        if(!pax){
            try{
                const obs=document.getElementById("order-obs")?.value||"";
                const m=obs.match(/🍽️\s*(\d+)\s*Couvert/i);
                if(m)pax=Number(m[1]);
            }catch(_){}
        }

        return Math.max(1,Math.min(50,Math.floor(pax||1)));
    }

    function hasUnassignedItems(){
        const items=Array.isArray(currentTicket)?currentTicket:[];
        return items.some(i=>
            i &&
            String(i.n ?? i.name ?? "").trim() &&
            safeInt(i.seat)===0
        );
    }

    function needsQrAssignment(){
        const o=currentOrder();
        return !!(
            o &&
            isQrOrder(o,currentTableId) &&
            currentPax()>1 &&
            hasUnassignedItems()
        );
    }

    function ensureWhoEatsButton(){
        const ticket=document.querySelector("#order-drawer .ticket-view");
        if(!ticket)return null;

        let btn=document.getElementById("ichef-who-eats-btn");
        if(!btn){
            btn=document.createElement("button");
            btn.type="button";
            btn.id="ichef-who-eats-btn";
            btn.textContent="👥 QUI MANGE QUOI ?";
            btn.onclick=()=>window.ichefOpenGuestAssignment();
            ticket.insertBefore(btn,ticket.firstChild);
        }

        btn.classList.toggle(
            "show",
            needsQrAssignment() || (
                Array.isArray(currentTicket) &&
                currentTicket.length>0 &&
                currentPax()>1
            )
        );

        return btn;
    }

    function guestLabel(item,seat){
        const n=String(item?.guestName||"").trim();
        if(n && safeInt(item?.seat)===seat){
            return `👤︎ ${seat} · ${n}`;
        }
        return `👤︎ ${seat}`;
    }

    function renderAssignment(){
        const list=document.getElementById("ichef-guest-assign-list");
        if(!list)return;

        const pax=currentPax();
        list.replaceChildren();

        (Array.isArray(currentTicket)?currentTicket:[]).forEach((item,idx)=>{
            if(!item)return;
            normalizeQrGuestFields(item);

            const row=document.createElement("div");
            row.className="ichef-guest-item";

            const name=document.createElement("div");
            name.className="ichef-guest-item-name";
            name.textContent=`${Number(item.qty||1)>1?Number(item.qty||1)+"× ":""}${String(item.n||item.name||"Plat")}`;
            row.appendChild(name);

            const buttons=document.createElement("div");
            buttons.className="ichef-guest-seat-buttons";

            const centre=document.createElement("button");
            centre.type="button";
            centre.className="ichef-guest-seat-btn"+(safeInt(item.seat)===0?" active":"");
            centre.textContent="🍽️ CENTRE";
            centre.onclick=()=>{
                item.seat=0;
                item.guestSeat=0;
                item.seatNumber=0;
                renderAssignment();
            };
            buttons.appendChild(centre);

            for(let s=1;s<=pax;s++){
                const b=document.createElement("button");
                b.type="button";
                b.className="ichef-guest-seat-btn ichef-seat-"+s+(safeInt(item.seat)===s?" active":"");
                b.setAttribute("data-ichef-seat",String(s));
                const guestText=String(item?.guestName||"").trim();
                b.replaceChildren();
                const person=document.createElement("span");
                person.className="ichef-seat-person";
                person.setAttribute("aria-hidden","true");
                const seatText=document.createElement("span");
                seatText.textContent=String(s)+(guestText && safeInt(item.seat)===s ? " · "+guestText : "");
                b.append(person,seatText);
                b.onclick=()=>{
                    item.seat=s;
                    item.guestSeat=s;
                    item.seatNumber=s;
                    renderAssignment();
                };
                buttons.appendChild(b);
            }

            row.appendChild(buttons);
            list.appendChild(row);
        });
    }

    window.ichefOpenGuestAssignment=function(){
        if(!Array.isArray(currentTicket) || !currentTicket.length)return;

        renderAssignment();

        const modal=document.getElementById("ichef-guest-assign-modal");
        if(modal){
            modal.classList.add("show");
            modal.setAttribute("aria-hidden","false");
        }
    };

    function closeAssignment(){
        const modal=document.getElementById("ichef-guest-assign-modal");
        if(modal){
            modal.classList.remove("show");
            modal.setAttribute("aria-hidden","true");
        }
    }

    async function saveAssignment(){
        (Array.isArray(currentTicket)?currentTicket:[])
            .forEach(normalizeQrGuestFields);

        try{
            if(typeof renderTicket==="function")renderTicket();
            ensureWhoEatsButton();

            /* Sauvegarde immédiate : Cuisine/KDS reçoit qui mange quoi. */
            if(typeof executeSaveTableState==="function"){
                await executeSaveTableState(false,true);
            }

            if(typeof showToast==="function"){
                showToast("👥 Répartition des convives enregistrée");
            }

            closeAssignment();
        }catch(err){
            console.warn("[iCHEF] Répartition convives :",err);
        }
    }

    document.getElementById("ichef-guest-assign-close")
        ?.addEventListener("click",closeAssignment);

    document.getElementById("ichef-guest-assign-save")
        ?.addEventListener("click",saveAssignment);

    /* Expose pour les autres écrans/KDS. */
    window.ichefSeatLabel=function(item){
        const seat=safeInt(item?.seat);
        const name=String(item?.guestName||"").trim();

        if(seat>0){
            return name ? `Convive ${seat} · ${name}` : `Convive ${seat}`;
        }
        return "Centre table";
    };

    function refresh(){
        try{
            if(Array.isArray(currentTicket)){
                currentTicket.forEach(normalizeQrGuestFields);
            }
            ensureWhoEatsButton();
        }catch(_){}
    }

    document.addEventListener("DOMContentLoaded",refresh,{once:true});
    setInterval(()=>{
        const drawer=document.getElementById("order-drawer");
        if(drawer?.classList.contains("open"))refresh();
    },1500);
})();
