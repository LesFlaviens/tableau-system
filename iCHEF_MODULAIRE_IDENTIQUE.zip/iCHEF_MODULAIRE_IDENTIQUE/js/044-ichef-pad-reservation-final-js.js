(function(){
'use strict';

const clicks=new WeakMap();
let openedReservation=null;

function norm(v){
  return String(v||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').trim().toLowerCase();
}
function getReservations(){
  try{return Array.isArray(reservationsData)?reservationsData:[]}catch(_){return[]}
}
function isActive(r){
  return !['rejected','cancelled','canceled','annule','annulee','completed','done','noshow','no show']
    .includes(norm(r?.status||r?.reservationStatus));
}
function tableOf(r){return String(r?.assignedTable||r?.tableId||r?.table||'').trim()}
function wrapperLabel(w){
  const o=w?.querySelector('.table-obj');
  /* Le plan crée les tables avec data-id=t.label.
     Utiliser data-id en priorité évite qu'un aperçu de plat modifie textContent
     et fasse perdre temporairement la réservation / le point d'état. */
  return String(
    w?.dataset?.id ||
    w?.getAttribute?.('data-id') ||
    w?.dataset?.label ||
    w?.dataset?.table ||
    o?.dataset?.id ||
    o?.dataset?.label ||
    o?.dataset?.table ||
    (o?.querySelector?.('.table-content > span')?.textContent || '') ||
    ''
  ).trim();
}
function reservationFor(label){
  const now=Date.now();
  return getReservations()
    .filter(r=>r&&isActive(r)&&tableOf(r)===String(label))
    .sort((a,b)=>{
      const da=Date.parse(`${a.date||''}T${a.time||'00:00'}`)||0;
      const db=Date.parse(`${b.date||''}T${b.time||'00:00'}`)||0;
      return Math.abs(da-now)-Math.abs(db-now);
    })[0]||null;
}
function stateClass(r){
  const s=norm(r?.status||r?.reservationStatus);
  if(['arrived','arrive','seated','installed','installe'].includes(s))return'arrived';
  const ts=Date.parse(`${r?.date||''}T${r?.time||'00:00'}`);
  if(Number.isFinite(ts)){
    const d=ts-Date.now();
    if(d < -15*60000)return'late';
    if(d <= 30*60000 && d >= -15*60000)return'soon';
  }
  return'reserved';
}
function refreshDots(){
  document.querySelectorAll('.table-wrapper').forEach(w=>{
    const tableObj=w.querySelector('.table-obj');
    if(!tableObj)return;

    const r=reservationFor(wrapperLabel(w));
    const dots=[...tableObj.querySelectorAll(':scope > .ichef-pad-res-dot')];

    if(!r){
      /* On retire le point uniquement si la table n'a réellement plus de réservation. */
      dots.forEach(x=>x.remove());
      return;
    }

    /* Réutilise le même nœud au lieu de le supprimer/recréer à chaque refresh.
       Cela supprime le flash visuel qui ressemblait à un clignotement. */
    let dot=dots.shift() || document.createElement('span');
    dots.forEach(x=>x.remove());

    const wanted='ichef-pad-res-dot '+stateClass(r);
    if(dot.className!==wanted) dot.className=wanted;
    dot.setAttribute('aria-hidden','true');
    dot.title='Réservation';

    if(dot.parentNode!==tableObj){
      tableObj.appendChild(dot);
    }
  });
}
function setText(id,v){const e=document.getElementById(id);if(e)e.textContent=(v===undefined||v===null||v==='')?'—':String(v)}
function openModal(r){
  openedReservation=r;
  setText('ichef-pad-res-name',r?.name||r?.clientName);
  setText('ichef-pad-res-phone',r?.phone||r?.telephone);
  setText('ichef-pad-res-time',r?.time);
  setText('ichef-pad-res-pax',Number(r?.couverts||r?.pax||r?.personnes||1));
  setText('ichef-pad-res-table',tableOf(r));
  setText('ichef-pad-res-pref',r?.obs||r?.observations||r?.preferences||'Aucune');
  const m=document.getElementById('ichef-pad-reservation-modal');
  if(m){m.classList.add('open');m.setAttribute('aria-hidden','false')}
}
function closeModal(){
  const m=document.getElementById('ichef-pad-reservation-modal');
  if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}
  openedReservation=null;
}

document.getElementById('ichef-pad-res-close')?.addEventListener('click',closeModal);
document.getElementById('ichef-pad-res-arrived')?.addEventListener('click',async()=>{
  if(!openedReservation)return;
  openedReservation.status='arrived';
  openedReservation.reservationStatus='arrived';
  try{
    if(typeof API!=='undefined'&&API?.update){
      await API.update('RESERVATIONS_MASTER',getReservations(),false,{reason:'Client arrivé'});
    }
  }catch(_){ }
  closeModal();
  refreshDots();
});
document.getElementById('ichef-pad-res-change')?.addEventListener('click',()=>{
  if(!openedReservation)return;
  const id=openedReservation.id||openedReservation.reservationId||openedReservation.bookingId;
  closeModal();
  if(typeof startAssignResa==='function')startAssignResa(id);
});

/* 3 clics rapides = détails réservation. Le clic simple reste au service. */
document.addEventListener('click',e=>{
  const w=e.target.closest?.('.table-wrapper');
  if(!w)return;
  const r=reservationFor(wrapperLabel(w));
  if(!r)return;
  const now=Date.now();
  const prev=clicks.get(w)||{n:0,t:0};
  const n=(now-prev.t<=650)?prev.n+1:1;
  clicks.set(w,{n,t:now});
  if(n>=3){
    clicks.set(w,{n:0,t:now});
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    openModal(r);
  }
},true);

function boot(){
  refreshDots();
  setInterval(refreshDots,5000);

  /* Quand le plan est reconstruit, réinjecte immédiatement les points sans attendre 5 s.
     L'observer ne surveille que les changements de nœuds, pas les classes : pas de boucle. */
  const floor=document.getElementById('floor-plan');
  if(floor && !floor.__ichefReservationDotObserver){
    let raf=0;
    const observer=new MutationObserver(()=>{
      if(raf) cancelAnimationFrame(raf);
      raf=requestAnimationFrame(()=>{ raf=0; refreshDots(); });
    });
    observer.observe(floor,{childList:true,subtree:true});
    floor.__ichefReservationDotObserver=observer;
  }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
window.ichefRefreshPadReservationDots=refreshDots;
})();
