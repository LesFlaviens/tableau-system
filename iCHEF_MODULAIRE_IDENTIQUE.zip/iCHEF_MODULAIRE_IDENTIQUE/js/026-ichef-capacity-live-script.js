(function(){
  'use strict';

  function num(v){
    v = Number(v);
    return Number.isFinite(v) && v > 0 ? v : 0;
  }

  function todayLocal(){
    const d=new Date();
    const y=d.getFullYear();
    const m=String(d.getMonth()+1).padStart(2,'0');
    const day=String(d.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }

  function tableZone(t){
    try{
      if(!t || !Array.isArray(zones)) return null;
      const cx=num(t.l)+(num(t.w)||80)/2;
      const cy=num(t.t)+(num(t.h)||120)/2;
      return zones.find(z =>
        z && z.room===t.room &&
        cx>=num(z.l) && cx<=num(z.l)+(num(z.w)||400) &&
        cy>=num(z.t) && cy<=num(z.t)+(num(z.h)||300)
      ) || null;
    }catch(_){ return null; }
  }

  function reservationPax(r){
    return num(r?.couverts || r?.pax || r?.personnes || r?.guests || 0);
  }

  function validTodayReservations(){
    const today=todayLocal();
    try{
      return (Array.isArray(reservationsData)?reservationsData:[]).filter(r =>
        r && r.date===today &&
        !['rejected','cancelled','canceled','annulee','annulée'].includes(String(r.status||'').toLowerCase())
      );
    }catch(_){ return []; }
  }

  function compute(){
    const allTables=(Array.isArray(tables)?tables:[]).filter(t=>t && !t.isExtra);
    const allZones=(Array.isArray(zones)?zones:[]);
    const resas=validTodayReservations();

    const totalCapacity=allTables.reduce((a,t)=>a+num(t.pax),0);
    const totalReserved=resas.reduce((a,r)=>a+reservationPax(r),0);
    const restaurant={
      capacity:totalCapacity,
      reserved:totalReserved,
      free:Math.max(0,totalCapacity-totalReserved)
    };

    const zoneStats=allZones.map(z=>{
      const zTables=allTables.filter(t=>tableZone(t)?.id===z.id);
      const capacity=zTables.reduce((a,t)=>a+num(t.pax),0);
      const labels=new Set(zTables.map(t=>String(t.label)));

      // Une réservation est attribuable à une zone seulement si elle possède une table assignée.
      const reserved=resas.reduce((a,r)=>{
        const assigned=String(r.assignedTable||r.table||'');
        return labels.has(assigned) ? a+reservationPax(r) : a;
      },0);

      return {
        id:z.id,
        label:z.label||z.name||'Zone',
        room:z.room||'',
        capacity,
        reserved,
        free:Math.max(0,capacity-reserved)
      };
    });

    return {restaurant,zoneStats};
  }

  function card(name,st,restaurant){
    return `<div class="ichef-cap-card${restaurant?' restaurant':''}">
      <span class="ichef-cap-name">${escapeText(name)}</span>
      <span class="ichef-cap-stat">TOTAL <strong>${st.capacity}</strong></span>
      <span class="ichef-cap-stat reserved">RÉSERVÉS <strong>${st.reserved}</strong></span>
      <span class="ichef-cap-stat free">LIBRES <strong>${st.free}</strong></span>
    </div>`;
  }

  function escapeText(v){
    return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function ensure(){
    const drawer=document.getElementById('order-drawer');
    if(!drawer) return null;
    let bar=document.getElementById('ichef-capacity-live');
    if(!bar){
      bar=document.createElement('div');
      bar.id='ichef-capacity-live';
      drawer.appendChild(bar);
    }
    // L'ancienne barre du bas est remplacée visuellement, sans supprimer sa logique.
    const old=document.getElementById('pro-status-bar');
    if(old) old.style.display='none';
    return bar;
  }

  function render(){
    const bar=ensure();
    if(!bar) return;
    const data=compute();
    let html=card('🍽 RESTAURANT',data.restaurant,true);

    // Afficher chaque zone, avec le nom de salle si nécessaire.
    data.zoneStats.forEach(z=>{
      const name=(z.room ? z.room+' · ' : '')+z.label;
      html+=card(name,z,false);
    });

    bar.innerHTML=html;
  }

  window.updateIChefCapacityLive=render;

  function init(){
    render();
    setInterval(()=>{
      const drawer=document.getElementById('order-drawer');
      if(drawer && drawer.classList.contains('open')) render();
    },1000);

    const drawer=document.getElementById('order-drawer');
    if(drawer){
      new MutationObserver(()=>render()).observe(drawer,{attributes:true,attributeFilter:['class']});
    }
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();

  // Rafraîchissement après les rendus métier existants.
  const hookNames=['renderFloor','renderPlanning','renderRooms'];
  hookNames.forEach(name=>{
    const original=window[name];
    if(typeof original==='function' && !original.__ichefCapacityHook){
      const wrapped=function(){
        const result=original.apply(this,arguments);
        setTimeout(render,0);
        return result;
      };
      wrapped.__ichefCapacityHook=true;
      window[name]=wrapped;
    }
  });
})();
