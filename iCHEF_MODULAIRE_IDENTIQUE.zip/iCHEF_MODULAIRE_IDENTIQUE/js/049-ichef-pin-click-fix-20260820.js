(function(){
  "use strict";
  function runPinButton(btn){
    if(!btn) return;
    const digit=btn.getAttribute("data-pin");
    const action=btn.getAttribute("data-pin-action");
    if(digit!==null){ window.appendPin(Number(digit)); return; }
    if(action==="clear"){ window.clearPin(); return; }
    if(action==="submit"){ Promise.resolve(window.submitPin()).catch(function(err){
      console.error("Erreur submitPin:",err);
      const box=document.getElementById("error-msg");
      if(box){ box.style.display="block"; box.style.color="var(--alert)"; box.innerText="❌ "+(err?.message||"Erreur de connexion"); }
    }); }
  }
  document.addEventListener("click",function(e){
    const btn=e.target.closest?.("#ichef-pin-pad-final .pin-btn");
    if(!btn) return;
    e.preventDefault(); e.stopImmediatePropagation();
    runPinButton(btn);
  },true);
  document.addEventListener("keydown",function(e){
    const login=document.getElementById("login-screen");
    if(!login || getComputedStyle(login).display==="none") return;
    if(/^\d$/.test(e.key)){ e.preventDefault(); window.appendPin(Number(e.key)); }
    else if(e.key==="Enter"){ e.preventDefault(); Promise.resolve(window.submitPin()).catch(console.error); }
    else if(e.key==="Backspace" || e.key==="Escape" || e.key==="Delete"){ e.preventDefault(); window.clearPin(); }
  },true);
})();
