(function(){
    "use strict";

    const MIN_WHITE = 36;
    const MIN_FOOTER = 42;
    const SPLITTER_H = 16;
    const STORAGE_KEY = "ichef_ticket_split_v4";

    let drag = null;
    let raf = 0;
    let pendingDelta = 0;
    let drawerWasOpen = false;

    function parts(){
        const drawer=document.getElementById("order-drawer");
        if(!drawer || !drawer.classList.contains("open")) return null;

        const ticket=drawer.querySelector(".ticket-view");
        const list=document.getElementById("ticket-list");
        if(!ticket || !list || !ticket.contains(list)) return null;

        let splitter=document.getElementById("ichef-ticket-splitter-v4");
        let footer=null;

        if(splitter && splitter.parentElement===ticket){
            footer=splitter.nextElementSibling;
        }else{
            /* Avant installation : le footer est l'élément qui suit ticket-list. */
            footer=list.nextElementSibling;
        }

        if(!footer) return null;
        return {drawer,ticket,list,splitter,footer};
    }

    function computeLimits(ticket,list){
        const tr=ticket.getBoundingClientRect();
        const lr=list.getBoundingClientRect();

        /* Hauteur réellement disponible entre le haut du bloc blanc et le bas du ticket. */
        const total=Math.max(
            MIN_WHITE + MIN_FOOTER + SPLITTER_H,
            tr.bottom - lr.top
        );

        return {
            min:MIN_WHITE,
            max:Math.max(MIN_WHITE,total - MIN_FOOTER - SPLITTER_H)
        };
    }

    function setHeight(list,h){
        list.style.setProperty("--ichef-ticket-white-h", Math.round(h)+"px");
    }

    function clampHeight(ticket,list,h){
        const lim=computeLimits(ticket,list);
        return Math.max(lim.min,Math.min(Number(h)||lim.min,lim.max));
    }

    function restoreOnce(p){
        if(p.list.dataset.splitV4Restored==="1") return;
        p.list.dataset.splitV4Restored="1";

        try{
            const saved=parseFloat(localStorage.getItem(STORAGE_KEY));
            if(Number.isFinite(saved) && saved>0){
                setHeight(p.list,clampHeight(p.ticket,p.list,saved));
            }
        }catch(_){}
    }

    function applyFrame(){
        raf=0;
        if(!drag) return;

        const h=clampHeight(
            drag.ticket,
            drag.list,
            drag.startHeight + pendingDelta
        );
        setHeight(drag.list,h);
    }

    function onPointerMove(e){
        if(!drag || e.pointerId!==drag.pointerId) return;
        e.preventDefault();

        /* Delta depuis le point de départ :
           aucune dépendance à la position du bloc pendant qu'il change de taille. */
        pendingDelta=e.clientY-drag.startY;

        if(!raf) raf=requestAnimationFrame(applyFrame);
    }

    function finishDrag(e){
        if(!drag) return;
        if(e && e.pointerId!=null && e.pointerId!==drag.pointerId) return;

        if(raf){
            cancelAnimationFrame(raf);
            raf=0;
            applyFrame();
        }

        const finalHeight=drag.list.getBoundingClientRect().height;
        try{
            localStorage.setItem(STORAGE_KEY,String(Math.round(finalHeight)));
        }catch(_){}

        drag.splitter.classList.remove("dragging");
        document.body.classList.remove("ichef-ticket-v4-dragging");

        try{ drag.splitter.releasePointerCapture(drag.pointerId); }catch(_){}

        window.removeEventListener("pointermove",onPointerMove,true);
        window.removeEventListener("pointerup",finishDrag,true);
        window.removeEventListener("pointercancel",finishDrag,true);

        drag=null;
        pendingDelta=0;
    }

    function startDrag(e){
        if(window.innerWidth<900 || e.button>0) return;

        const p=parts();
        if(!p || !p.splitter) return;

        e.preventDefault();
        e.stopPropagation();

        const startHeight=p.list.getBoundingClientRect().height;

        drag={
            pointerId:e.pointerId,
            splitter:p.splitter,
            ticket:p.ticket,
            list:p.list,
            startY:e.clientY,
            startHeight
        };

        pendingDelta=0;

        p.splitter.classList.add("dragging");
        document.body.classList.add("ichef-ticket-v4-dragging");

        try{ p.splitter.setPointerCapture(e.pointerId); }catch(_){}

        window.addEventListener("pointermove",onPointerMove,{capture:true,passive:false});
        window.addEventListener("pointerup",finishDrag,{capture:true,passive:false});
        window.addEventListener("pointercancel",finishDrag,{capture:true,passive:false});
    }

    function install(){
        if(window.innerWidth<900) return;

        const p=parts();
        if(!p) return;

        p.list.classList.add("ichef-ticket-list-resizable");

        let splitter=document.getElementById("ichef-ticket-splitter-v4");
        if(!splitter){
            splitter=document.createElement("div");
            splitter.id="ichef-ticket-splitter-v4";
            splitter.setAttribute("role","separator");
            splitter.setAttribute("aria-orientation","horizontal");
            splitter.setAttribute("aria-label","Redimensionner le ticket");

            const line=document.createElement("span");
            line.className="ichef-split-line";

            const handle=document.createElement("span");
            handle.className="ichef-split-handle";
            handle.textContent="↕";

            splitter.append(line,handle);
        }

        /* Toujours replacer exactement entre le bloc blanc et le footer. */
        let footer=p.footer;
        if(footer===splitter) footer=splitter.nextElementSibling;
        if(!footer) return;

        footer.classList.add("ichef-ticket-footer-v4");

        if(splitter.parentElement!==p.ticket || splitter.nextElementSibling!==footer){
            p.ticket.insertBefore(splitter,footer);
        }

        /* IMPORTANT : restauration une seule fois par ouverture, jamais pendant un render. */
        restoreOnce({ticket:p.ticket,list:p.list});

        if(splitter.dataset.v4Ready==="1") return;
        splitter.dataset.v4Ready="1";

        splitter.addEventListener("pointerdown",startDrag,{passive:false});

        splitter.addEventListener("dblclick",function(e){
            e.preventDefault();
            try{ localStorage.removeItem(STORAGE_KEY); }catch(_){}
            p.list.style.removeProperty("--ichef-ticket-white-h");
        });
    }

    function onDrawerState(){
        const drawer=document.getElementById("order-drawer");
        if(!drawer) return;

        const isOpen=drawer.classList.contains("open");

        if(isOpen && !drawerWasOpen){
            const list=document.getElementById("ticket-list");
            if(list) delete list.dataset.splitV4Restored;
            requestAnimationFrame(install);
        }

        if(!isOpen && drawerWasOpen){
            finishDrag();
        }

        drawerWasOpen=isOpen;
    }

    function boot(){
        const drawer=document.getElementById("order-drawer");

        if(drawer){
            drawerWasOpen=drawer.classList.contains("open");

            /* On n'observe QUE l'ouverture/fermeture du drawer.
               Les changements internes du ticket ne relancent plus restore(). */
            new MutationObserver(onDrawerState)
                .observe(drawer,{attributes:true,attributeFilter:["class"]});
        }

        if(drawerWasOpen) install();

        window.addEventListener("resize",function(){
            if(window.innerWidth>=900){
                requestAnimationFrame(function(){
                    const p=parts();
                    if(p){
                        const current=p.list.getBoundingClientRect().height;
                        setHeight(p.list,clampHeight(p.ticket,p.list,current));
                        install();
                    }
                });
            }else{
                finishDrag();
            }
        },{passive:true});

        setTimeout(function(){
            if(document.getElementById("order-drawer")?.classList.contains("open")) install();
        },250);
    }

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",boot,{once:true});
    }else{
        boot();
    }
})();
