(function(){
    "use strict";

    function normalize(s){
        return String(s||"")
            .normalize("NFD").replace(/[\u0300-\u036f]/g,"")
            .trim().toUpperCase();
    }

    function apply(){
        document.querySelectorAll("button").forEach(btn=>{
            const label=normalize(btn.textContent);
            if(label.includes("ATTENTE") || label.includes("ANNULER")){
                btn.style.setProperty("color","#fff","important");
                btn.style.setProperty("-webkit-text-fill-color","#fff","important");

                btn.querySelectorAll("*").forEach(el=>{
                    el.style.setProperty("color","#fff","important");
                    el.style.setProperty("-webkit-text-fill-color","#fff","important");
                });
            }
        });
    }

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",apply,{once:true});
    }else{
        apply();
    }

    /* Si le ticket est reconstruit après une commande, la couleur reste blanche. */
    const obs=new MutationObserver(()=>requestAnimationFrame(apply));
    obs.observe(document.documentElement,{childList:true,subtree:true});
})();
