(function(){
    let outilsButton = null;

    function getPanel(){
        return document.getElementById('folder-outils');
    }

    function placePanel(){
        const panel = getPanel();
        if(!panel || !outilsButton) return;

        if(window.innerWidth <= 900){
            panel.style.setProperty('left','8px','important');
            panel.style.setProperty('right','8px','important');
            panel.style.setProperty('top','auto','important');
            panel.style.setProperty('bottom','8px','important');
            panel.style.setProperty('width','auto','important');
            return;
        }

        const r = outilsButton.getBoundingClientRect();
        const width = 290;

        let left = r.right - width;
        if(left < 8) left = 8;
        if(left + width > window.innerWidth - 8){
            left = window.innerWidth - width - 8;
        }

        panel.style.setProperty('top', (r.bottom + 6) + 'px', 'important');
        panel.style.setProperty('left', left + 'px', 'important');
        panel.style.setProperty('right', 'auto', 'important');
        panel.style.setProperty('bottom', 'auto', 'important');
        panel.style.setProperty('width', width + 'px', 'important');
    }

    function closePanel(){
        const panel = getPanel();
        if(!panel) return;

        panel.classList.remove('ichef-outils-visible');

        if(outilsButton){
            outilsButton.classList.remove('open');
            const caret = outilsButton.querySelector('.folder-caret');
            if(caret) caret.textContent = '▾';
        }
    }

    window.toggleOutilsMenuFinal = function(event, button){
        if(event){
            event.preventDefault();
            event.stopPropagation();
        }

        const panel = getPanel();
        if(!panel){
            console.error('iCHEF: panneau #folder-outils introuvable');
            return;
        }

        outilsButton = button || outilsButton;

        // Le sortir de quick-folders-layer pour supprimer tout problème
        // de parent, z-index, overflow ou positionnement.
        if(panel.parentElement !== document.body){
            document.body.appendChild(panel);
        }

        const open = !panel.classList.contains('ichef-outils-visible');

        closePanel();

        if(open){
            panel.classList.add('ichef-outils-visible');

            if(outilsButton){
                outilsButton.classList.add('open');
                const caret = outilsButton.querySelector('.folder-caret');
                if(caret) caret.textContent = '▴';
            }

            placePanel();
        }
    };

    // Fermer après un choix dans le menu
    document.addEventListener('click', function(e){
        const panel = getPanel();
        if(!panel || !panel.classList.contains('ichef-outils-visible')) return;

        if(panel.contains(e.target)){
            if(e.target.closest('button')){
                setTimeout(closePanel, 50);
            }
            return;
        }

        if(outilsButton && outilsButton.contains(e.target)) return;
        closePanel();
    });

    document.addEventListener('keydown', function(e){
        if(e.key === 'Escape') closePanel();
    });

    window.addEventListener('resize', function(){
        const panel = getPanel();
        if(panel && panel.classList.contains('ichef-outils-visible')){
            placePanel();
        }
    });
})();
