(function(){
    'use strict';

    function isRetour(el){
        if (!el || !el.closest) return null;
        const b = el.closest('button, [role="button"], .btn-mini, .dock-btn');
        if (!b) return null;
        const txt = (b.textContent || '').trim().toLowerCase();
        const id = (b.id || '').toLowerCase();
        const cls = (typeof b.className === 'string' ? b.className : '').toLowerCase();
        const oc = (b.getAttribute('onclick') || '').toLowerCase();
        return (
            txt.includes('retour') || txt === '←' || txt.startsWith('←') ||
            id.includes('retour') || cls.includes('retour') || oc.includes('retour') ||
            id.includes('back') || cls.includes('back') || oc.includes('back')
        ) ? b : null;
    }

    let firedButton = null;
    let firedAt = 0;

    function fireRetour(e){
        const btn = isRetour(e.target);
        if (!btn || btn.disabled) return;

        /* pointerdown/touchstart donne une réponse immédiate, sans attendre le click */
        if (e.cancelable) e.preventDefault();
        e.stopPropagation();

        firedButton = btn;
        firedAt = performance.now();

        /* animation tactile très courte */
        btn.style.transform = 'scale(.96)';
        setTimeout(() => { if (btn) btn.style.transform = ''; }, 70);

        /* Exécute l'action existante du bouton sans la remplacer */
        const onclick = btn.getAttribute('onclick');
        if (onclick) {
            try {
                (new Function(onclick)).call(btn);
            } catch(err) {
                console.error('Retour tactile:', err);
                btn.click();
            }
        } else {
            btn.click();
        }
    }

    /* Pointer Events = souris, stylet et tactile moderne */
    document.addEventListener('pointerdown', fireRetour, {capture:true, passive:false});

    /* Bloque le click fantôme qui suivrait le pointerdown */
    document.addEventListener('click', function(e){
        const btn = isRetour(e.target);
        if (btn && btn === firedButton && performance.now() - firedAt < 700) {
            e.preventDefault();
            e.stopImmediatePropagation();
            firedButton = null;
        }
    }, true);
})();
