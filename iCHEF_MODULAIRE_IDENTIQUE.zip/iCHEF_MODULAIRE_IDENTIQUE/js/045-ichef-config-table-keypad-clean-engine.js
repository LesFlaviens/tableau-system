(function(){
"use strict";

function isVisible(el){
    if(!el) return false;
    const cs=getComputedStyle(el);
    return cs.display!=="none" && cs.visibility!=="hidden" && el.getClientRects().length>0;
}

function configPanel(){
    return [...document.querySelectorAll('div,section,dialog')].find(el=>{
        if(!isVisible(el)) return false;
        const txt=(el.innerText||"").toUpperCase();
        return txt.includes("CONFIG. TABLE") && txt.includes("CAPACITÉ");
    }) || null;
}

function findNameSource(panel){
    if(!panel) return null;

    // 1) input/textarea if available
    const input=[...panel.querySelectorAll('input,textarea')].find(isVisible);
    if(input) return input;

    // 2) current name display: large element above keypad
    const candidates=[...panel.querySelectorAll('div,span,p')].filter(el=>{
        if(!isVisible(el) || el.closest('button')) return false;
        const txt=(el.textContent||"").trim();
        const r=el.getBoundingClientRect();
        return txt.length<=16 && r.width>250 && r.height>45;
    });
    return candidates[0] || null;
}

function getVal(target){
    if(!target) return "";
    return ('value' in target) ? String(target.value||"") : String(target.textContent||"").trim();
}

function setVal(target,v,preview){
    v=String(v||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,12);

    if(target){
        if('value' in target){
            target.value=v;
            target.dispatchEvent(new Event('input',{bubbles:true}));
            target.dispatchEvent(new Event('change',{bubbles:true}));
        }else{
            target.textContent=v || "—";
            target.dispatchEvent(new Event('input',{bubbles:true}));
        }
    }

    if(preview) preview.textContent=v || "—";
}

function hideOldNamingKeys(panel){
    if(!panel) return;

    // Hide only the old naming keypad, not capacity/shape controls.
    [...panel.querySelectorAll('button')].forEach(btn=>{
        const t=(btn.textContent||"").trim().toUpperCase();

        // Old naming keys: 0-9, A/B/C/T/EXT, clear/backspace
        if(/^[0-9]$/.test(t) || ["A","B","C","T","EXT","⌫","←"].includes(t)){
            const parent=btn.parentElement;
            const rect=btn.getBoundingClientRect();

            // Only keys in upper naming section (above CAPACITÉ heading)
            const cap=[...panel.querySelectorAll('*')].find(x=>
                (x.textContent||"").trim().toUpperCase().includes("CAPACITÉ")
            );
            const capTop=cap?.getBoundingClientRect().top ?? Infinity;

            if(rect.top < capTop - 20){
                btn.style.display="none";
            }
        }
    });
}

function build(){
    const panel=configPanel();
    if(!panel) return;

    if(panel.querySelector('#ichef-config-table-keypad-clean')) return;

    const target=findNameSource(panel);
    if(!target) return;

    hideOldNamingKeys(panel);

    // Hide old "EFFACER" naming button if present in upper section
    [...panel.querySelectorAll('button')].forEach(btn=>{
        if((btn.textContent||"").trim().toUpperCase()==="EFFACER"){
            btn.style.display="none";
        }
    });

    const preview=document.createElement('div');
    preview.id='ichef-config-table-name-preview';
    preview.textContent=getVal(target)||"—";

    const wrap=document.createElement('div');
    wrap.id='ichef-config-table-keypad-clean';
    wrap.innerHTML=`
      <div class="numeric">
        <button data-k="1">1</button>
        <button data-k="2">2</button>
        <button data-k="3">3</button>
        <button data-k="4">4</button>
        <button data-k="5">5</button>
        <button data-k="6">6</button>
        <button data-k="7">7</button>
        <button data-k="8">8</button>
        <button data-k="9">9</button>
        <button class="clear" data-action="clear">C</button>
        <button data-k="0">0</button>
        <button class="back" data-action="back">⌫</button>
      </div>
      <div class="shortcuts">
        <button data-k="A">A</button>
        <button data-k="B">B</button>
        <button data-k="C">C</button>
        <button data-k="T">T</button>
        <button data-k="EXT">EXT</button>
      </div>`;

    wrap.addEventListener('click',e=>{
        const b=e.target.closest('button');
        if(!b) return;
        e.preventDefault();
        e.stopPropagation();

        let v=getVal(target);
        if(v==="—") v="";

        if(b.dataset.action==="clear"){
            setVal(target,"",preview);
            return;
        }
        if(b.dataset.action==="back"){
            setVal(target,v.slice(0,-1),preview);
            return;
        }
        setVal(target,v+(b.dataset.k||""),preview);
    });

    // Insert just before capacity section
    const capacityHeading=[...panel.querySelectorAll('*')].find(el=>{
        const txt=(el.textContent||"").trim().toUpperCase();
        return txt==="CAPACITÉ (COUVERTS)" || txt.includes("CAPACITÉ");
    });

    const anchor=capacityHeading?.parentElement || panel;
    anchor.insertBefore(preview, capacityHeading || anchor.firstChild);
    preview.insertAdjacentElement('afterend',wrap);
}

document.addEventListener('click',()=>setTimeout(build,20),true);
{
  const __ichefCfgModal=document.getElementById('table-config-modal');
  if(__ichefCfgModal){
    let __ichefCfgRaf=0;
    new MutationObserver(()=>{
      if(__ichefCfgRaf) return;
      __ichefCfgRaf=requestAnimationFrame(()=>{__ichefCfgRaf=0;build();});
    }).observe(__ichefCfgModal,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  }
}
setTimeout(build,250);
})();
