(function(){
"use strict";

/*
 iCHEF — Réservations strictement limitées au PLAN DE SALLE.
 Une réservation n'est "placée" que si assignedTable correspond
 EXACTEMENT à une table présente dans ARCHITECTURE.data.tables.
 Aucun autre identifiant (zone, salle, texte "T", etc.) n'est accepté.
*/

function rpNorm(v){ return String(v == null ? "" : v).trim(); }
function rpRid(r){ return String(r?.id || r?.reservationId || r?.bookingId || ""); }
function rpAssigned(r){ return rpNorm(r?.assignedTable || r?.tableId || r?.table); }

function rpTables(state){
    const raw = state?.activeOrders?.ARCHITECTURE?.data?.tables;
    return Array.isArray(raw) ? raw.filter(t => rpNorm(t?.label)) : [];
}

function rpFindExactTable(state,label){
    const wanted = rpNorm(label);
    if(!wanted) return null;
    return rpTables(state).find(t => rpNorm(t.label) === wanted) || null;
}

function rpReservationActive(r){
    const st = rpNorm(r?.status || r?.reservationStatus).toLowerCase();
    return !["cancelled","canceled","annule","annulee","rejected","completed","done","noshow","no show"].includes(st);
}

async function rpState(){
    const r = await fetch(`${window.SERVER_URL}/get-current-state?tenantID=${getTenantParam()}`, {cache:"no-store"});
    if(!r.ok) throw new Error("STATE_"+r.status);
    return r.json();
}

async function rpWriteReservations(resas){
    const r = await fetch(`${window.SERVER_URL}/update-order?tenantID=${getTenantParam()}`,{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({tableId:"RESERVATIONS_MASTER",order:{data:resas}})
    });
    if(!r.ok) throw new Error("UPDATE_"+r.status);
}

/* Corrige les anciennes affectations fantômes comme "T".
   Elles redeviennent simplement "à placer". */
async function rpSanitizeAssignments(){
    const state = await rpState();
    const resas = state?.activeOrders?.RESERVATIONS_MASTER?.data || [];
    let changed = false;

    resas.forEach(r=>{
        if(!rpReservationActive(r)) return;
        const label = rpAssigned(r);
        if(label && !rpFindExactTable(state,label)){
            r.assignedTable = "";
            r.tableId = "";
            r.table = "";
            r.placementStatus = "pending";
            changed = true;
        }
    });

    if(changed) await rpWriteReservations(resas);
    return {state, resas, changed};
}

/* Verrou central : toute affectation doit viser une vraie table du plan. */
const oldAssign = window.ichefAssignReservationToTable;
window.ichefAssignReservationToTable = async function(reservation,label){
    const state = await rpState();
    const table = rpFindExactTable(state,label);
    if(!table){
        alert("❌ Cette destination n'est pas une table du plan de salle.");
        return false;
    }
    if(typeof oldAssign === "function"){
        const out = await oldAssign(reservation, table.label);
        await rpRefreshAll();
        return out;
    }
    return false;
};

/* Compteurs : uniquement les vraies tables physiques du plan. */
window.ichefRefreshTableStatusSummary = async function(){
    try{
        const state = await rpState();
        const tables = rpTables(state);
        const resas = state?.activeOrders?.RESERVATIONS_MASTER?.data || [];

        const reservedLabels = new Set(
            resas.filter(r=>rpReservationActive(r) && rpFindExactTable(state,rpAssigned(r)))
                 .map(r=>rpAssigned(r))
        );

        let free=0,reserved=0,occupied=0;
        tables.forEach(t=>{
            const label = rpNorm(t.label);
            const order = state?.activeOrders?.[label];
            const items = Array.isArray(order?.items) ? order.items : [];
            const hasItems = items.some(i => Number(i?.qty ?? i?.quantity ?? 1)>0 &&
                String(i?.name ?? i?.n ?? i?.productName ?? i?.title ?? "").trim());

            if(hasItems) occupied++;
            else if(reservedLabels.has(label)) reserved++;
            else free++;
        });

        const f=document.getElementById("ichef-free-count");
        const r=document.getElementById("ichef-reserved-count");
        const o=document.getElementById("ichef-occupied-count");
        if(f) f.textContent=free;
        if(r) r.textContent=reserved;
        if(o) o.textContent=occupied;
    }catch(e){ console.warn("[iCHEF PLAN STRICT]",e); }
};

/* Bord violet : seulement la vraie table correspondant à la réservation. */
async function rpPaintReservedTables(){
    try{
        const state = await rpState();
        const tables = rpTables(state);
        const resas = state?.activeOrders?.RESERVATIONS_MASTER?.data || [];
        const reserved = new Set(
            resas.filter(r=>rpReservationActive(r) && rpFindExactTable(state,rpAssigned(r)))
                 .map(r=>rpAssigned(r))
        );

        /* On ne touche qu'aux éléments qui représentent réellement une table connue. */
        tables.forEach(t=>{
            const label = rpNorm(t.label);
            const candidates = document.querySelectorAll(
                `[data-id="${CSS.escape(label)}"],`+
                `[data-table-id="${CSS.escape(label)}"],`+
                `[data-table="${CSS.escape(label)}"],`+
                `[data-table-label="${CSS.escape(label)}"],`+
                `[data-label="${CSS.escape(label)}"]`
            );
            candidates.forEach(el=>{
                if(reserved.has(label)){
                    el.classList.add("ichef-plan-reserved");
                }else{
                    el.classList.remove("ichef-plan-reserved");
                }
            });
        });
    }catch(e){ console.warn("[iCHEF VIOLET]",e); }
}

async function rpRefreshAll(){
    await rpSanitizeAssignments();
    await window.ichefRefreshTableStatusSummary();
    await rpPaintReservedTables();
    if(typeof loadB2BAnalytics === "function") loadB2BAnalytics();
}

/* IA ON : seules les réservations sans vraie table du plan sont candidates. */
const oldAi = window.ichefAiPlaceReservationById;
window.ichefAiPlaceReservationById = async function(id){
    await rpSanitizeAssignments();
    if(typeof oldAi === "function") {
        const out = await oldAi(id);
        await rpRefreshAll();
        return out;
    }
};

/* Nettoyage au chargement + synchronisation régulière. */
window.addEventListener("load",()=>setTimeout(rpRefreshAll,900));
setInterval(()=>{
    const panel=document.getElementById("b2b-panel");
    if(panel && (panel.style.display==="flex" || getComputedStyle(panel).display!=="none")){
        rpRefreshAll();
    }
},5000);

window.ICHEF_RESERVATION_PLAN_STRICT = Object.freeze({
    enabled:true,
    source:"ARCHITECTURE.data.tables",
    exactTableOnly:true
});
})();
