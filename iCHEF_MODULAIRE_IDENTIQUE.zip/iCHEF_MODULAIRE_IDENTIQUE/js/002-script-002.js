        // Variables d'état Anti-Rush 3.0
        let isKitchenInRush = false;
        let rushV3Settings = { cameleon: false, timeShift: { active: false, discount: 5, delay: 15 }, paceMaker: { active: false, max: 10 } };
        let currentRushLevel = 0;

        window.addEventListener('load', () => {
            if (typeof isDemoMode !== 'undefined' && isDemoMode) {
                let badge = document.createElement('div');
                badge.innerHTML = "MODE DÉMO - LECTURE SEULE";
                badge.style.cssText = "position:fixed; top:10px; right:10px; background:var(--alert); color:white; padding:5px 10px; border-radius:5px; font-weight:bold; z-index:99999; font-size:12px; pointer-events:none;";
                document.body.appendChild(badge);
            }
        });

        // -------------------------------------------------------------
        // FONCTIONS D'INTERFACE DE BASE
        // -------------------------------------------------------------

        const appUrlParams = new URLSearchParams(window.location.search);
        let appTenantID = appUrlParams.get('tenantID') || localStorage.getItem('ichef_tenant_id');
        if (!appTenantID) window.location.replace('connexionpartenaire.html');
        // iCHEF FIX PIN : un fichier HTML ouvert directement doit utiliser le serveur en ligne.
        // localhost n'est utilisé QUE lorsque la page est réellement servie depuis localhost/127.0.0.1.
        const APP_SERVER_URL = (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1")
        ? "http://localhost:10000" : "https://tableau-system.onrender.com";
        
        let activeOrders = {}; 
        let currentTableId = null; 
        let currentTicket = []; 
        let isArchiMode = false;
        let isDraggingTable = false; 
        let configTableId = null;
        let isRushMode = false;
        let isServiceAuBarActive = false;
        
        let currentSeat = 0; 
        let currentCategory = 'MenuJour'; 
        let currentCourseDefault = 2;
        let stockAlerts = { green: 10, yellow: 7, orange: 5, red: 2 }; 

        let menuCuisine = { MenuJour: [], Suggestions: [], Entrées: [], Plats: [], Desserts: [] };

        let menuBar = { Vins: [], Cocktails: [], Bières: [], Softs: [], Spiritueux: [], "Boissons Chaudes": [] };
        let reservationsData = []; 
        let staffAccessData = []; 
        let localSasConfig = { active: false, maxTables: 5, delay: 60 }; 
        let unifiedMenu = {};
        let globalTimesheets = {};

        // --- NOUVELLES VARIABLES DE SYMBIOSE ---
let categoriesCuisine = [];
let categoriesBar = [];
let categoriesPatisserie = [];
let unifiedCategories = [];

// ---------------------------------------

        let isLoyaltyActive = false;
        let loyaltyPercent = 5;
        let globalLoyaltyData = {};
        let currentLoyaltyPhone = null;

        // =========================================================
        // ✅ COMPATIBILITÉ UI — évite les boutons morts
        // =========================================================
        function toggleMobileMenu() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('mobile-overlay');
            if (!sidebar) return;
            sidebar.classList.toggle('open');
            if (overlay) overlay.classList.toggle('show', sidebar.classList.contains('open'));
        }

        function closeCriticalStockAlert() {
            const modal = document.getElementById('stock-critical-modal');
            if (modal) modal.classList.remove('open');
        }

        async function markAsServed(idx) {
            const item = currentTicket[idx];
            if (!item) return;
            item.served = true;
            item.done = true;
            item.sequenceStatus = 'SERVED';
            renderTicket();
            try { await executeSaveTableState(false, true); }
            catch(e) { console.warn('Sauvegarde service impossible', e); }
            updateSequenceServicePanel();
        }

        // =========================================================
        // 🔗 iCHEF — SYMBIOSE TOTALE DES COMMANDES
        // Une seule lecture métier pour QR / PAD / COMPTOIR / KDS / CAISSE.
        // =========================================================
        function normalizeLifecycleValue(value, allowed, fallback) {
            const v = String(value || '').trim().toUpperCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g,'');
            return allowed.includes(v) ? v : fallback;
        }

        function inferOrderProductionStatus(order) {
            const items = Array.isArray(order?.items) ? order.items.filter(Boolean) : [];
            if (!items.length) return 'WAITING';

            const allServed = items.every(i => i.served === true || String(i.sequenceStatus || '').toUpperCase() === 'SERVED');
            if (allServed) return 'SERVED';

            const sent = items.filter(i => i.isSent === true);
            if (!sent.length) return 'WAITING';

            const allReady = sent.every(i =>
                i.done === true ||
                String(i.sequenceStatus || '').toUpperCase() === 'READY'
            );
            if (allReady) return 'READY';

            return 'PRODUCTION';
        }

        function inferOrderDestinations(order) {
            const items = Array.isArray(order?.items) ? order.items : [];
            const found = [...new Set(items.map(i =>
                String(i?.dest || i?.destination || i?.station || '').trim().toUpperCase()
            ).filter(Boolean))];
            return found.length ? found : ['CUISINE'];
        }

        function getUnifiedOrderMeta(order, tableId, overrides = {}) {
            const old = (order && typeof order.orderMeta === 'object' && order.orderMeta) ? order.orderMeta : {};

            const isQr = !!(
                order?.isWeb ||
                order?.isQR ||
                String(old.origin || order?.origin || '').toUpperCase() === 'QR' ||
                /^WEB_|^QR_/i.test(String(tableId || ''))
            );

            const origin = normalizeLifecycleValue(
                overrides.origin || old.origin || order?.origin || (isQr ? 'QR' : 'PAD'),
                ['QR','PAD','COMPTOIR','ADMIN','VOICE','API'],
                isQr ? 'QR' : 'PAD'
            );

            let serviceGuess =
                overrides.serviceMode ||
                old.serviceMode ||
                order?.serviceMode ||
                order?.modeService ||
                order?.deliveryMode ||
                '';

            if (!serviceGuess) {
                const counterHint = !!(
                    order?.pickup ||
                    order?.takeAwayCounter ||
                    order?.serviceAuComptoir ||
                    order?.counterService ||
                    (typeof isServiceAuBarActive !== 'undefined' && isServiceAuBarActive)
                );
                serviceGuess = counterHint ? 'COMPTOIR' : 'SERVEUR';
            }

            const serviceMode = normalizeLifecycleValue(
                serviceGuess,
                ['COMPTOIR','SERVEUR','EMPORTER','LIVRAISON'],
                'SERVEUR'
            );

            const paidHint = (
                order?.paid === true ||
                order?.isPaid === true ||
                String(order?.paymentStatus || old.paymentStatus || '').toUpperCase() === 'PAYE' ||
                String(order?.paymentStatus || old.paymentStatus || '').toUpperCase() === 'PAID'
            );

            const paymentStatus = normalizeLifecycleValue(
                overrides.paymentStatus || old.paymentStatus || order?.paymentStatus || (paidHint ? 'PAYE' : 'A_PAYER'),
                ['PAYE','A_PAYER','PARTIEL','REMBOURSE'],
                paidHint ? 'PAYE' : 'A_PAYER'
            );

            const productionStatus = normalizeLifecycleValue(
                overrides.productionStatus || old.productionStatus || inferOrderProductionStatus(order),
                ['WAITING','PRODUCTION','READY','SERVED','CANCELLED'],
                inferOrderProductionStatus(order)
            );

            return {
                version: 1,
                origin,
                serviceMode,
                paymentStatus,
                productionStatus,
                destinations: Array.isArray(overrides.destinations)
                    ? overrides.destinations
                    : inferOrderDestinations(order),
                tableId: String(tableId || old.tableId || ''),
                updatedAt: new Date().toISOString(),
                updatedBy: currentUser?.name || old.updatedBy || null,
                deviceId: window.ICHEF_SECURITY?.deviceId || old.deviceId || null
            };
        }

        function lifecycleLabels(meta = {}) {
            const service = meta.serviceMode === 'COMPTOIR' ? 'COMPTOIR'
                : meta.serviceMode === 'EMPORTER' ? 'À EMPORTER'
                : meta.serviceMode === 'LIVRAISON' ? 'LIVRAISON'
                : 'SERVEUR';

            const pay = meta.paymentStatus === 'PAYE' ? 'PAYÉ'
                : meta.paymentStatus === 'PARTIEL' ? 'PARTIEL'
                : meta.paymentStatus === 'REMBOURSE' ? 'REMBOURSÉ'
                : 'À PAYER';

            const prod = meta.productionStatus === 'READY' ? 'PRÊT'
                : meta.productionStatus === 'PRODUCTION' ? 'EN PRODUCTION'
                : meta.productionStatus === 'SERVED' ? 'SERVI'
                : meta.productionStatus === 'CANCELLED' ? 'ANNULÉ'
                : 'EN ATTENTE';

            return {service, pay, prod};
        }

        function safeArray(key, fallback) {
            try { let v = localStorage.getItem(key); if (v && v !== 'undefined' && v !== 'null') { let p = JSON.parse(v); if (Array.isArray(p)) return p.filter(i => i !== null && i !== undefined); } } catch(e) {} return fallback;
        }

        let rooms = safeArray('empire_rooms', ['Salle Principale']);
        let currentRoom = rooms[0] || 'Salle Principale';
        let configRoomOldName = null, currentTactileRoomName = "";
        let tables = safeArray('empire_architecture', [ {label:"T1", l:550, t:500, w:80, h:120, shape:"rect", pax: 4, room: "Salle Principale"} ]);
        let zones = safeArray('empire_zones', []);
        let configZoneId = null;
        let currentTableId_PayMode = 'standard';
        let currentTableZoneLabel = 'Salle';
        window.systemSettings = window.systemSettings || {};

        let inactivityTimer; const INACTIVITY_LIMIT = 15 * 60 * 1000; 
        let currentUser = null, currentPin = "";
        let loginInProgress = false;
        let localLoginFailures = 0;
        let localLoginBlockedUntil = 0;
        let syncInterval = null; let clockInterval = null;

        function securityHeaders(extra = {}) {
            const headers = {
                'Content-Type': 'application/json',
                'X-Requested-With': 'iCHEF-PWA',
                /* Noms EXACTS autorisés par server.js */
                'X-iCHEF-Tenant': String(appTenantID || ''),
                'X-iCHEF-Device': String(window.ICHEF_SECURITY?.deviceId || ''),
                ...extra
            };
            if (window.ICHEF_SECURITY.sessionToken) {
                headers.Authorization = `Bearer ${window.ICHEF_SECURITY.sessionToken}`;
            }
            if (window.ICHEF_SECURITY.csrfToken) {
                headers['X-CSRF-Token'] = window.ICHEF_SECURITY.csrfToken;
            }
            return headers;
        }

        async function secureFetch(path, options = {}) {
            // Mode compatibilité avec l'authentification /api/verify-pin.
            // Une fonction optionnelle non disponible ne doit JAMAIS fermer la session locale du Pad.
            const response = await fetch(`${APP_SERVER_URL}${path}`, {
                credentials: 'include',
                cache: 'no-store',
                ...options,
                headers: securityHeaders(options.headers || {})
            });

            if (response.status === 401 || response.status === 403) {
                console.warn(
                    `[iCHEF] Accès refusé pour ${path} (${response.status}) — session Pad conservée.`
                );
            }

            return response;
        }

        async function auditEvent(action, details = {}, throwOnError = true) {
            /* Le server.js fourni n'expose pas /api/audit/events.
               Ne jamais casser le service pour un audit client optionnel.
               Les opérations fiscales importantes restent scellées côté server.js. */
            try {
                console.debug('[iCHEF AUDIT CLIENT]', action, details);
                return true;
            } catch (error) {
                return !throwOnError;
            }
        }

        function hasPermission(permission) {
            return window.ICHEF_SECURITY.permissions.has(permission) || window.ICHEF_SECURITY.permissions.has('*');
        }

        async function requirePermission(permission, context = {}) {
            if (!currentUser || !hasPermission(permission)) {
                await auditEvent('PERMISSION_DENIED', { permission, ...context }, false);
                alert('❌ Vous ne disposez pas de cette autorisation.');
                return false;
            }
            return true;
        }

        function validateOrderPayloadForFraud(data) {
            if (data === null || data === undefined) return { ok: true };

            const items = Array.isArray(data?.items)
                ? data.items
                : (Array.isArray(data) ? data : null);

            if (!items) return { ok: true };

            if (items.length > 500) {
                return { ok:false, reason:'TOO_MANY_ITEMS' };
            }

            let computed = 0;

            for (const item of items) {
                if (!item || typeof item !== 'object') {
                    return { ok:false, reason:'INVALID_ITEM' };
                }

                const name = String(item.n ?? item.name ?? '').trim();
                const qty = Number(item.qty ?? 1);
                const price = Number(item.p ?? item.price ?? 0);

                if (!name || name.length > 240) {
                    return { ok:false, reason:'INVALID_ITEM_NAME' };
                }
                if (!Number.isFinite(qty) || qty <= 0 || qty > 100) {
                    return { ok:false, reason:'INVALID_QTY' };
                }
                if (!Number.isFinite(price) || price < 0 || price > 100000) {
                    return { ok:false, reason:'INVALID_PRICE' };
                }

                computed += qty * price;
                if (!Number.isFinite(computed) || computed > 500000) {
                    return { ok:false, reason:'ABNORMAL_ORDER_TOTAL' };
                }
            }

            return { ok:true, computedTotal:Math.round(computed * 100) / 100 };
        }

        async function reportClientSecurityEvent(action, details = {}) {
            try {
                console.debug('[iCHEF SECURITY]', action, details);
                return true;
            } catch (_) {
                return false;
            }
        }

        const API = {
            getState: async () => {
                const response = await secureFetch(
                    `/get-current-state?tenantID=${encodeURIComponent(appTenantID)}&_t=${Date.now()}`,
                    { method: 'GET' }
                );
                if (!response.ok) throw new Error(`STATE_READ_FAILED_${response.status}`);
                return response.json();
            },

            update: async (key, data, isOrder = false, audit = {}) => {
                if (!currentUser) throw new Error('AUTH_REQUIRED');

                if (isOrder) {
                    const fraudCheck = validateOrderPayloadForFraud(data);
                    if (!fraudCheck.ok) {
                        reportClientSecurityEvent('CLIENT_ORDER_BLOCKED', {
                            reason: fraudCheck.reason,
                            key: String(key || '').slice(0,120)
                        });
                        throw new Error(`ORDER_SECURITY_${fraudCheck.reason}`);
                    }
                }

                const normalizedKey = String(key || '').trim();
                if (!normalizedKey || normalizedKey.length > 120) {
                    throw new Error('INVALID_KEY');
                }

                const payload = isOrder ? data : { data };
                const response = await secureFetch(
                    `/update-order?tenantID=${encodeURIComponent(appTenantID)}`,
                    {
                        method: 'POST',
                        body: JSON.stringify({
                            tableId: normalizedKey,
                            order: data === null ? null : payload,
                            deviceId: window.ICHEF_SECURITY?.deviceId || null,
                            waiter: currentUser?.name || null
                        })
                    }
                );

                const result = await response.json().catch(() => ({}));
                if (!response.ok) {
                    throw new Error(result.error || `UPDATE_FAILED_${response.status}`);
                }
                return result;
            }
        };

        // --- AUTHENTIFICATION EXCLUSIVEMENT SERVEUR ---
        function resetInactivityTimer() {
            window.ICHEF_SECURITY.lastActivityAt = Date.now();
            clearTimeout(inactivityTimer);
            if (currentUser) inactivityTimer = setTimeout(() => logout('INACTIVITY'), INACTIVITY_LIMIT);
        }
        ['touchstart', 'click', 'mousemove', 'keypress'].forEach(e => document.addEventListener(e, resetInactivityTimer, { passive: true }));

        function appendPin(n) {
            if (currentPin.length >= 12) return;
            currentPin += String(n);
            document.getElementById('pin-display').innerText = '•'.repeat(currentPin.length);
            resetInactivityTimer();
        }
        function clearPin() {
            currentPin = '';
            document.getElementById('pin-display').innerText = '';
        }
        async function submitPin() {
    if (loginInProgress) return;

    const msgBox = document.getElementById('error-msg');
    msgBox.style.display = 'none';

    if (Date.now() < localLoginBlockedUntil) {
        msgBox.style.display = 'block';
        msgBox.style.color = 'var(--alert)';
        msgBox.innerText = '⏳ Trop de tentatives. Veuillez patienter.';
        return;
    }

    const pin = String(currentPin || '').trim();
    if (!pin) return;

    if (!/^\d{4,12}$/.test(pin)) {
        msgBox.style.display = 'block';
        msgBox.style.color = 'var(--alert)';
        msgBox.innerText = '❌ Code PIN invalide (4 chiffres minimum).';
        clearPin();
        return;
    }

    loginInProgress = true;
    msgBox.style.display = 'block';
    msgBox.style.color = 'var(--gold)';
    msgBox.innerText = '⏳ Vérification...';

    try {
        // Vérification centralisée côté serveur : PIN principal + PIN du personnel.
        const response = await secureFetch('/api/verify-pin', {
            method: 'POST',
            headers: { 'Accept': 'application/json' },
            body: JSON.stringify({
                tenantID: appTenantID,
                pin,
                deviceId: window.ICHEF_SECURITY?.deviceId || null
            })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok || !data.success) {
            localLoginFailures += 1;
            if (localLoginFailures >= 5) {
                localLoginBlockedUntil = Date.now() + 30000;
                localLoginFailures = 0;
            }

            msgBox.style.display = 'block';
            msgBox.style.color = 'var(--alert)';
            msgBox.innerText = `❌ ${data.error || 'Code PIN incorrect.'}`;
            clearPin();
            return;
        }

        localLoginFailures = 0;

        // Jetons éventuels renvoyés par le serveur : conservés uniquement en mémoire.
        if (data.sessionToken) window.ICHEF_SECURITY.sessionToken = data.sessionToken;
        if (data.csrfToken) window.ICHEF_SECURITY.csrfToken = data.csrfToken;

        // Le serveur renvoie le rôle réel associé au PIN.
        const serverRole = String(data.role || 'STAFF').trim().toLowerCase();
        let displayName = serverRole === 'master' ? 'Directeur' : 'Utilisateur';
        let userRole = (serverRole === 'master' || serverRole === 'admin' || serverRole === 'manager')
            ? 'Manager'
            : 'Serveur';

        // Pour un PIN staff, récupérer le nom affiché sans refaire l'authentification localement.
        if (serverRole !== 'master') {
            try {
                const stateResponse = await secureFetch(
                    `/get-current-state?tenantID=${encodeURIComponent(appTenantID)}&_t=${Date.now()}`,
                    { method: 'GET' }
                );
                if (stateResponse.ok) {
                    const stateData = await stateResponse.json();
                    const staffList = stateData?.activeOrders?.STAFF_ACCESS?.data || [];
                    const staffUser = Array.isArray(staffList)
                        ? staffList.find(s => String(s?.pin ?? '').trim() === pin)
                        : null;
                    if (staffUser?.name) displayName = staffUser.name;
                }
            } catch (_) {
                // Le nom est secondaire : l'accès reste validé par /api/verify-pin.
            }
        }

        currentUser = { name: displayName, role: userRole, serverRole };

        window.ICHEF_SECURITY.user = currentUser;
        window.ICHEF_SECURITY.authenticatedAt = Date.now();
        window.ICHEF_SECURITY.permissions = new Set(
            userRole === 'Manager'
                ? ['ADMIN_ACCESS','FLOORPLAN_DELETE','ORDER_ITEM_CANCEL','ORDER_VOID','TERMINAL_MAINTENANCE']
                : []
        );

        clearPin();
        unlockPadWithUser(currentUser);
    } catch (e) {
        console.error('Erreur réseau PIN', e);
        msgBox.style.display = 'block';
        msgBox.style.color = 'var(--alert)';
        msgBox.innerText = '❌ Impossible de joindre le serveur.';
        clearPin();
    } finally {
        loginInProgress = false;
    }
}

async function requestMaintenanceOverride() {
            if (!(await requirePermission('TERMINAL_MAINTENANCE'))) return;
            const reason = prompt('Motif de maintenance obligatoire :');
            if (!reason || reason.trim().length < 5) return alert('Motif obligatoire.');
            await auditEvent('PWA_MAINTENANCE_OVERRIDE', { reason: reason.trim() });
            document.getElementById('pwa-strict-lock').style.display = 'none';
        }

        async function toggleKioskMode() {
            const elem = document.documentElement;
            const btn = document.getElementById('btn-kiosk');
            
            try {
                if (!document.fullscreenElement) {
                    if (elem.requestFullscreen) await elem.requestFullscreen();
                    else if (elem.webkitRequestFullscreen) await elem.webkitRequestFullscreen(); 
                    else if (elem.msRequestFullscreen) await elem.msRequestFullscreen(); 
                    
                    btn.innerHTML = "✕ QUITTER";
                    btn.style.color = "var(--gold)";
                    btn.style.borderColor = "var(--gold)";

                    if ('wakeLock' in navigator) {
                        try {
                            window.wakeLockObj = await navigator.wakeLock.request('screen');
                        } catch (err) {}
                    }
                } else {
                    if (document.exitFullscreen) await document.exitFullscreen();
                    else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
                    
                    btn.innerHTML = "⛶ KIOSQUE";
                    btn.style.color = "var(--text-muted)";
                    btn.style.borderColor = "var(--border)";

                    if (window.wakeLockObj) {
                        await window.wakeLockObj.release();
                        window.wakeLockObj = null;
                    }
                }
            } catch(e) { console.error("Erreur Kiosque:", e); }
        }

        function unlockPadWithUser(user) {
    clearPin();
    document.getElementById('user-badge').innerText = `Badge: ${user.name}`;
    document.getElementById('login-screen').style.display = 'none';
    document.querySelectorAll('.admin').forEach(e => e.style.display = user.role === 'Manager' ? 'block' : 'none');

    renderRooms();
    renderFloor();

    connectEmpireH24();
    resetInactivityTimer();
}

async function logout(reason = 'MANUAL') {
            forceLocalLogout();
        }

        function forceLocalLogout(message = '') {
            currentUser = null;
            currentPin = '';
            window.ICHEF_SECURITY.sessionToken = null;
            window.ICHEF_SECURITY.user = null;
            window.ICHEF_SECURITY.permissions = new Set();
            document.getElementById('login-screen').style.display = 'flex';
            clearPin();
            closeOrder(); closeArchiMode(); closeAdminCatalog(); closePlanningModal(); closeDrawer('history-drawer');
            clearTimeout(inactivityTimer);
            if (syncInterval) clearInterval(syncInterval);
            if (clockInterval) clearInterval(clockInterval);
            if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
            if (message) alert(message);
        }

        function connectEmpireH24() { 
            let currentGlobalScheduledMode = 'standard'; 
            window.systemSettings = null;

            function evaluateScheduleMode() {
                if (!window.systemSettings || !window.systemSettings.schedule || !window.systemSettings.schedule.auto) {
                    currentGlobalScheduledMode = 'standard';
                    return;
                }
                
                let d = new Date();
                let currentDay = d.getDay(); 
                
                if (!window.systemSettings.schedule.days.includes(currentDay)) {
                    currentGlobalScheduledMode = 'closed';
                    return;
                }

                let nowTime = d.getHours() * 60 + d.getMinutes();
               let shifts = ['matin', 'midi', 'aprem', 'soir']
                let activeShiftMode = 'standard';
                let isClosed = true;

                for (let s of shifts) {
                    let shift = window.systemSettings.schedule[s];
                    if (shift && shift.s && shift.e) {
                        let startMins = parseInt(shift.s.split(':')[0])*60 + parseInt(shift.s.split(':')[1]);
                        let endMins = parseInt(shift.e.split(':')[0])*60 + parseInt(shift.e.split(':')[1]);
                        
                        if (startMins > endMins) {
                            if (nowTime >= startMins || nowTime <= endMins) { activeShiftMode = shift.mode || 'standard'; isClosed = false; break; }
                        } else {
                            if (nowTime >= startMins && nowTime <= endMins) { activeShiftMode = shift.mode || 'standard'; isClosed = false; break; }
                        }
                    }
                }
                currentGlobalScheduledMode = isClosed ? 'closed' : activeShiftMode;
            }

            if(clockInterval) clearInterval(clockInterval);
            if(syncInterval) clearInterval(syncInterval);
            
            const updateClock = () => { const c = document.getElementById('empire-clock'); if(c) c.innerText = new Date().toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'}); };
            updateClock(); clockInterval = setInterval(updateClock, 1000); 
            if (typeof syncData === 'function') { syncData(); syncInterval = setInterval(syncData, 3000); }
        }

        // =========================================================
        // iCHEF — FILTRE CENTRAL DES VRAIES COMMANDES
        // =========================================================
        function isIchefSystemStateKey(key) {
            const k = String(key || '').toUpperCase();
            return (
                k === 'ARCHITECTURE' ||
                k.includes('_MASTER') ||
                k.startsWith('MENU_') ||
                k.startsWith('CATEGORIES_') ||
                k.startsWith('SETTINGS_') ||
                k.startsWith('FINANCIAL_') ||
                k.startsWith('TRAFFIC_') ||
                k.startsWith('LOYALTY_') ||
                k.startsWith('TIMESHEETS_') ||
                k.startsWith('STAFF_') ||
                k.startsWith('RESERVATIONS_') ||
                k.startsWith('ALERTS_')
            );
        }

        function hasRealOrderItem(order) {
            const items = Array.isArray(order?.items) ? order.items : [];
            return items.some(item => {
                if (!item || typeof item !== 'object') return false;
                const name = String(
                    item.n ?? item.name ?? item.productName ?? item.title ?? item.label ?? ''
                ).trim();
                const qty = Number(item.qty ?? item.quantity ?? 1);
                return name.length > 0 && Number.isFinite(qty) && qty > 0;
            });
        }

        function hasRealActiveReservation(order) {
            if (!order || typeof order !== 'object') return false;

            const reservationId =
                order.reservationId || order.bookingId ||
                order.reservation?.id ||
                order.reservation?.reservationId ||
                order.reservation?.bookingId;

            if (!reservationId) return false;

            const status = String(
                order.reservationStatus ||
                order.reservation?.status ||
                order.status ||
                ''
            ).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();

            return [
                'reserved','reserve','confirmed','confirmee',
                'arrived','arrive','seated','installed','installe'
            ].includes(status);
        }

        function isRealServiceOrder(key, order) {
            if (isIchefSystemStateKey(key)) return true;
            if (!order || typeof order !== 'object') return false;
            return hasRealOrderItem(order) || hasRealActiveReservation(order);
        }

        function sanitizeServerOrders(rawOrders) {
            const src = rawOrders && typeof rawOrders === 'object' ? rawOrders : {};
            const clean = {};
            const ghosts = [];

            for (const [key, value] of Object.entries(src)) {
                if (isIchefSystemStateKey(key)) {
                    clean[key] = value;
                } else if (isRealServiceOrder(key, value)) {
                    clean[key] = value;
                } else {
                    ghosts.push(key);
                }
            }

            if (!window.__ichefGhostDeleteSent) {
                window.__ichefGhostDeleteSent = new Set();
            }

            ghosts.forEach(key => {
                if (window.__ichefGhostDeleteSent.has(key)) return;
                window.__ichefGhostDeleteSent.add(key);

                Promise.resolve().then(async () => {
                    try {
                        if (typeof API !== 'undefined' && API?.update && currentUser) {
                            await API.update(key, null, true);
                        }
                    } catch (err) {
                        window.__ichefGhostDeleteSent.delete(key);
                    }
                });
            });

            return clean;
        }

        async function syncData() {
            if (isArchiMode) return; 
            try {
                const state = await API.getState();
                if (state && state.activeOrders) {
                    let nO = state.activeOrders;

                    if (nO['SETTINGS_MASTER'] && nO['SETTINGS_MASTER'].data) {
                        window.systemSettings = nO['SETTINGS_MASTER'].data;
                        try { refreshFiscalProfileUI(); } catch(e) {}
                        isServiceAuBarActive = window.systemSettings.serviceAuBar === true;
                        
                        if (window.systemSettings.loyalty) {
                            isLoyaltyActive = window.systemSettings.loyalty.active === true;
                            loyaltyPercent = window.systemSettings.loyalty.percent || 5;
                        }

                        let badgeBar = document.getElementById('badge-service-bar');
                        if (badgeBar) {
                            badgeBar.style.display = isServiceAuBarActive ? 'flex' : 'none';
                        }

                        updateCashRegisterBadge();

                        // 🔥 SYNCHRO ANTI-RUSH & TIME-SHIFTING 🔥
                        currentRushLevel = window.systemSettings.rushLevel || 0;
                        rushV3Settings = window.systemSettings.rushV3 || { cameleon: false, timeShift: { active: false, discount: 5, delay: 15 }, paceMaker: { active: false, max: 10 } };
                        isKitchenInRush = (currentRushLevel >= 4); // Alerte critique sur la caisse uniquement si niveau 4 ou 5
                        
                        let globalRushAlert = document.getElementById('global-rush-alert');
                        if(globalRushAlert) {
                            if (isKitchenInRush) {
                                globalRushAlert.style.display = 'block';
                            } else {
                                globalRushAlert.style.display = 'none';
                            }
                        }
                    }

                    if(nO['LOYALTY_MASTER'] && nO['LOYALTY_MASTER'].data) {
                        globalLoyaltyData = nO['LOYALTY_MASTER'].data;
                    }
                    
                    if(nO['TIMESHEETS_MASTER'] && nO['TIMESHEETS_MASTER'].data) {
                        globalTimesheets = nO['TIMESHEETS_MASTER'].data;
                    }

                    /* Normalisation uniquement des vraies commandes.
                       Une ligne vide n'est plus transformée en faux "Plat QR". */
                    for (let key in nO) {
                        if (isIchefSystemStateKey(key)) continue;

                        if (
                            nO[key] &&
                            nO[key].data !== undefined &&
                            !Array.isArray(nO[key].data)
                        ) {
                            nO[key] = nO[key].data;
                        }

                        if (nO[key] && Array.isArray(nO[key].items)) {
                            nO[key].items = nO[key].items.filter(
                                i => i && typeof i === 'object'
                            );

                            nO[key].items.forEach(i => {
                                if (i.name && !i.n) i.n = i.name;
                                if (i.productName && !i.n) i.n = i.productName;
                                if (i.title && !i.n) i.n = i.title;
                                if (i.price !== undefined && i.p === undefined) i.p = i.price;
                                if (i.category && !i.dest) i.dest = i.category;
                                if (i.n && !i.dest) i.dest = 'cuisine';

                                /* Qui mange quoi ? — compatibilité QR/API */
                                if (typeof window.ichefNormalizeQrGuestFields === 'function') {
                                    window.ichefNormalizeQrGuestFields({items:[i]});
                                }
                            });
                        }
                    }

                    nO = sanitizeServerOrders(nO);
                    
// RECUPERATION DES CATEGORIES
categoriesCuisine = nO['CATEGORIES_CUISINE']?.data || [];
categoriesBar = nO['CATEGORIES_BAR']?.data || [];
categoriesPatisserie = nO['CATEGORIES_PATISSERIE']?.data || [];
unifiedCategories = [...categoriesCuisine, ...categoriesBar, ...categoriesPatisserie];

// RECUPERATION DES PLATS
if(nO['MENU_MASTER']?.data) menuCuisine = nO['MENU_MASTER'].data;
if(nO['MENU_MASTER_BAR']?.data) menuBar = nO['MENU_MASTER_BAR'].data;
let menuPatisserie = nO['MENU_MASTER_PATISSERIE']?.data || {};

// FUSION GLOBALE
unifiedMenu = { ...menuCuisine, ...menuBar, ...menuPatisserie };

// ACTUALISATION DE L'AFFICHAGE DES ONGLETS
renderDynamicCategories();
                    
                    if(nO['STAFF_ACCESS']?.data) staffAccessData = nO['STAFF_ACCESS'].data;
                    if(nO['RESERVATIONS_MASTER']?.data) reservationsData = nO['RESERVATIONS_MASTER'].data;
                    
                    if (state.sasConfig) {
                        localSasConfig = state.sasConfig;
                        if(typeof updateSASButtonUI === 'function') updateSASButtonUI();
                    }

                    if (nO['ARCHITECTURE']) {
                        let archiData = nO['ARCHITECTURE'].data !== undefined
                            ? nO['ARCHITECTURE'].data
                            : nO['ARCHITECTURE'];

                        if (!isDraggingTable && archiData && Array.isArray(archiData.tables)) {
                            const serverTables = archiData.tables;
                            const serverRooms = Array.isArray(archiData.rooms) && archiData.rooms.length
                                ? archiData.rooms
                                : ['Salle Principale'];
                            const serverZones = Array.isArray(archiData.zones)
                                ? archiData.zones
                                : [];

                            // Ne remplace pas un plan local existant par un plan serveur vide
                            const acceptServerPlan =
                                serverTables.length > 0 || !Array.isArray(tables) || tables.length === 0;

                            if (acceptServerPlan) {
                                serverTables.forEach(t => {
                                    if (t && !t.room) t.room = serverRooms[0] || 'Salle Principale';
                                });
                                serverZones.forEach(z => {
                                    if (z && !z.room) z.room = serverRooms[0] || 'Salle Principale';
                                });

                                rooms = serverRooms;
                                tables = serverTables;
                                zones = serverZones;

                                if (!rooms.includes(currentRoom)) {
                                    currentRoom = rooms[0] || 'Salle Principale';
                                }

                                localStorage.setItem('empire_architecture', JSON.stringify(tables));
                                localStorage.setItem('empire_rooms', JSON.stringify(rooms));
                                localStorage.setItem('empire_zones', JSON.stringify(zones));

                                renderRooms();
                                renderFloor();
                            }
                        }
                    }
                    
                   if (currentTableId && nO[currentTableId]) {
    let serverOrder = nO[currentTableId];
    if (serverOrder && serverOrder.items) {
        notifyReadySequences(serverOrder, currentTableId);
        // 🔒 COMPARAIISON PROFONDE : Détecte tout changement (Statut Prêt, Quantité, Prix, Erreur...)
        let serverHash = JSON.stringify(serverOrder.items);
        let localHash = JSON.stringify(currentTicket);
        
        if (serverHash !== localHash) {
            currentTicket = JSON.parse(serverHash);
            renderTicket();
        }
    }
}

                    Object.keys(nO).forEach(tableKey => {
                        if (
                            (tableKey.startsWith('T') || tableKey.startsWith('W') || tableKey.startsWith('order_') || tableKey.startsWith('WEB_')) &&
                            nO[tableKey] && Array.isArray(nO[tableKey].items)
                        ) {
                            notifyReadySequences(nO[tableKey], tableKey);
                        }
                    });

                    activeOrders = sanitizeServerOrders(nO);
                    if(typeof window.ichefUpdateAntiRushSignal==="function"){
                        window.ichefUpdateAntiRushSignal();
                    }
                    checkGlobalAlerts();
                    if(!isDraggingTable && !isArchiMode) renderFloor();
                }
            } catch(e) {}
        }

        async function checkGlobalAlerts() {
            let alerts = activeOrders['ALERTS_MASTER'];
            if (alerts && alerts.data && alerts.data.type === 'RING') {
                let banner = document.getElementById('drawer-alert-banner');
                let msgBox = document.getElementById('drawer-alert-msg');
                
                if(document.getElementById('order-drawer').classList.contains('open')) {
                    if (banner) {
                        banner.style.display = 'flex'; 
                        msgBox.innerText = alerts.data.message;
                    }
                } else {
                    alert(alerts.data.message);
                }

                try {
                    let audio = new Audio('data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...');
                    audio.play().catch(e=>{});
                } catch(e){}
                
                await API.update('ALERTS_MASTER', { cleared: true, clearedAtClient: new Date().toISOString() }, false, { reason: 'Acquittement alerte' });
            }
        }

        async function acknowledgeChefAlert() {
            document.getElementById('drawer-alert-banner').style.display = 'none';
        }

        function openAdminCatalog() {
            if (!currentUser || currentUser.role !== 'Manager') return alert("⛔ Accès Manager requis");
            document.getElementById('admin-catalog-modal').classList.add('open');
            document.getElementById('sas-max-input').value = localSasConfig.maxTables || 5;
            document.getElementById('sas-time-input').value = localSasConfig.delay || 60;
        }

        function closeAdminCatalog() { document.getElementById('admin-catalog-modal').classList.remove('open'); }

        function toggleSAS() {
            localSasConfig.active = !localSasConfig.active;
            updateSASButtonUI();
        }

        function updateSASButtonUI() {
            const btn = document.getElementById('btn-sas-toggle');
            if(!btn) return;
            if(localSasConfig.active) {
                btn.innerHTML = "✅ ACTIVÉ";
                btn.style.borderColor = "var(--gold)"; btn.style.color = "var(--gold)";
            } else {
                btn.innerHTML = "❌ DÉSACTIVÉ";
                btn.style.borderColor = "var(--border)"; btn.style.color = "var(--text-muted)";
            }
        }

        async function sendSASConfig() {
            localSasConfig.maxTables = document.getElementById('sas-max-input').value;
            localSasConfig.delay = document.getElementById('sas-time-input').value;
            try {
                const state = await API.getState();
                let systemSettingsTemp = (state.activeOrders && state.activeOrders['SETTINGS_MASTER']) ? state.activeOrders['SETTINGS_MASTER'].data : {};
                await API.update('SETTINGS_MASTER', { ...systemSettingsTemp, sasConfig: localSasConfig });
                alert("✅ SAS Configuré");
            } catch(e) { alert("Erreur réseau"); }
        }

        function toggleRushMode() {
            isRushMode = !isRushMode;
            document.body.classList.toggle('rush-mode', isRushMode);
            let btn = document.getElementById('btn-rush-toggle');
            if (isRushMode) {
                btn.innerHTML = '🏗️ VUE ARCHI';
                btn.style.borderColor = 'var(--border)'; btn.style.color = 'var(--text-muted)'; btn.style.background = 'transparent';
            } else {
                btn.innerHTML = '⚡ MODE RUSH';
                btn.style.borderColor = 'var(--text-main)'; btn.style.color = 'var(--bg)'; btn.style.background = 'var(--text-main)';
            }
            renderFloor();
        }
function toggleAntiRushPanel() {

    let panel =
        document.getElementById('anti-rush-server-panel');

    const label =
        document.getElementById('anti-rush-toggle-label');

    if (!panel) {

        panel = document.createElement('div');

        panel.id = 'anti-rush-server-panel';

        panel.innerHTML = `
            <div class="anti-rush-server-box">

                <div class="anti-rush-server-icon">
                    🤖
                </div>

                <div class="anti-rush-server-content">

                    <div class="anti-rush-server-title">
                        ANTI-RUSH INTELLIGENT · ORCHESTRATION TEMPS RÉEL
                    </div>

                    <div class="anti-rush-server-status">
                        Service
                        <strong id="server-rush-level">CALME</strong>
                        · attente estimée
                        <strong id="server-rush-wait">10 min</strong>
                    </div>

                    <div class="anti-rush-server-load">
                        Cuisine
                        <strong id="server-rush-cuisine">0%</strong>
                        · Bar
                        <strong id="server-rush-bar">0%</strong>
                        · Pass
                        <strong id="server-rush-pass">0%</strong>
                        ·
                        <span id="server-rush-message">
                            → Charge stable
                        </span>
                    </div>

                </div>

            </div>
        `;

        const menu =
            document.getElementById('service-tools-bar');

        if (menu) {
            menu.insertAdjacentElement(
                'afterend',
                panel
            );
        }
    }

    const isOpen =
        panel.classList.contains('open');

    if (isOpen) {

        panel.classList.remove('open');

        if (label) {
            label.textContent = 'ANTI-RUSH';
        }

    } else {

        panel.classList.add('open');

        if (label) {
            label.textContent = '↩ RETOUR';
        }

        updateAntiRushServerPanel();
    }
}

function updateAntiRushServerPanel() {

    try {

        const orders =
            Object.values(activeOrders || {})
                .filter(order =>
                    order &&
                    typeof order === 'object' &&
                    Array.isArray(order.items)
                );

        let cuisineItems = 0;
        let barItems = 0;
        let totalItems = 0;

        orders.forEach(order => {

            (order.items || []).forEach(item => {

                totalItems++;

                const category =
                    String(
                        item.category ||
                        item.cat ||
                        ''
                    ).toLowerCase();

                if (
                    category.includes('bar') ||
                    category.includes('boisson')
                ) {
                    barItems++;
                } else {
                    cuisineItems++;
                }
            });
        });

        const cuisineLoad =
            Math.min(
                100,
                Math.round(cuisineItems * 8)
            );

        const barLoad =
            Math.min(
                100,
                Math.round(barItems * 10)
            );

        const passLoad =
            Math.min(
                100,
                Math.round(totalItems * 6)
            );

        const maxLoad =
            Math.max(
                cuisineLoad,
                barLoad,
                passLoad
            );

        let level = 'CALME';
        let wait = '10 min';
        let message = '→ Charge stable';

        if (maxLoad >= 80) {

            level = 'CRITIQUE';
            wait = '30+ min';
            message = '→ Forte saturation';

        } else if (maxLoad >= 60) {

            level = 'TENDU';
            wait = '20 min';
            message = '→ Charge élevée';

        } else if (maxLoad >= 35) {

            level = 'ACTIF';
            wait = '15 min';
            message = '→ Service soutenu';
        }

        const levelEl =
            document.getElementById(
                'server-rush-level'
            );

        if (levelEl)
            levelEl.textContent = level;

        const waitEl =
            document.getElementById(
                'server-rush-wait'
            );

        if (waitEl)
            waitEl.textContent = wait;

        const cuisineEl =
            document.getElementById(
                'server-rush-cuisine'
            );

        if (cuisineEl)
            cuisineEl.textContent =
                cuisineLoad + '%';

        const barEl =
            document.getElementById(
                'server-rush-bar'
            );

        if (barEl)
            barEl.textContent =
                barLoad + '%';

        const passEl =
            document.getElementById(
                'server-rush-pass'
            );

        if (passEl)
            passEl.textContent =
                passLoad + '%';

        const messageEl =
            document.getElementById(
                'server-rush-message'
            );

        if (messageEl)
            messageEl.textContent =
                message;

    } catch (error) {

        console.error(
            'Erreur Anti-Rush serveur :',
            error
        );
    }
}

        async function openDashboard() {
            if (!currentUser || currentUser.role !== 'Manager') {
                return alert("⛔ Accès Direction requis");
            }

            document.getElementById('dashboard-modal').classList.add('open');
            await refreshDashboardDirection(true);
        }

        function closeDashboard() { document.getElementById('dashboard-modal').classList.remove('open'); }

        function openPlanningModal() { document.getElementById('planning-modal').classList.add('open'); renderPlanning('today'); }
        function closePlanningModal() { document.getElementById('planning-modal').classList.remove('open'); }
        function renderPlanning(day) {
            document.getElementById('btn-plan-today').classList.remove('gold'); document.getElementById('btn-plan-today').style.background = 'transparent'; document.getElementById('btn-plan-today').style.borderColor = 'var(--border)'; document.getElementById('btn-plan-today').style.color = 'var(--text-muted)';
            document.getElementById('btn-plan-tomorrow').classList.remove('gold'); document.getElementById('btn-plan-tomorrow').style.background = 'transparent'; document.getElementById('btn-plan-tomorrow').style.borderColor = 'var(--border)'; document.getElementById('btn-plan-tomorrow').style.color = 'var(--text-muted)';
            
            if(day === 'today') { document.getElementById('btn-plan-today').style.borderColor = 'var(--gold)'; document.getElementById('btn-plan-today').style.color = 'var(--gold)'; } 
            else { document.getElementById('btn-plan-tomorrow').style.borderColor = 'var(--gold)'; document.getElementById('btn-plan-tomorrow').style.color = 'var(--gold)'; }

            const container = document.getElementById('planning-content');
            let now = new Date(); if (day === 'tomorrow') now.setDate(now.getDate() + 1);
            let targetDate = now.toISOString().split('T')[0];

            let filteredResas = reservationsData.filter(r => r.date === targetDate && r.status !== 'rejected');
            filteredResas.sort((a, b) => (a.time || "00:00").localeCompare(b.time || "00:00"));

            if (typeof window.ichefRefreshReservationTableColors==='function') window.ichefRefreshReservationTableColors();
            if (filteredResas.length === 0) { container.innerHTML = `<div style="text-align:center; padding: 40px; color:var(--text-muted); font-weight: 300;">Aucune réservation.</div>`; return; }

            container.innerHTML = filteredResas.map(r => {
                let pax = parseInt(r.couverts) || parseInt(r.pax) || parseInt(r.personnes) || '?';
                let obsHtml = r.obs ? `<div style="color:var(--gold); font-size:0.75rem; margin-top:5px; font-weight:500; letter-spacing: 1px;">⚠️ ${r.obs}</div>` : '';
                let phoneHtml = r.phone ? `<div style="color:var(--text-muted); font-size:0.75rem; letter-spacing: 1px;">📞 ${r.phone}</div>` : '';
                
                let assignBtn = '';
                const assignedTable = String(
                    r.assignedTable || r.tableId || r.table || ''
                ).trim();

                if(r.date === new Date().toISOString().split('T')[0] && !assignedTable) {
                    if (currentUser && currentUser.role === 'Manager') {
                        assignBtn = `
                            <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
                                <button class="btn-mini gold"
                                    style="padding:9px;border-radius:2px;"
                                    onclick="ichefOpenReservationTableChooser(${JSON.stringify(r.id)})">
                                    📍 CHOISIR TABLE
                                </button>
                                <button class="btn-mini"
                                    style="padding:9px;border-radius:2px;border-color:#a855f7;color:#d8b4fe;"
                                    onclick="ichefSuggestOneReservation(${JSON.stringify(r.id)})">
                                    🧠 AIDE IA
                                </button>
                            </div>`;
                    } else {
                        assignBtn = `<div style="color:var(--text-muted);font-size:.7rem;font-weight:500;border:1px solid var(--border);padding:4px 8px;border-radius:2px;">🔒 MANAGER</div>`;
                    }
                } else if (assignedTable) {
                    assignBtn = `
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:5px;">
                            <div style="color:#f0abfc;font-weight:800;font-size:.85rem;letter-spacing:1px;">
                                📍 TABLE ${assignedTable}
                            </div>
                            <button class="btn-mini"
                                style="padding:6px 8px;font-size:.65rem;"
                                onclick="ichefOpenReservationTableChooser(${JSON.stringify(r.id)})">
                                CHANGER
                            </button>
                        </div>`;
                }

                let statusIcon = r.status === 'confirmed' ? '🟢' : '⏳';

                return `
                <div style="background:transparent; border:1px solid var(--border-strong); padding:15px; border-radius:4px; display:flex; align-items:center; gap:20px;">
                    <div style="color:var(--text-main); font-size:1.3rem; font-weight:300; width: 70px; text-align: center; font-family: 'Playfair Display', serif;">${r.time || '??:??'}</div>
                    <div style="flex:1;">
                        <div style="color:var(--text-main); font-weight:500; font-size:1rem; text-transform:uppercase; letter-spacing: 1px;">${statusIcon} ${r.name || 'Client'}</div>
                        ${phoneHtml}${obsHtml}
                    </div>
                    <div style="display:flex; flex-direction:column; align-items:flex-end; gap:10px;">
                        <div style="color:var(--text-muted); font-weight:500; font-size:0.85rem; letter-spacing: 2px;">${pax} PAX</div>
                        ${assignBtn}
                    </div>
                </div>`;
            }).join('');
        }

        async function autoAssignToday() {
            if (!currentUser || currentUser.role !== 'Manager') return alert("⛔ Accès Manager requis");
            let todayStr = new Date().toISOString().split('T')[0];
            let resasToAssign = reservationsData.filter(r => r.date === todayStr && r.status === 'confirmed' && !r.assignedTable);
            if (resasToAssign.length === 0) return alert("Aucune réservation en attente d'assignation pour aujourd'hui.");

            const state = await API.getState();
            let currentOrders = state.activeOrders || {};
            let updatesCount = 0;

            for (let resa of resasToAssign) {
                let availableTables = tables.filter(t => {
                    let o = currentOrders[t.label];
                    if (o && (o.status === 'reserved' || (o.items && o.items.length > 0))) return false;
                    if (t.isExtra) return false; 
                    return t.pax >= resa.couverts;
                });

                if (availableTables.length > 0) {
                    availableTables.sort((a, b) => a.pax - b.pax);
                    let bestTable = availableTables[0];
                    const reservationId = String(
                        resa.id || resa.reservationId || resa.bookingId ||
                        `RESA_${Date.now()}_${Math.random().toString(36).slice(2,7)}`
                    );
resa.id = resa.id || reservationId;
                    resa.reservationId = reservationId;
                    resa.bookingId = resa.bookingId || reservationId;
                    resa.assignedTable = bestTable.label;
                    resa.tableId = bestTable.label;
                    resa.table = bestTable.label;
                    resa.status = resa.status || 'confirmed';
                    updatesCount++;
                }
            }

            if (updatesCount > 0) {
                await API.update('RESERVATIONS_MASTER', reservationsData);
                alert(`✅ ${updatesCount} table(s) assignée(s) automatiquement.`);
                renderPlanning('today'); renderFloor();
            } else alert("⚠️ Aucune table disponible n'a été trouvée.");
        }

        let pendingAssignResa = null;
        function startAssignResa(resaId) {
            let res = reservationsData.find(r =>
                String(r.id || r.reservationId || r.bookingId) === String(resaId)
            );
            if(!res) return;
            pendingAssignResa = res; closePlanningModal();
            document.body.classList.add('assign-mode');
            document.getElementById('assign-overlay').style.display = 'flex';
        }
        function cancelAssignResa() { pendingAssignResa = null; document.body.classList.remove('assign-mode'); document.getElementById('assign-overlay').style.display = 'none'; }
        
        async function assignTableToResa(tableLabel) {
            if(!pendingAssignResa) return;
            if(activeOrders[tableLabel] && activeOrders[tableLabel].status !== 'ready' && activeOrders[tableLabel].items && activeOrders[tableLabel].items.length > 0) {
                if(!confirm(`La table ${tableLabel} semble occupée. Voulez-vous écraser ?`)) return;
            }
            const reservationId = String(
                pendingAssignResa.id ||
                pendingAssignResa.reservationId ||
                pendingAssignResa.bookingId ||
                `RESA_${Date.now()}_${Math.random().toString(36).slice(2,7)}`
            );
let rIndex = reservationsData.findIndex(r =>
                String(r.id || r.reservationId || r.bookingId) ===
                String(pendingAssignResa.id || pendingAssignResa.reservationId || pendingAssignResa.bookingId)
            );

            if(rIndex > -1) {
                reservationsData[rIndex].id =
                    reservationsData[rIndex].id || reservationId;
                reservationsData[rIndex].reservationId = reservationId;
                reservationsData[rIndex].bookingId =
                    reservationsData[rIndex].bookingId || reservationId;
                reservationsData[rIndex].assignedTable = tableLabel;
                reservationsData[rIndex].tableId = tableLabel;
                reservationsData[rIndex].table = tableLabel;

                await API.update('RESERVATIONS_MASTER', reservationsData, false, {
                    reason:'Affectation réservation table',
                    operationType:'RESERVATION_ASSIGNMENT'
                });
            }
            pendingAssignResa = null;
            document.body.classList.remove('assign-mode');
            document.getElementById('assign-overlay').style.display = 'none';
            if (typeof renderFloor === 'function') renderFloor();
            if (typeof window.ichefReservationSyncNow === 'function') {
                await window.ichefReservationSyncNow(true);
            }
        }

        function escapeHtml(value) {
            return String(value ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function renderRooms() {
            const container = document.getElementById('room-tabs-container');
            if (!container) return;

            container.innerHTML = '';

            rooms.forEach(room => {
                const tab = document.createElement('div');
                tab.className = 'room-tab' + (room === currentRoom ? ' active' : '');
                tab.textContent = room;
                tab.setAttribute('role', 'button');
                tab.setAttribute('tabindex', '0');
                tab.setAttribute('aria-current', room === currentRoom ? 'page' : 'false');
                tab.onclick = () => handleRoomClick(room);
                tab.onkeydown = event => {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        handleRoomClick(room);
                    }
                };
                container.appendChild(tab);
            });

            const antiRushButton = document.createElement('button');
            antiRushButton.type = 'button';
            antiRushButton.className = 'btn-mini';
            antiRushButton.textContent = `🧠 ANTI-RUSH ${Number(currentRushLevel || 0)}/5`;
            antiRushButton.style.cssText = 'background:rgba(239,68,68,.1);border-color:#ef4444;color:#ef4444;margin-left:20px;box-shadow:0 0 10px rgba(239,68,68,.2);';
            antiRushButton.title = 'Détection Anti-Rush cuisine — niveau actuel';
            antiRushButton.onclick = () => {
                window.location.href = 'anti-rush.html?tenantID=' + encodeURIComponent(appTenantID || '');
            };
            container.appendChild(antiRushButton);
        }

        function handleRoomClick(room) {
            if (isArchiMode && room === currentRoom) {
                openRoomConfigModal(room);
                return;
            }
            currentRoom = room;
            renderRooms();
            renderFloor();
        }

        function addNewRoom() {
            let index = rooms.length + 1;
            let name = 'Salle ' + index;
            while (rooms.includes(name)) {
                index += 1;
                name = 'Salle ' + index;
            }
            rooms.push(name);
            currentRoom = name;
            renderRooms();
            renderFloor();
        }

        function addTactileRoomName(value) {
            if (value === 'CLEAR') currentTactileRoomName = currentTactileRoomName.slice(0, -1);
            else currentTactileRoomName += value;
            document.getElementById('config-room-name-display').innerText = currentTactileRoomName;
        }
        
        function openRoomConfigModal(r) { configRoomOldName = r; currentTactileRoomName = r; document.getElementById('config-room-name-display').innerText = currentTactileRoomName; document.getElementById('room-config-modal').style.display = 'flex'; }
        function closeRoomConfigModal() { configRoomOldName = null; document.getElementById('room-config-modal').style.display = 'none'; }
        async function saveRoomConfig() {
            if (!configRoomOldName) return;

            const oldName = configRoomOldName;
            const newName = currentTactileRoomName.trim();

            if (!newName) return alert('Le nom de la salle ne peut pas être vide.');
            if (newName !== oldName && rooms.includes(newName)) {
                return alert('Une salle porte déjà ce nom.');
            }

            if (newName !== oldName) {
                const roomIndex = rooms.indexOf(oldName);
                if (roomIndex > -1) rooms[roomIndex] = newName;

                tables.forEach(table => {
                    if (table && table.room === oldName) table.room = newName;
                });

                zones.forEach(zone => {
                    if (zone && zone.room === oldName) zone.room = newName;
                });

                if (currentRoom === oldName) currentRoom = newName;
            }

            closeRoomConfigModal();
            renderRooms();
            renderFloor();
            await pushArchitecture();
        }

        async function deleteCurrentRoom() {
            if (!configRoomOldName) return;
            if (rooms.length <= 1) return alert('Impossible de supprimer la dernière salle.');

            const roomToDelete = configRoomOldName;
            if (!confirm(`Supprimer la salle "${roomToDelete}", ses tables et ses zones ?`)) return;

            tables = tables.filter(table => table && table.room !== roomToDelete);
            zones = zones.filter(zone => zone && zone.room !== roomToDelete);
            rooms = rooms.filter(room => room !== roomToDelete);
            currentRoom = rooms[0];

            closeRoomConfigModal();
            renderRooms();
            renderFloor();
            await pushArchitecture();
        }

        function unlockArchiMode() { if (!currentUser || currentUser.role !== 'Manager') return alert("⛔ Accès Manager requis"); isArchiMode = true; document.body.classList.add('edit-mode'); renderRooms(); renderFloor(); }
        async function closeArchiMode() { isArchiMode = false; document.body.classList.remove('edit-mode'); renderRooms(); renderFloor(); }
        async function saveArchitecture() {
            const saved = await pushArchitecture();
            if (saved) await closeArchiMode();
        }
        
        async function pushArchitecture() {
            const architecture = {
                rooms: Array.isArray(rooms) ? rooms : [],
                tables: Array.isArray(tables) ? tables : [],
                zones: Array.isArray(zones) ? zones : []
            };

            try {
                await API.update('ARCHITECTURE', architecture);
                localStorage.setItem('empire_architecture', JSON.stringify(architecture.tables));
                localStorage.setItem('empire_rooms', JSON.stringify(architecture.rooms));
                localStorage.setItem('empire_zones', JSON.stringify(architecture.zones));
                return true;
            } catch (error) {
                console.error('Erreur de sauvegarde de l’architecture :', error);
                alert('La sauvegarde du plan a échoué. Vérifiez la connexion au serveur.');
                return false;
            }
        }

        function addNewTable() {
            let nextNum = 1; tables.filter(t => t && t.room === currentRoom).forEach(t => { let m = t.label.match(/\d+/); if(m && parseInt(m[0]) >= nextNum) nextNum = parseInt(m[0]) + 1; });
            tables.push({ label: "T" + nextNum, l: window.innerWidth/2 - 40, t: window.innerHeight/2 - 60, w: 80, h: 120, shape: "rect", pax: 4, room: currentRoom }); 
            renderFloor();
        }
        function addTactileTableName(v) { if(v === 'CLEAR') currentTactileName = currentTactileName.slice(0, -1); else currentTactileName += v; document.getElementById('config-table-name-display').innerText = currentTactileName; }
        function setShape(s) {
            const allowed = ['oval','rect','losange','triangle'];
            if (!allowed.includes(s)) return;

            const input = document.getElementById('config-table-shape');
            if (input) input.value = s;

            // Retour visuel immédiat : la forme choisie devient dorée.
            document.querySelectorAll('#table-config-modal .shape-btn').forEach(btn => {
                const match = (btn.getAttribute('onclick') || '').includes(`'${s}'`);
                btn.classList.toggle('shape-selected', match);
                btn.setAttribute('aria-pressed', match ? 'true' : 'false');
            });

            // Petit aperçu directement sur le nom de table.
            const preview = document.getElementById('config-table-name-display');
            if (preview) {
                preview.classList.remove('shape-preview-oval','shape-preview-rect','shape-preview-losange','shape-preview-triangle');
                preview.classList.add('shape-preview-' + s);
            }
        }
        
        function openTableConfigModal(id) {
            let t = tables.find(x => x && x.label === id && x.room === currentRoom); if(!t) return;
            configTableId = id; currentTactileName = t.label; 
            document.getElementById('config-table-name-display').innerText = currentTactileName; 
            document.getElementById('config-table-shape').value = t.shape || 'rect';
            document.getElementById('config-table-pax').value = t.pax || 4; 
            document.getElementById('table-config-modal').style.display = 'flex';
            setShape(t.shape || 'rect');
        }
        function closeTableConfigModal() { configTableId = null; document.getElementById('table-config-modal').style.display = 'none'; }
        function saveTableConfig() {
            let t = tables.find(x => x && x.label === configTableId && x.room === currentRoom);
            if(t) {
                let n = currentTactileName.trim();
                if(n && n !== t.label) { if(activeOrders[t.label]) { activeOrders[n] = activeOrders[t.label]; delete activeOrders[t.label]; } t.label = n; }
                t.shape = document.getElementById('config-table-shape').value;
                t.pax = parseInt(document.getElementById('config-table-pax').value) || 4; 
            }
            closeTableConfigModal();
            renderFloor();
            try { pushArchitecture(); } catch(e) { console.warn('[iCHEF] sauvegarde forme', e); }
        }
        function deleteCurrentTable() { if(confirm("Supprimer cette table ?")) { tables = tables.filter(t => !(t && t.label === configTableId && t.room === currentRoom)); closeTableConfigModal(); renderFloor(); } }
        function changeConfigPax(delta) { let input = document.getElementById('config-table-pax'); let val = parseInt(input.value) || 2; val = Math.max(1, val + delta); input.value = val; }

        function makeInteractive(elmnt, tableObj, resizerElnt) {
            let p1=0, p2=0, p3=0, p4=0, iW, iH, iX, iY;
            elmnt.onmousedown = dragMD; elmnt.ontouchstart = dragTS;
            resizerElnt.onmousedown = resMD; resizerElnt.ontouchstart = resTS;
            function dragMD(e) { if(!isArchiMode || e.target === resizerElnt) return; e.preventDefault(); p3=e.clientX; p4=e.clientY; document.onmouseup=close; document.onmousemove=drag; }
            function dragTS(e) { if(!isArchiMode || e.target === resizerElnt) return; p3=e.touches[0].clientX; p4=e.touches[0].clientY; document.ontouchend=close; document.ontouchmove=tDrag; }
            function drag(e) { e.preventDefault(); isDraggingTable=true; p1=p3-e.clientX; p2=p4-e.clientY; p3=e.clientX; p4=e.clientY; updatePos(); }
            function tDrag(e) { isDraggingTable=true; p1=p3-e.touches[0].clientX; p2=p4-e.touches[0].clientY; p3=e.touches[0].clientX; p4=e.touches[0].clientY; updatePos(); }
            function updatePos() { elmnt.style.top = (elmnt.offsetTop-p2)+"px"; elmnt.style.left = (elmnt.offsetLeft-p1)+"px"; tableObj.t = elmnt.offsetTop; tableObj.l = elmnt.offsetLeft; }
            function resMD(e) { if(!isArchiMode) return; e.preventDefault(); e.stopPropagation(); iW=elmnt.offsetWidth; iH=elmnt.offsetHeight; iX=e.clientX; iY=e.clientY; document.onmouseup=close; document.onmousemove=res; }
            function resTS(e) { if(!isArchiMode) return; e.stopPropagation(); iW=elmnt.offsetWidth; iH=elmnt.offsetHeight; iX=e.touches[0].clientX; iY=e.touches[0].clientY; document.ontouchend=close; document.ontouchmove=tRes; }
            function res(e) { e.preventDefault(); isDraggingTable=true; updateDim(e.clientX, e.clientY); }
            function tRes(e) { isDraggingTable=true; updateDim(e.touches[0].clientX, e.touches[0].clientY); }
            function updateDim(cX, cY) { let nW = Math.max(40, iW+(cX-iX)); let nH = Math.max(40, iH+(cY-iY)); elmnt.style.width=nW+"px"; elmnt.style.height=nH+"px"; tableObj.w=nW; tableObj.h=nH; }
            function close() { document.onmouseup=null; document.onmousemove=null; document.ontouchend=null; document.ontouchmove=null; setTimeout(()=>{isDraggingTable=false; renderFloor(); }, 50); } 
        }

        // --- LOGIQUE DES ZONES ---
        function addNewZone() {
            let nextId = "Z" + (zones.length + 1) + "_" + Date.now();
            zones.push({ id: nextId, label: "Nouvelle Zone", l: 50, t: 50, w: 400, h: 300, room: currentRoom, color: "#3498db", payMode: "standard" });
            renderFloor();
        }
        function openZoneConfigModal(id) {
            let z = zones.find(x => x.id === id && x.room === currentRoom); if(!z) return;
            configZoneId = id;
            document.getElementById('config-zone-name').value = z.label || "";
            document.getElementById('config-zone-mode').value = z.payMode || "standard";
            document.getElementById('config-zone-color').value = z.color || "#3498db";
            document.getElementById('zone-config-modal').style.display = 'flex';
        }
        function closeZoneConfigModal() { configZoneId = null; document.getElementById('zone-config-modal').style.display = 'none'; }
        function saveZoneConfig() {
            let z = zones.find(x => x.id === configZoneId && x.room === currentRoom);
            if(z) {
                z.label = document.getElementById('config-zone-name').value.trim();
                z.payMode = document.getElementById('config-zone-mode').value;
                z.color = document.getElementById('config-zone-color').value;
            }
            closeZoneConfigModal(); renderFloor(); pushArchitecture();
        }
        function deleteCurrentZone() {
            if(confirm("Supprimer cette zone ?")) {
                zones = zones.filter(z => !(z.id === configZoneId && z.room === currentRoom));
                closeZoneConfigModal(); renderFloor(); pushArchitecture();
            }
        }

        // =========================================================
        // ✅ CORRECTIF TABLE → OUVERTURE DU MENU DE COMMANDE
        // =========================================================
        function getZoneForTable(tableLabel) {
            try {
                let tableObj = tables.find(t => t && t.label === tableLabel && t.room === currentRoom);
                if (!tableObj || !Array.isArray(zones)) return null;

                let tableCenterY = (tableObj.t || 0) + ((tableObj.h || 120) / 2);
                let tableCenterX = (tableObj.l || 0) + ((tableObj.w || 80) / 2);

                return zones.find(z =>
                    z.room === currentRoom &&
                    tableCenterX >= (z.l || 0) &&
                    tableCenterX <= ((z.l || 0) + (z.w || 400)) &&
                    tableCenterY >= (z.t || 0) &&
                    tableCenterY <= ((z.t || 0) + (z.h || 300))
                ) || null;
            } catch (e) {
                console.warn("Zone table introuvable :", e);
                return null;
            }
        }

        function checkZoneAccess(tableLabel) {
            const activeZone = getZoneForTable(tableLabel);

            if (activeZone) {
                currentTableZoneLabel = activeZone.label || activeZone.name || "Zone";
                currentTableId_PayMode = activeZone.payMode || activeZone.mode || "standard";
            } else {
                currentTableZoneLabel = "Salle";
                currentTableId_PayMode = "standard";
            }

            // Le Pad serveur doit toujours pouvoir ouvrir la commande.
            // QR/NFC ou BAR changent seulement l'information affichée et le mode d'encaissement.
            return true;
        }

        function handleTableOrderTap(tableOpenKey, tableLabel) {
            try {
                const label = String(tableLabel || tableOpenKey || '').trim();
                if (!label) return;

                if (typeof checkZoneAccess === 'function' && !checkZoneAccess(label)) return;

                /* IMPORTANT :
                   Ouvrir une table vide ne doit JAMAIS créer une commande.
                   La vraie commande sera créée uniquement lorsqu'il existe
                   réellement des articles / une sauvegarde de commande. */
                openOrder(label);

            } catch (err) {
                console.error('Erreur clic table / ouverture commande :', err);
            }
        }

        function renderFloor() {
            try {
                let floor = document.getElementById('floor-plan');
                if (!floor) return;
                floor.innerHTML = '';

                // ✅ Compatibilité anciens plans sans propriété "room"
                const fallbackRoom = currentRoom || rooms[0] || 'Salle Principale';

                if (!Array.isArray(rooms) || rooms.length === 0) {
                    rooms = [fallbackRoom];
                }

                if (!Array.isArray(tables)) tables = [];
                if (!Array.isArray(zones)) zones = [];

                tables.forEach(t => {
                    if (t && !t.room) t.room = fallbackRoom;
                });

                zones.forEach(z => {
                    if (z && !z.room) z.room = fallbackRoom;
                });

                if (!rooms.includes(currentRoom)) {
                    currentRoom = rooms[0] || fallbackRoom;
                }

                let hasTables = tables.some(t => t && t.room === currentRoom);

                if (!hasTables) {
                    console.warn('🪑 PLAN VIDE', {
                        currentRoom,
                        rooms,
                        totalTables: tables.length,
                        tables: tables.map(t => ({ label: t?.label, room: t?.room }))
                    });
                }
                
                let tablesEnAttente = [];
                for (let tLabel in activeOrders) {
                    let order = activeOrders[tLabel];
                    if (order && order.items && order.items.length > 0 && order.status !== 'reserved') {
                        let unfired = order.items.filter(i => !i.fired);
                        let hasReady = order.items.some(i => i.done);
                        if (unfired.length > 0 && !hasReady) tablesEnAttente.push({ label: tLabel, time: Math.min(...unfired.map(i => i.itemId)) });
                    }
                }
                tablesEnAttente.sort((a, b) => a.time - b.time);
                let ordrePriorite = {}; tablesEnAttente.forEach((t, index) => { ordrePriorite[t.label] = index + 1; });
                
                for(let k in activeOrders) { if(activeOrders[k]) delete activeOrders[k]._isMapped; }

                // 🔲 DESSIN DES ZONES SPATIALES
                let zoneContainers = {};
                zones.filter(z => z && z.room === currentRoom).forEach(z => {
                    let wrapper = document.createElement('div'); wrapper.className = 'zone-wrapper';
                    wrapper.setAttribute('data-id', z.id);
                    
                    let bgCol = z.color || '#3498db';
                    let modeIcons = { 'standard': '🍽️ SERVEUR', 'qr_nfc': '📲 QR/NFC', 'bar': '🍹 BAR' };
                    let mode = z.payMode || z.mode || 'standard';
                    let icon = modeIcons[mode] || '🍽️';

                    if (!isRushMode) {
                        wrapper.style.left = (z.l||0)+'px'; wrapper.style.top = (z.t||0)+'px'; wrapper.style.width = (z.w||400)+'px'; wrapper.style.height = (z.h||300)+'px';
                        
                        let d = document.createElement('div'); d.className = 'zone-obj';
                        d.style.borderColor = bgCol;
                        d.style.color = bgCol;
                        d.style.background = `linear-gradient(135deg, ${bgCol}18, transparent)`;
                        d.innerHTML = `<span class="zone-badge" style="color:${bgCol};">${icon} ${z.label}</span>`;
                        
                        let r = document.createElement('div'); r.className = 'zone-resizer';
                        r.style.backgroundColor = bgCol;
                        
                        wrapper.appendChild(d); wrapper.appendChild(r);
                        d.onclick = (e) => { if(isArchiMode) { if(!isDraggingTable && e.target !== r) openZoneConfigModal(z.id); } };
                        if (isArchiMode) makeInteractive(wrapper, z, r);
                    } else {
                        let labelHtml = '';
                        let rushColor = bgCol;
                        if (mode === 'qr_nfc') { rushColor = '#fbbf24'; labelHtml = `ZONE AUTONOME <span style="font-size:0.75rem; font-weight:400; opacity:0.8; margin-left:10px;">💳 PAIEMENT CLIENT (QR)</span>`; } 
                        else if (mode === 'bar') { rushColor = '#ef4444'; labelHtml = `ZONE COMPTOIR <span style="font-size:0.75rem; font-weight:400; opacity:0.8; margin-left:10px;">🚶 RETRAIT & PAIEMENT BAR</span>`; } 
                        else { rushColor = '#10b981'; labelHtml = `ZONE CLASSIQUE <span style="font-size:0.75rem; font-weight:400; opacity:0.8; margin-left:10px;">👨‍🍳 COMMANDE SERVEUR</span>`; }

                        wrapper.style.position = 'relative';
                        wrapper.style.width = '100%';
                        wrapper.style.height = 'auto';
                        wrapper.style.minHeight = '140px';
                        wrapper.style.display = 'flex';
                        wrapper.style.flexWrap = 'wrap';
                        wrapper.style.gap = '15px';
                        wrapper.style.padding = '60px 20px 20px 20px';
                        wrapper.style.border = `2px dashed ${rushColor}`;
                        wrapper.style.borderRadius = '12px';
                        wrapper.style.backgroundColor = `${rushColor}15`;
                        wrapper.style.marginBottom = '15px';

                        let title = document.createElement('div');
                        title.style.position = 'absolute';
                        title.style.top = '15px';
                        title.style.left = '20px';
                        title.innerHTML = `<span style="color:${rushColor}; font-size: 1.1rem; font-weight: 800; letter-spacing: 1px; text-transform: uppercase;">${icon} ${z.label} | ${labelHtml}</span>`;
                        wrapper.appendChild(title);
                    }
                    
                    zoneContainers[z.id] = wrapper;
                    floor.appendChild(wrapper);
                });

                let unassignedWrapper = null;
                if (isRushMode) {
                    unassignedWrapper = document.createElement('div');
                    unassignedWrapper.className = 'zone-wrapper unassigned-zone';
                    unassignedWrapper.style.position = 'relative';
                    unassignedWrapper.style.width = '100%';
                    unassignedWrapper.style.minHeight = '120px';
                    unassignedWrapper.style.display = 'flex';
                    unassignedWrapper.style.flexWrap = 'wrap';
                    unassignedWrapper.style.gap = '15px';
                    unassignedWrapper.style.padding = '50px 20px 20px 20px';
                    unassignedWrapper.style.border = `2px dashed var(--border-strong)`;
                    unassignedWrapper.style.borderRadius = '12px';
                    
                    let title = document.createElement('div');
                    title.style.position = 'absolute';
                    title.style.top = '15px';
                    title.style.left = '20px';
                    title.innerHTML = `<span style="color:var(--text-muted); font-size: 1rem; font-weight: 700; letter-spacing: 1px; text-transform: uppercase;">🍽️ TABLES HORS ZONE</span>`;
                    unassignedWrapper.appendChild(title);
                }

                if (hasTables) {
                    tables.filter(t => t && t.room === currentRoom).forEach(t => {
                        let tStatus = ''; let isActive = false;
                        let orderKey = Object.keys(activeOrders).find(k => k.toLowerCase() === t.label.toLowerCase() || ('t' + k).toLowerCase() === t.label.toLowerCase() || k.toLowerCase().replace(/[^a-z0-9]/gi, '') === t.label.toLowerCase().replace(/[^a-z0-9]/gi, ''));
                        let orderData = orderKey ? activeOrders[orderKey] : null;
                        if(orderData) orderData._isMapped = true;

                        /* Réservation = source maître indépendante des commandes.
                           Une table affectée à une réservation du jour est violette
                           même si aucune commande n'est encore ouverte. */
                        const todayKey = new Date().toISOString().split('T')[0];
                        const tableReservation = (Array.isArray(reservationsData) ? reservationsData : []).find(resa => {
                            if(!resa) return false;
                            const assigned = String(resa.assignedTable || resa.tableId || resa.table || '').trim();
                            const status = String(resa.status || resa.reservationStatus || '').toLowerCase();
                            const inactive = ['rejected','cancelled','canceled','annule','annulee','completed','done','noshow','no show'].includes(status);
                            return !inactive && resa.date === todayKey && assigned === String(t.label);
                        });

                        let isReady = false;
                        let maxDelayMin = 0;

                        if (orderData && orderData.status === 'PRÊT') isReady = true;
                        if (orderData && orderData.items && orderData.items.length > 0) {
                            let allDone = orderData.items.every(i => i.done);
                            if (allDone) isReady = true;

                            orderData.items.forEach(i => {
                                if (i.isSent && !i.served && i.itemId) {
                                    let delay = (Date.now() - parseInt(i.itemId)) / 60000;
                                    if (delay > maxDelayMin) maxDelayMin = delay;
                                }
                            });
                        }

                        if (orderData) {
                            if (orderData.alerteRouge) tStatus = 'alert';
                            else if (orderData.status === 'EN ATTENTE PAIEMENT') tStatus = 'payment';
                            else if (isReady && isServiceAuBarActive) tStatus = 'ready-bar'; 
                            else if (orderData.items && orderData.items.length > 0) { 
                                isActive = true; tStatus = 'active'; 
                                if (!isReady) {
                                    if (maxDelayMin >= 25) tStatus = 'late';
                                    else if (maxDelayMin >= 15) tStatus = 'warning';
                                }
                            }
                        }

                        /* La réservation colore uniquement une table libre.
                           Une vraie commande active garde sa priorité visuelle. */
                        if (tableReservation && !isActive && tStatus !== 'alert' && tStatus !== 'payment') {
                            tStatus = 'reserved';
                        }

                        let wrapper = document.createElement('div'); wrapper.className = 'table-wrapper';
                        wrapper.setAttribute('data-id', t.label);
                        if(tStatus) wrapper.classList.add('status-' + tStatus);
                        if(t.isExtra) wrapper.classList.add('extra');

                        /* iCHEF FIX DÉFINITIF : l'indicateur réservation fait partie du rendu
                           SYNCHRONE de la table. Il n'est plus dépendant d'un span ajouté après
                           coup par MutationObserver, donc aucun flash lors d'un renderFloor(). */
                        if(tableReservation){
                            let reservationDotState = 'reserved';
                            const reservationStatus = String(tableReservation.status || tableReservation.reservationStatus || '')
                                .normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
                            if(['arrived','arrive','seated','installed','installe'].includes(reservationStatus)){
                                reservationDotState = 'arrived';
                            }else{
                                const reservationTs = Date.parse(`${tableReservation.date || todayKey}T${tableReservation.time || '00:00'}`);
                                if(Number.isFinite(reservationTs)){
                                    const reservationDelta = reservationTs - Date.now();
                                    if(reservationDelta < -15 * 60000) reservationDotState = 'late';
                                    else if(reservationDelta <= 30 * 60000 && reservationDelta >= -15 * 60000) reservationDotState = 'soon';
                                }
                            }
                            wrapper.classList.add('ichef-reservation-dot-' + reservationDotState);
                        }
                        
                        wrapper.style.left=(t.l||0)+'px'; wrapper.style.top=(t.t||0)+'px'; wrapper.style.width=(t.w||80)+'px'; wrapper.style.height=(t.h||120)+'px';

                        let pax = parseInt(t.pax) || 4;
                        /* En mode Architecture, on affiche TOUJOURS la capacité configurée
                           de la table. Une commande active ne doit pas écraser visuellement
                           le nombre de places défini par le Manager. */
                        if (!isArchiMode && orderData && orderData.observations) { let match = orderData.observations.match(/🍽️ (\d+) Couvert\(s\)/); if (match) pax = parseInt(match[1]); }

                        /* iCHEF FIX ARCHITECTURE COUVERTS : la table DOM transporte
                           toujours le même nombre de couverts que la source métier.
                           Le moteur des chaises lit ce data-pax, donc Capture 1 et
                           plan interactif ne peuvent plus diverger (ex. 56C = 7). */
                        wrapper.dataset.pax = String(Math.max(1, pax));
                        wrapper.dataset.shape = String(t.shape || 'rect');

                        let extraPax = parseInt(t.extraPax) || 0;

                       
                        let d = document.createElement('div'); d.className = 'table-obj shape-' + (t.shape || 'rect');
                        let contentHtml = '';
                        if (tStatus === 'alert') contentHtml = `<span style="text-align:center; display:block;">⚠️<br>${t.label || '?'}</span>`;
                        else contentHtml = `<span style="text-align:center; display:block; font-family: 'Playfair Display', serif; font-weight:600;">${t.label || '?'}</span>`;
                        
                        if (isActive && !isReady && maxDelayMin >= 1) {
                            let chronoColor = (tStatus === 'late') ? '#e056fd' : (tStatus === 'warning' ? '#9b59b6' : '#3498db');
                            contentHtml += `<span style="font-size:0.6rem; color:${chronoColor}; margin-top:2px; font-weight:bold; letter-spacing: 1px;">⏱ ${Math.floor(maxDelayMin)} min</span>`;
                        }

                        if(tableReservation && !isActive) {
                             const reservationName = String(tableReservation.name || tableReservation.clientName || 'Client');
                             contentHtml += `<span style="font-size:0.5rem; color:#a855f7; margin-top:4px; font-weight:700; text-transform:uppercase; letter-spacing:1px;">${reservationName.substring(0,10)}</span>`;
                             contentHtml += `<span style="font-size:0.65rem; color:var(--text-main); margin-top:2px; font-weight:400; font-family:'Playfair Display',serif;">${tableReservation.time || ''}</span>`;
                        } else if (orderData && orderData.isWeb) {
                             contentHtml += `<span style="font-size:0.55rem; color:var(--bg); margin-top:5px; font-weight:600; background:var(--text-main); padding:2px 6px; border-radius:2px; letter-spacing: 1px;">WEB</span>`;
                             contentHtml += `<span style="font-size:0.65rem; color:var(--text-main); font-weight:400; margin-top:5px; font-family: 'Playfair Display', serif;">${orderData.totalStr || ''}</span>`;
                        } else if (t.isExtra && t.pax) {
                            contentHtml += `<span style="font-size:0.65rem; color:var(--text-muted); margin-top:5px; font-weight:500; letter-spacing: 1px;">👤 ${t.pax}</span>`;
                        }

                        d.innerHTML = `<div class="table-content">${contentHtml}</div>`;
                        let r = document.createElement('div'); r.className = 'table-resizer'; 
                        wrapper.appendChild(d); wrapper.appendChild(r);
                        
                        let clickTimer = null;
                        d.onclick = (e) => { 
                            if(isArchiMode) { if(!isDraggingTable && e.target !== r) openTableConfigModal(t.label); } 
                            else if(pendingAssignResa) { assignTableToResa(t.label); } 
                            else if (isRushMode) {
                                if (clickTimer == null) { clickTimer = setTimeout(() => { clickTimer = null; handleTableOrderTap(orderKey || t.label, t.label); }, 300); } 
                                else { clearTimeout(clickTimer); clickTimer = null; }
                            } 
                            else { 
                                handleTableOrderTap(orderKey || t.label, t.label); 
                            }
                        };

                        d.ontouchend = (e) => {
                            if (!isArchiMode) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (pendingAssignResa) {
                                    assignTableToResa(t.label);
                                    return;
                                }
                                handleTableOrderTap(orderKey || t.label, t.label);
                            }
                        };

                        makeInteractive(wrapper, t, r); 
                        
                        if (isRushMode) {
                            let tableCenterY = (t.t || 0) + ((t.h || 120) / 2);
                            let tableCenterX = (t.l || 0) + ((t.w || 80) / 2);
                            
                            let activeZone = zones.find(z => 
                                z.room === currentRoom &&
                                tableCenterX >= (z.l || 0) && tableCenterX <= ((z.l || 0) + (z.w || 400)) &&
                                tableCenterY >= (z.t || 0) && tableCenterY <= ((z.t || 0) + (z.h || 300))
                            );

                            if (activeZone && zoneContainers[activeZone.id]) {
                                zoneContainers[activeZone.id].appendChild(wrapper);
                            } else {
                                if (!unassignedWrapper.parentNode) floor.appendChild(unassignedWrapper);
                                unassignedWrapper.appendChild(wrapper);
                            }
                        } else {
                            floor.appendChild(wrapper);
                        }
                    });
                }

                // COMMANDES WEB
                let webOrders = Object.keys(activeOrders).filter(k => {
                    let orderData = activeOrders[k];
                    if (!orderData || orderData._isMapped) return false;
                    let isOrder = k.startsWith('order_') || k.startsWith('W') || k.startsWith('T') || k.startsWith('WEB_');
                    if (!isOrder) return false;
                    if (orderData.items && orderData.items.length > 0) return true;
                    if (orderData.status === 'EN ATTENTE PAIEMENT') return true;
                    if (orderData.isWeb) return true;
                    return false;
                });

                let webStartX = 20; let webStartY = 20;
                webOrders.forEach((orderKey, index) => {
                    let orderData = activeOrders[orderKey];
                    let d = document.createElement('div');
                    
                    let statusClass = 'status-active';
                    let isReady = orderData.status === 'PRÊT' || (orderData.items && orderData.items.length > 0 && orderData.items.every(i => i.done));
                    let maxDelayMin = 0;

                    if (orderData.items && orderData.items.length > 0) {
                        orderData.items.forEach(i => {
                            if (i.isSent && !i.served && i.itemId) {
                                let delay = (Date.now() - parseInt(i.itemId)) / 60000;
                                if (delay > maxDelayMin) maxDelayMin = delay;
                            }
                        });
                    }
                    
                    if (orderData.alerteRouge) statusClass = 'status-alert';
                    else if (orderData.status === 'reserved') statusClass = 'status-reserved';
                    else if (orderData.status === 'EN ATTENTE PAIEMENT') statusClass = 'status-payment';
                    else if (isReady && isServiceAuBarActive) statusClass = 'status-ready-bar';
                    else if (!isReady) {
                        if (maxDelayMin >= 25) statusClass = 'status-late';
                        else if (maxDelayMin >= 15) statusClass = 'status-warning';
                    }
                    
                    d.className = `table-obj shape-rect ${statusClass}`; 
                    
                    if (isRushMode) {
                        d.style.position = 'relative';
                    } else {
                        d.style.left = webStartX + (index * 130) + 'px'; d.style.top = webStartY + 'px';
                    }

                    d.style.width = '110px'; d.style.height = '90px'; d.style.zIndex = '100'; d.style.cursor = 'pointer';

                    let clientName = orderData.clientName ? orderData.clientName.substring(0,12) : 'Client Web';
                    let displayTitle = orderKey.startsWith('WEB_') ? `QR` : `Table ${orderKey}`;

                    let contentHtml = `<span style="color:var(--text-main); font-weight:600; font-size:0.75rem; letter-spacing: 1px;">${displayTitle}</span>`;
                    
                    if (!isReady && maxDelayMin >= 1 && statusClass !== 'status-alert') {
                        let chronoColor = (statusClass === 'status-late') ? '#e056fd' : (statusClass === 'status-warning' ? '#9b59b6' : '#3498db');
                        contentHtml += `<span style="font-size:0.6rem; color:${chronoColor}; margin-top:2px; font-weight:bold;">⏱ ${Math.floor(maxDelayMin)} min</span>`;
                    }

                    if(statusClass === 'status-alert') contentHtml += `<span style="font-size:1.5rem; margin-top:5px;">⚠️</span>`;
                    else {
                        contentHtml += `<span style="font-size:0.65rem; color:var(--text-muted); margin-top:8px; font-weight:400; text-align:center;">${clientName}</span>`;
                        contentHtml += `<span style="font-size:0.75rem; color:var(--gold); font-weight:500; margin-top:5px; font-family: 'Playfair Display', serif;">${orderData.totalStr || ''}</span>`;
                    }

                    d.innerHTML = `<div class="table-content">${contentHtml}</div>`;
                    d.onclick = () => { openOrder(orderKey); };
                    
                    if(isRushMode && unassignedWrapper) {
                        unassignedWrapper.appendChild(d);
                    } else {
                        floor.appendChild(d);
                    }
                });

               // renderTableZoneBadges();
                
            } catch (e) { console.error(e); }
        }

        // ==========================================
        // 🍽️ GESTION DU TIROIR DE COMMANDE 🍽️
        // ==========================================

        // =========================================================
        // 🧾 COMMANDE TOUJOURS VISIBLE — TABLETTE / MOBILE
        // =========================================================
        function ensureOrderMiniBar() {
            let bar = document.getElementById('order-mini-bar');
            if (bar) return bar;

            bar = document.createElement('div');
            bar.id = 'order-mini-bar';
            bar.innerHTML = `
                <div id="order-mini-main" onclick="toggleMobileOrderTicket()">
                    <div id="order-mini-title">🧾 TABLE -- · 0 article</div>
                    <div id="order-mini-last">Aucune saisie</div>
                </div>
                <div id="order-mini-total">0,00 €</div>
                <button id="order-mini-open" type="button" onclick="toggleMobileOrderTicket();event.stopPropagation();">
                    VOIR
                </button>
            `;

            document.body.appendChild(bar);

            if (!document.getElementById('order-add-toast')) {
                const toast = document.createElement('div');
                toast.id = 'order-add-toast';
                document.body.appendChild(toast);
            }

            return bar;
        }

        function getTicketQuantityCount() {
            return (currentTicket || []).reduce(
                (sum, item) => sum + Number(item?.qty || 1),
                0
            );
        }

        function updateOrderMiniBar() {
            ensureOrderMiniBar();

            const title = document.getElementById('order-mini-title');
            const last = document.getElementById('order-mini-last');
            const total = document.getElementById('order-mini-total');
            const button = document.getElementById('order-mini-open');
            const drawer = document.getElementById('order-drawer');

            const count = getTicketQuantityCount();
            const table = currentTableId || '--';

            if (title) {
                title.textContent =
                    `🧾 TABLE ${table} · ${count} article${count > 1 ? 's' : ''}`;
            }

            const lastItem = (currentTicket || []).length
                ? currentTicket[currentTicket.length - 1]
                : null;

            if (last) {
                last.textContent = lastItem
                    ? `Dernier : ${Number(lastItem.qty || 1)}× ${String(lastItem.n || 'Article').replace(/\n/g, ' + ')}`
                    : 'Aucune saisie';
            }

            if (total) {
                total.textContent = typeof formatMoneyPad === 'function'
                    ? formatMoneyPad(Number(currentTableTotal || 0))
                    : `${Number(currentTableTotal || 0).toFixed(2)} €`;
            }

            if (button && drawer) {
                button.textContent = drawer.classList.contains('order-ticket-focus')
                    ? '↩ MENU'
                    : 'VOIR';
            }
        }

        function toggleMobileOrderTicket() {
            const drawer = document.getElementById('order-drawer');
            if (!drawer) return;

            drawer.classList.toggle('order-ticket-focus');
            updateOrderMiniBar();

            if (drawer.classList.contains('order-ticket-focus')) {
                const ticket = drawer.querySelector('.ticket-view');
                if (ticket) ticket.scrollTop = 0;
            }
        }

        function flashAddedItem(itemName, quantity = 1) {
            ensureOrderMiniBar();

            const toast = document.getElementById('order-add-toast');
            if (!toast) return;

            toast.textContent = `✅ +${quantity} ${String(itemName || 'Article').replace(/\n/g, ' + ')}`;
            toast.classList.remove('show');

            // Force un nouveau cycle d'animation.
            void toast.offsetWidth;
            toast.classList.add('show');

            clearTimeout(window.__ichefOrderToastTimer);
            window.__ichefOrderToastTimer = setTimeout(() => {
                toast.classList.remove('show');
            }, 1100);
        }

        function openOrder(tableLabel) {
            const orderDrawer = document.getElementById('order-drawer');
            if (!orderDrawer) {
                console.error("order-drawer introuvable");
                alert("Le tiroir de commande est introuvable dans cette page.");
                return;
            }

            currentTableId = tableLabel;
            currentLoyaltyPhone = null; 
            
            // 🔲 GESTION DU ZONING SPATIAL
            let tableObj = tables.find(t => t && t.label === tableLabel && t.room === currentRoom);

            // BOUTON RETIRER UNIQUEMENT POUR TABLES EXTRA
            let extraBtnHtml = (tableObj && tableObj.isExtra) ? ` <button class="btn-mini" style="border-color:var(--alert); color:var(--alert); padding:4px 8px; margin-left:15px; font-size:0.7rem;" onclick="promptRemoveExtraTable('${tableLabel}')">🗑️ RETIRER</button>` : '';
            document.getElementById('ticket-table-name').innerHTML = "TABLE " + tableLabel + extraBtnHtml;

            let zoneBandeau = document.getElementById('drawer-zone-alert');
            
            if (zoneBandeau) {
                zoneBandeau.style.display = 'none'; 
                
                if (tableObj && typeof zones !== 'undefined') {
                    let tableCenterY = (tableObj.t || 0) + ((tableObj.h || 120) / 2);
                    let tableCenterX = (tableObj.l || 0) + ((tableObj.w || 80) / 2);
                    
                    let activeZone = zones.find(z => 
                        z.room === currentRoom &&
                        tableCenterX >= (z.l || 0) && tableCenterX <= ((z.l || 0) + (z.w || 400)) &&
                        tableCenterY >= (z.t || 0) && tableCenterY <= ((z.t || 0) + (z.h || 300))
                    );

                    if (activeZone) {
                        currentTableZoneLabel = activeZone.label || activeZone.name || 'Zone';
                        currentTableId_PayMode = activeZone.payMode || activeZone.mode; 
                        
                        if (currentTableId_PayMode === 'qr_nfc') {
                            zoneBandeau.style.display = 'block';
                            zoneBandeau.style.borderColor = activeZone.color || 'var(--alert)';
                            zoneBandeau.style.color = activeZone.color || 'var(--alert)';
                            zoneBandeau.style.background = (activeZone.color ? activeZone.color + '15' : 'rgba(239, 68, 68, 0.1)');
                            zoneBandeau.innerHTML = `📲 ZONE QR/NFC : COMMANDE CLIENT AUTONOME — ENCAISSEMENT SÉPARÉ`;
                        } 
                        else if (currentTableId_PayMode === 'bar') {
                            zoneBandeau.style.display = 'block';
                            zoneBandeau.style.borderColor = activeZone.color || '#3498db';
                            zoneBandeau.style.color = activeZone.color || '#3498db';
                            zoneBandeau.style.background = (activeZone.color ? activeZone.color + '15' : 'rgba(52, 152, 219, 0.1)');
                            zoneBandeau.innerHTML = `🍹 ZONE COMPTOIR : RETRAIT ET PAIEMENT AU BAR`;
                        }
                    } else {
                        currentTableId_PayMode = 'standard';
                        currentTableZoneLabel = 'Salle';
                    }
                } else {
                    currentTableId_PayMode = 'standard';
                    currentTableZoneLabel = 'Salle';
                }
            }

            if(activeOrders[tableLabel] && activeOrders[tableLabel].status === 'reserved') {
                currentTicket = [];
                document.getElementById('order-obs').value = activeOrders[tableLabel].observations || '';
            } else {
                currentTicket = (activeOrders[tableLabel] && activeOrders[tableLabel].items) ? JSON.parse(JSON.stringify(activeOrders[tableLabel].items)) : [];
                currentTicket.forEach(i => { if (i.isSent === undefined) i.isSent = true; });
                document.getElementById('order-obs').value = (activeOrders[tableLabel] && activeOrders[tableLabel].observations) ? activeOrders[tableLabel].observations : '';
            }
            
            if (tableObj && tableObj.isExtra && currentTicket.length === 0 && document.getElementById('order-obs').value === '') {
                document.getElementById('order-obs').value = `🍽️ ${tableObj.pax || 1} Couvert(s)`;
            }

            // IMPORTANT : ouvrir le tiroir AVANT les rendus.
            // Ainsi une erreur secondaire du menu ne peut plus empêcher l'ouverture.
            orderDrawer.classList.remove('order-ticket-focus');
            orderDrawer.classList.add('open');
            orderDrawer.style.display = 'flex';

            try { renderSeatBar(); } catch(e) { console.warn('renderSeatBar:', e); }
            try { renderMenu('MenuJour'); } catch(e) { console.warn('renderMenu:', e); }
            try { renderTicket(); } catch(e) { console.warn('renderTicket:', e); }
            try { checkTableAlertState(currentTableId); } catch(e) { console.warn('checkTableAlertState:', e); }
            try { ensureOrderMiniBar(); } catch(e) { console.warn('ensureOrderMiniBar:', e); }
            try { updateOrderMiniBar(); } catch(e) { console.warn('updateOrderMiniBar:', e); }
        }

        function closeOrder() {
            const drawer = document.getElementById('order-drawer');
            if (drawer) {
                drawer.classList.remove('open');
                drawer.classList.remove('order-ticket-focus');

                // IMPORTANT : openOrder() applique un display:flex inline.
                // Il faut donc retirer explicitement cet affichage lors de la fermeture.
                drawer.style.display = 'none';
                drawer.style.removeProperty('visibility');
                drawer.style.removeProperty('opacity');
                drawer.style.removeProperty('pointer-events');
            }

            currentTableId = null;
            currentLoyaltyPhone = null;

            try { updateOrderMiniBar(); } catch(e) {}
            try { renderFloor(); } catch(e) {}
        }

        function checkTableAlertState(tableId) {
            let order = activeOrders[tableId];
            let banner = document.getElementById('drawer-alert-banner');
            let msgBox = document.getElementById('drawer-alert-msg');
            
            let isReady = false;
            if (order && order.status === 'PRÊT') isReady = true;
            if (order && order.items && order.items.length > 0) {
                let allDone = order.items.every(i => i.done);
                if (allDone) isReady = true;
            }

            let sba = document.getElementById('drawer-service-bar-alert');
            if (sba) {
                sba.style.display = (isReady && isServiceAuBarActive) ? 'block' : 'none';
            }

            if (order && order.alerteRouge) {
                banner.style.display = 'flex'; msgBox.innerText = order.alerteRouge;
            } else { banner.style.display = 'none'; }
        }

        // ==========================================
        // 🪑 GESTION DES SIÈGES ET COUVERTS
        // ==========================================
        function renderSeatBar() {
            let pax = 2;
            let obsInput = document.getElementById('order-obs').value;
            let match = obsInput.match(/🍽️ (\d+) Couvert\(s\)/);
            if(match) pax = parseInt(match[1]);
            else { let tObj = tables.find(t => t && t.label === currentTableId); if(tObj && tObj.pax) pax = tObj.pax; }

            let html = `<span style="color:var(--text-muted); font-size:0.75rem; font-weight:500; align-self:center; margin-right:10px; letter-spacing: 1px; text-transform: uppercase;">Cibler :</span>`;
            html += `<button class="btn-mini seat-btn ${currentSeat===0?'gold':''}" onclick="setSeat(0)" style="margin-right: 10px;">🍽️ CENTRE</button>`;
            for(let i=1; i<=pax; i++) { html += `<button class="btn-mini seat-btn ichef-seat-${i} ${currentSeat===i?'gold':''}" data-ichef-seat="${i}" onclick="setSeat(${i})"><span class="ichef-seat-person" aria-hidden="true"></span><span>${i}</span></button>`; }
            html += `<button class="btn-mini" style="background:transparent; border:1px dashed var(--border); display:flex; justify-content:center; align-items:center;" onclick="addExtraSeatToBar()">+</button>`;
            
            let container = document.getElementById('seat-bar-container');
            if(container) container.innerHTML = html;
        }

        function setSeat(s) { currentSeat = s; renderSeatBar(); }
        function addExtraSeatToBar() {
            let maxC = 0; let obsInput = document.getElementById('order-obs').value;
            let match = obsInput.match(/🍽️ (\d+) Couvert\(s\)/);
            if(match) maxC = parseInt(match[1]);
            let newPax = maxC + 1;
            let baseObs = obsInput.replace(/🍽️ \d+ Couvert\(s\)( \| )?/, '').replace(/ \| $/, '').trim();
            document.getElementById('order-obs').value = baseObs === "" ? `🍽️ ${newPax} Couvert(s)` : `🍽️ ${newPax} Couvert(s) | ${baseObs}`;
            let tObj = tables.find(t => t && t.label === currentTableId);
            if (tObj) { tObj.pax = newPax; pushArchitecture(); }
            setSeat(newPax);
        }

// ==========================================
        // 📋 GESTION DE LA CARTE ET AJOUT AU TICKET (SYMBIOSE ADMIN)
        // ==========================================

        // 1. GÉNÉRATION DES ONGLETS DYNAMIQUES
        function renderDynamicCategories() {
            const container = document.getElementById('dynamic-categories-container');
            if (!container) return;

            if (unifiedCategories.length === 0) {
                container.innerHTML = `<span style="color:var(--text-muted); font-size: 0.8rem; font-style: italic;">En attente du menu de l'Administration...</span>`;
                return;
            }

            container.innerHTML = unifiedCategories.map(cat => {
                let isActive = (currentCategory === cat.id);
                return `
                <button class="btn-mini menu-tab ${isActive ? 'gold' : ''}" 
                        style="${isActive ? 'border-color:var(--gold); color:var(--gold);' : 'border-color:var(--border); color:var(--text-muted);'} margin-right: 5px;"
                        onclick="renderMenu('${cat.id}')">
                    📂 ${cat.label.toUpperCase()}
                </button>`;
            }).join('');
        }

        // 2. AFFICHAGE INTELLIGENT DES PLATS
  // 2. AFFICHAGE INTELLIGENT DES PLATS
function renderMenu(categoryId) {
    currentCategory = categoryId;

    // 🔥 NOUVEAU : AUTO-DÉTECTION DE LA SÉQUENCE SELON L'ONGLET
    let lowerCat = String(categoryId).toLowerCase();
    if (lowerCat.includes('boisson') || lowerCat.includes('bar') || lowerCat.includes('vin') || lowerCat.includes('soft')) {
        currentCourseDefault = 0; // Apéritif / Boisson (Envoi direct)
    } else if (lowerCat.includes('entrée') || lowerCat.includes('entree') || lowerCat.includes('tapas') || lowerCat.includes('partager')) {
        currentCourseDefault = 1; // Séquence 1
    } else if (lowerCat.includes('dessert') || lowerCat.includes('glace') || lowerCat.includes('sucré') || lowerCat.includes('patisserie')) {
        currentCourseDefault = 3; // Séquence 3
    } else {
        currentCourseDefault = 2; // Séquence 2 (Plats) par défaut
    }

    let itemsToDisplay = [];

    // Rafraîchir les couleurs des onglets
    renderDynamicCategories();

    // On récupère strictement les plats classés dans cette catégorie...
    if (unifiedMenu[categoryId]) {
        itemsToDisplay = unifiedMenu[categoryId].filter(i => !i.hidden);
    }

            container.innerHTML = itemsToDisplay.map(item => {
                let isSoldOut = (item.stock === 0 || item.stock === "0");
                let cleanName = item.name.replace(/\n/g, '<br>');
                let escapedName = escapeQuotes(item.name);
                let price = parseFloat(item.price) || 0;
                let tvaRate = parseFloat(item.tva) || 10;
                
                let stockHtml = '';
                if (item.stock !== "" && item.stock !== undefined && item.stock > 0) {
                    let badgeClass = 'stock-badge';
                    if (item.stock <= stockAlerts.red) badgeClass += ' alert-red';
                    else if (item.stock <= stockAlerts.orange) badgeClass += ' alert-orange';
                    else if (item.stock <= stockAlerts.yellow) badgeClass += ' alert-yellow';
                    else if (item.stock <= stockAlerts.green) badgeClass += ' alert-green';
                    stockHtml = `<div class="${badgeClass}">${item.stock}</div>`;
                }

                let tagsAlert = '';
                if (item.tags && item.tags.length > 0) {
                    const tagMap = { 'vegan': '🌿', 'vege': '🥗', 'nogluten': '🌾', 'nopork': '🐷', 'spicy': '🌶️', 'lactose': '🥛' };
                    tagsAlert = `<div style="position: absolute; bottom: 8px; left: 10px; font-size: 0.75rem; pointer-events: none; opacity: 0.8;">` + 
                        item.tags.map(t => tagMap[t] || t).join(' ') + 
                    `</div>`;
                }

                // Destination dynamique en fonction de la catégorie
                let isBarItem = (typeof categoriesBar !== 'undefined') ? categoriesBar.find(c => c.id === categoryId) : false;
                let dest = item.dest || (isBarItem ? 'bar' : 'cuisine');
                
                let clickAction = (item.isMenuJour) ? `addMenuToTicket('${escapedName}', ${price}, '${dest}', ${tvaRate})` : `addToTicket('${escapedName}', ${price}, '${dest}', ${tvaRate})`;

                return `
                    <button class="btn-item ${isSoldOut ? 'sold-out' : ''}" onclick="${clickAction}" style="position: relative; padding-bottom: 25px;">
                        ${stockHtml}
                        <span style="pointer-events:none;">${cleanName}</span>
                        ${tagsAlert}
                        <span class="price" style="pointer-events:none; font-family: 'Playfair Display', serif;">${formatMoneyPad(price)}</span>
                    </button>
                `;
            }).join('');
        }

        function escapeQuotes(str) { return String(str).replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/\n/g, '[BR]').replace(/\r/g, ''); }

        // =========================================================
        // 🥩 CUISSON VIANDE — 9 NIVEAUX
        // =========================================================
        const ICHEF_COOKING_LEVELS = [
            'BLEU',
            'ENTRE BLEU ET SAIGNANT',
            'SAIGNANT',
            'ENTRE SAIGNANT ET À POINT',
            'À POINT',
            'ENTRE À POINT ET BIEN CUIT',
            'BIEN CUIT',
            'ENTRE BIEN CUIT ET ULTRA BIEN CUIT',
            'ULTRA BIEN CUIT'
        ];

        function ensureCuissonModal() {
            let modal = document.getElementById('cuisson-modal');
            if (modal) return modal;

            modal = document.createElement('div');
            modal.id = 'cuisson-modal';
            modal.className = 'modal';
            modal.style.zIndex = '99999';

            modal.innerHTML = `
                <div class="ichef-choice-modal-card">
                    <h2 class="ichef-choice-title">🥩 CUISSON</h2>
                    <div class="ichef-choice-subtitle">
                        <strong id="cuisson-item-name" style="color:#fff"></strong><br>
                        Choisissez précisément la cuisson demandée par le client.
                    </div>

                    <div class="ichef-cooking-grid">
                        ${ICHEF_COOKING_LEVELS.map(level => `
                            <button type="button"
                                    class="ichef-cooking-btn"
                                    data-cooking-level="${level.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">
                                ${level}
                            </button>
                        `).join('')}
                    </div>

                    <button type="button"
                            class="pay-btn cancel"
                            style="width:100%;margin:18px 0 0"
                            onclick="cancelCuisson()">
                        ANNULER
                    </button>
                </div>
            `;

            document.body.appendChild(modal);

            // Liaison fiable souris + tactile : ne dépend plus du onclick inline.
            modal.querySelectorAll('.ichef-cooking-btn').forEach(btn => {
                btn.style.pointerEvents = 'auto';
                btn.style.touchAction = 'manipulation';

                const chooseCooking = (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    const level = btn.dataset.cookingLevel;
                    if (!level) return;
                    confirmCuisson(level);
                };

                btn.addEventListener('click', chooseCooking, { passive: false });

                // Fallback tactile pour certains navigateurs/PWA Android.
                btn.addEventListener('touchend', (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    const level = btn.dataset.cookingLevel;
                    if (!level) return;
                    confirmCuisson(level);
                }, { passive: false });
            });

            return modal;
        }

        // =========================================================
        // ➕ / ➖ MODIFICATEURS DE PLAT
        // =========================================================
        let pendingModifierIndex = null;

        function ensureModifierModal() {
            let modal = document.getElementById('item-modifier-modal');
            if (modal) return modal;

            modal = document.createElement('div');
            modal.id = 'item-modifier-modal';
            modal.className = 'modal';
            modal.style.zIndex = '99999';

            modal.innerHTML = `
                <div class="ichef-choice-modal-card">
                    <h2 class="ichef-choice-title">✏️ MODIFIER LE PLAT</h2>
                    <div id="modifier-item-name"
                         class="ichef-choice-subtitle"
                         style="color:#fff;font-weight:800"></div>

                    <div class="ichef-modifier-section add">
                        <div class="ichef-modifier-label add">➕ LE CLIENT VEUT AJOUTER</div>
                        <input id="modifier-add-input"
                               class="ichef-modifier-input"
                               placeholder="Ex : sauce en plus, fromage, bacon, légumes...">

                        <div class="ichef-quick-mods">
                            <button type="button" onclick="appendQuickModifier('add','Sauce en plus')">Sauce +</button>
                            <button type="button" onclick="appendQuickModifier('add','Fromage en plus')">Fromage +</button>
                            <button type="button" onclick="appendQuickModifier('add','Bacon en plus')">Bacon +</button>
                            <button type="button" onclick="appendQuickModifier('add','Garniture en plus')">Garniture +</button>
                        </div>
                    </div>

                    <div class="ichef-modifier-section remove">
                        <div class="ichef-modifier-label remove">➖ LE CLIENT VEUT ENLEVER</div>
                        <input id="modifier-remove-input"
                               class="ichef-modifier-input"
                               placeholder="Ex : sans oignon, sans sauce, sans fromage...">

                        <div class="ichef-quick-mods">
                            <button type="button" onclick="appendQuickModifier('remove','Sans oignon')">Sans oignon</button>
                            <button type="button" onclick="appendQuickModifier('remove','Sans sauce')">Sans sauce</button>
                            <button type="button" onclick="appendQuickModifier('remove','Sans fromage')">Sans fromage</button>
                            <button type="button" onclick="appendQuickModifier('remove','Sans garniture')">Sans garniture</button>
                        </div>
                    </div>

                    <div style="display:flex;gap:8px;margin-top:16px">
                        <button type="button"
                                class="pay-btn"
                                style="flex:1;width:auto;margin:0;border-color:var(--gold);color:var(--gold)"
                                onclick="saveItemModifiers()">
                            ✅ VALIDER
                        </button>

                        <button type="button"
                                class="pay-btn cancel"
                                style="flex:1;width:auto;margin:0"
                                onclick="closeItemModifierModal()">
                            ANNULER
                        </button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            return modal;
        }

        function splitModifierText(value) {
            return String(value || '')
                .split(/[,;|]/)
                .map(v => v.trim())
                .filter(Boolean);
        }

        function appendQuickModifier(type, value) {
            const input = document.getElementById(
                type === 'add' ? 'modifier-add-input' : 'modifier-remove-input'
            );
            if (!input) return;

            const existing = input.value.trim();
            input.value = existing ? `${existing}, ${value}` : value;
            input.focus();
        }

        function openItemModifierModal(idx) {
            const item = currentTicket[idx];
            if (!item) return;

            pendingModifierIndex = idx;
            ensureModifierModal();

            document.getElementById('modifier-item-name').textContent =
                item.n.replace(/\n/g, ' ');

            document.getElementById('modifier-add-input').value =
                Array.isArray(item.modifiers?.add)
                    ? item.modifiers.add.join(', ')
                    : '';

            document.getElementById('modifier-remove-input').value =
                Array.isArray(item.modifiers?.remove)
                    ? item.modifiers.remove.join(', ')
                    : '';

            document.getElementById('item-modifier-modal').classList.add('open');
        }

        function closeItemModifierModal() {
            pendingModifierIndex = null;
            const modal = document.getElementById('item-modifier-modal');
            if (modal) modal.classList.remove('open');
        }

        async function saveItemModifiers() {
            if (pendingModifierIndex === null) return;

            const item = currentTicket[pendingModifierIndex];
            if (!item) return closeItemModifierModal();

            const add = splitModifierText(
                document.getElementById('modifier-add-input')?.value
            );

            const remove = splitModifierText(
                document.getElementById('modifier-remove-input')?.value
            );

            item.modifiers = { add, remove };

            // Copie aussi dans obs pour que les écrans cuisine existants
            // affichent l'information même s'ils ne lisent pas encore "modifiers".
            const cleanObsParts = String(item.obs || '')
                .split(' | ')
                .filter(part =>
                    !part.startsWith('➕ ') &&
                    !part.startsWith('➖ ')
                );

            if (add.length) cleanObsParts.push(`➕ ${add.join(', ')}`);
            if (remove.length) cleanObsParts.push(`➖ ${remove.join(', ')}`);

            item.obs = cleanObsParts.join(' | ');

            closeItemModifierModal();
            renderTicket();

            try {
                await executeSaveTableState(false, true);
            } catch (e) {
                console.warn('Sauvegarde modificateurs différée :', e);
            }

            if (typeof showToast === 'function') {
                showToast('✅ Modification du plat enregistrée');
            }
        }

        // Crée les modales dès que le DOM est prêt.
        document.addEventListener('DOMContentLoaded', () => {
            ensureCuissonModal();
            ensureModifierModal();
        });

        function ichefNeedsMeatCookingChoice(name, dest = 'cuisine') {
            if (String(dest || '').toLowerCase() !== 'cuisine') return false;

            const text = String(name || '')
                .toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '');

            // --- AUCUNE FENÊTRE CUISSON ---
            // Poissons / produits de la mer
            if (/\b(perche|perches|poisson|saumon|thon|cabillaud|dorade|bar de mer|loup|truite|lotte|sole|turbot|merlu|colin|sandre|crevette|gambas|homard|langoustine|moules|calamar|poulpe)\b/.test(text)) {
                return false;
            }

            // Volaille : cuisson sanitaire standard, pas de choix client.
            if (/\b(poulet|volaille|dinde|pintade|coquelet|chapon)\b/.test(text)) {
                return false;
            }

            // Porc : pas de popup dans le flux de service iCHEF.
            if (/\b(porc|cochon|jambon|travers|echine|filet mignon)\b/.test(text)) {
                return false;
            }

            // Plats mijotés / préparations dont la cuisson est définie en cuisine.
            if (/\b(ragout|daube|bourguignon|blanquette|mijote|mijotee|pot au feu|civet|braise|braisee)\b/.test(text)) {
                return false;
            }

            // Tartare / carpaccio : cru par définition, aucun choix de cuisson.
            if (/\b(tartare|carpaccio)\b/.test(text)) {
                return false;
            }

            // --- VRAI CHOIX DE CUISSON CLIENT ---
            // Bœuf
            if (/\b(entrecote|steak|rumsteck|faux filet|filet de boeuf|filet de bœuf|onglet|bavette|cote de boeuf|côte de bœuf|boeuf|bœuf)\b/.test(text)) {
                return true;
            }

            // Burger : le steak peut avoir une cuisson demandée.
            if (/\bburger\b/.test(text)) {
                return true;
            }

            // Canard / agneau
            if (/\b(magret|canard|agneau|gigot|carre d agneau|carré d agneau)\b/.test(text)) {
                return true;
            }

            return false;
        }

        function addToTicket(n, p, dest, tvaRate = 10) { 
            let realName = n.replace(/\[BR\]/g, ' ');
            // ... (la suite de ta fonction addToTicket existante)
            // 🔥 NOUVEAU BLOCAGE ANTI-RUSH 3.0 🔥
            // Si le plat nécessite une cuisson (viande/chaud) ET que la cuisine est en mode RUSH 4 ou 5
            if (isKitchenInRush && currentRushLevel >= 4 && dest === 'cuisine') {
                let isColdPlat = realName.toLowerCase().includes('salade') || realName.toLowerCase().includes('froid') || realName.toLowerCase().includes('tartare') || realName.toLowerCase().includes('glace');
                if (!isColdPlat) {
                    alert(`🛑 ARRÊT DE PRODUCTION !\nLa cuisine est saturée (Niveau ${currentRushLevel}). Veuillez suspendre l'envoi de plats chauds pour le moment ou inciter les clients à commander froid.`);
                }
            }

            // Cuisson demandée UNIQUEMENT lorsqu'il existe un vrai choix client.
            // Important : ne jamais utiliser le mot générique "filet", car il attrape
            // aussi "filets de perches", "filet de poisson", etc.
            if (ichefNeedsMeatCookingChoice(realName, dest)) {
                pendingCuissonItem = { n: realName, p, dest, tvaRate };
                ensureCuissonModal();
                document.getElementById('cuisson-item-name').innerText = realName;
                document.getElementById('cuisson-modal').classList.add('open');
                return;
            }

            // Poisson, volaille, porc, ragoût/mijoté et tous les plats sans choix
            // de cuisson sont ajoutés immédiatement à la commande.
            executeAddToCart(realName, p, dest, currentCourseDefault, n, tvaRate);
        }

        let pendingCuissonItem = null;
        async function confirmCuisson(niv) {
            if (!pendingCuissonItem) {
                console.warn('[iCHEF] Cuisson ignorée : aucun plat en attente.');
                return;
            }

            // Copie avant de fermer le modal, afin de ne jamais perdre la référence.
            const pending = { ...pendingCuissonItem };

            executeAddToCart(
                `${pending.n} (${niv})`,
                pending.p,
                pending.dest,
                currentCourseDefault,
                pending.n,
                pending.tvaRate
            );

            const targetName = `${pending.n} (${niv})`;
            const item = [...currentTicket].reverse().find(i => i.n === targetName);

            if (item) {
                item.cooking = niv;
                item.originalName = pending.n;
            }

            cancelCuisson();
            renderTicket();

            // Sauvegarde immédiate pour que la cuisine reçoive bien la cuisson.
            try {
                await executeSaveTableState(false, true);
            } catch (error) {
                console.warn('[iCHEF] Sauvegarde cuisson différée :', error);
            }

            try {
                updateOrderMiniBar();
            } catch (_) {}
        }

        // Exposition explicite pour compatibilité avec anciens boutons / PWA.
        window.confirmCuisson = confirmCuisson;
        function cancelCuisson() { pendingCuissonItem = null; document.getElementById('cuisson-modal').classList.remove('open'); }

        function executeAddToCart(n, p, dest, courseOverride, originalName, tvaRate = 10) { 
            let cId = courseOverride !== undefined ? courseOverride : currentCourseDefault;
            let seatId = currentSeat; 
            let e = currentTicket.find(i => i.n === n && !i.done && !i.served && !i.isSent && i.course === cId && !i.obs && !i.isOffered && (i.seat || 0) === seatId && i.tva === tvaRate); 
            if(e) e.qty = (e.qty||1)+1; 
            else currentTicket.push({ id: Date.now()+Math.random(), itemId: Date.now(), n: n.replace(/\[BR\]/g, ' '), originalName: (originalName || n).replace(/\[BR\]/g, '\n'), p, tva: tvaRate, qty: 1, done: false, served: false, dest, savedToDB: false, isOffered: false, course: cId, obs: "", modifiers: { add: [], remove: [] }, cooking: null, seat: seatId, guestSeat: seatId, seatNumber: seatId, guestName: "", isSent: false }); 
            renderTicket();
            flashAddedItem(n, 1);
            updateOrderMiniBar();
        }

        function addMenuToTicket(n, p, dest, tvaRate = 10) {
            const cleanMenuName = String(n || '').replace('🌟 ', '').trim();
            const parts = String(n || '').split('[BR]').map(x => x.replace('🌟 ','').trim()).filter(Boolean);
            const menuId = `MENU_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;

            const sequenceParts = parts.length > 1 ? parts : [
                `🥗 Entrée (${cleanMenuName})`,
                `🔥 Plat (${cleanMenuName})`,
                `🍰 Dessert (${cleanMenuName})`
            ];

            sequenceParts.forEach((part,index) => {
                const seq = index + 1;
                const lower = part.toLowerCase();
                let course = lower.includes('dessert') || part.includes('🍰') ? 3
                           : lower.includes('entrée') || lower.includes('entree') || part.includes('🥗') ? 1
                           : 2;

                executeAddToCart(part, index===0 ? p : 0, dest, course, n, tvaRate);

                const added = [...currentTicket].reverse().find(item =>
                    !item.isSent && item.n === part && item.course === course
                );

                if (added) {
                    added.menuId = menuId;
                    added.menuName = cleanMenuName;
                    added.sequence = seq;
                    added.sequenceStatus = 'DRAFT';
                }
            });

            renderTicket();
        }

        // =========================================================
        // 🍽️ SERVICE PAR SÉQUENCES / RÉCLAME
        // =========================================================
        function getItemSequence(item) {
            if (Number(item?.sequence) > 0) return Number(item.sequence);
            const c=Number(item?.course);
            if(c===1)return 1;if(c===2)return 2;if(c===3)return 3;
            return 0;
        }
        function getSequenceMap() {
            const map=new Map();
            currentTicket.forEach((item,idx)=>{
                const s=getItemSequence(item);
                if(s<=0)return;
                if(!map.has(s))map.set(s,[]);
                map.get(s).push({item,idx});
            });
            return new Map([...map.entries()].sort((a,b)=>a[0]-b[0]));
        }
        function getSequenceState(entries) {
            const items=(entries||[]).map(e=>e.item||e);
            if(items.length&&items.every(i=>i.served))return 'SERVED';
            if(items.length&&items.every(i=>i.done))return 'READY';
            if(items.some(i=>i.sequenceStatus==='PRODUCTION'))return 'PRODUCTION';
            if(items.some(i=>i.isSent))return 'WAITING';
            return 'DRAFT';
        }
        function canRequestSequence(seq,map=getSequenceMap()) {
            const keys=[...map.keys()];
            const pos=keys.indexOf(Number(seq));
            if(pos<=0)return true;
            return getSequenceState(map.get(keys[pos-1]))==='SERVED';
        }
        async function requestSequence(seq) {
            const map=getSequenceMap(), entries=map.get(Number(seq));
            if(!entries?.length)return;
            if(!canRequestSequence(Number(seq),map)){
                alert('⏸️ Servez la séquence précédente avant de réclamer la suite.');
                return;
            }
            entries.forEach(({item})=>{
                item.isSent=true;item.done=false;item.served=false;
                item.sequenceStatus='PRODUCTION';item.requestedAt=Date.now();
            });
            renderTicket();
            try{
                await executeSaveTableState(false,true);
                if(typeof showToast==='function')showToast(`🔥 Séquence ${seq} réclamée`);
            }catch(e){console.error(e);}
        }
        function updateSequenceServicePanel() {
            const panel=document.getElementById('sequence-service-panel');
            if(!panel)return;
            const map=getSequenceMap();
            if(!map.size){panel.style.display='none';panel.innerHTML='';return;}
            panel.style.display='block';
            let html='<div style="padding:10px;color:var(--gold);font-weight:900">🍽️ SERVICE DU MENU</div>';
            for(const [seq,entries] of map){
                const state=getSequenceState(entries), allowed=canRequestSequence(seq,map);
                let label=state==='PRODUCTION'?'🔥 EN PRODUCTION':state==='READY'?'🔔 PRÊT':state==='SERVED'?'✅ SERVI':'⏸ EN ATTENTE';
                let btn=(state==='WAITING'||state==='DRAFT')
                    ? `<button onclick="requestSequence(${seq})" ${allowed?'':'disabled'} style="padding:7px 10px">▶ RÉCLAMER</button>`:'';
                html+=`<div style="display:flex;justify-content:space-between;align-items:center;padding:9px;border-top:1px solid #333"><span><b>S${seq}</b> ${label}</span>${btn}</div>`;
            }
            panel.innerHTML=html;
        }

        function renderTicket() {
            let list = document.getElementById('ticket-list');
            let total = 0; let totalHT = 0; let tvaTotals = { '5.5': 0, '10': 0, '20': 0, '0': 0 };
            let htmlByCourse = { 0: '', 1: '', 2: '', 3: '' };
            let courseNames = { 0: '🍸 BOISSONS', 1: '🥗 ENTRÉES', 2: '🔥 PLATS', 3: '🍰 DESSERTS' };

            currentTicket.forEach((i, idx) => {
                if(!i) return; let q = i.qty || 1; 
                let ligneTTC = (parseFloat(i.p)||0) * q;
                total += ligneTTC;

                let rate = parseFloat(i.tva) || 10;
                let ligneHT = ligneTTC / (1 + (rate / 100));
                let ligneTVA = ligneTTC - ligneHT;
                totalHT += ligneHT;
                if(tvaTotals[rate] !== undefined) tvaTotals[rate] += ligneTVA; else tvaTotals[rate] = ligneTVA;

                let cleanName = i.n.replace(/\n/g, ' + ');
                let c = i.course !== undefined ? i.course : 2;
                let seq = getItemSequence(i);
                let seqState = String(i.sequenceStatus || '').toUpperCase();
                let seqPill = seq > 0
                    ? `<span class="sequence-pill ${seqState === 'PRODUCTION' ? 'production' : (i.done ? 'ready' : '')}">S${seq}</span>`
                    : '';
                let statusHtml = ''; let opacityStyle = "";
                
               if (!i.isSent) statusHtml = ``;
                else if (i.served) { statusHtml = `<button class="btn-mini" style="border-color: var(--text-muted); color: var(--text-muted); padding: 4px 8px; font-size: 0.6rem;">SERVI</button>`; opacityStyle = "opacity: 0.4;"; }
              else if (i.done) statusHtml = `<button class="btn-mini" style="background: #10b981; color: #000; border-color: #10b981; padding: 4px 8px; font-size: 0.7rem; font-weight: 800; cursor: pointer; box-shadow: 0 0 10px rgba(16,185,129,0.5);" onclick="markAsServed(${idx}); event.stopPropagation();">✋ RÉCUPÉRER</button>`;
                else statusHtml = `<button class="btn-mini" style="border-color: var(--gold); color: var(--gold); padding: 4px 8px; font-size: 0.6rem;">ATTENTE</button>`;
                
                let seatNo = Math.floor(Number(i.seat || i.guestSeat || i.seatNumber || 0) || 0);
                let seatBadge = (seatNo >= 1 && seatNo <= 9)
                    ? `<span class="ichef-seat-badge ichef-seat-${seatNo}" data-ichef-seat="${seatNo}"><span class="ichef-seat-person" aria-hidden="true"></span><span class="ichef-seat-number">${seatNo}</span>${i.guestName ? ` <span class="ichef-guest-name">${String(i.guestName).replace(/</g,'&lt;').replace(/>/g,'&gt;')}</span>` : ''}</span>`
                    : `<span class="ichef-seat-centre">🍽️ CTR</span>`;
                let priceHtml = i.isOffered ? `<span style="margin-right:10px; font-weight:500; color:var(--gold); font-size: 0.8rem; letter-spacing: 1px;">🎁 OFFERT</span>` : `<span style="margin-right:10px; font-weight:500; font-size: 0.95rem; font-family: 'Playfair Display', serif;">${formatMoneyPad(ligneTTC)}</span>`;
               let obsDisplay = i.obs ? `<span style="font-size:0.7rem; color:var(--gold); margin-left: 5px; font-weight: 500;">⚠️ ${i.obs}</span>` : ``;

                // 🔥 BOUTON D'ERREUR POUR LES PLATS DÉJÀ ENVOYÉS 🔥
                let errorBtnHtml = i.isSent && !i.served ? `<button class="item-error-btn" onclick="openErrorModal(${idx}); event.stopPropagation();">REFAIRE</button>` : `<button class="item-delete-btn" onclick="removeTicketItem(${idx}); event.stopPropagation();">✕</button>`;

                let itemHtml = `
                <div class="ticket-item-row" style="${opacityStyle}">
                    <div style="flex:1; cursor:pointer;" onclick="openEditItem(${idx})">
                        <div style="font-weight:400; font-size:0.95rem; color: var(--text-main);">${seatBadge}${q>1?`<span style="color:var(--gold); font-weight:600;">${q}x</span> `:""}${cleanName||'?'}${seqPill}</div>
                        <div style="display:flex; align-items:center; gap:8px; margin-top:6px;">${statusHtml}${obsDisplay}</div>
                        ${
                            (Array.isArray(i.modifiers?.add) && i.modifiers.add.length) ||
                            (Array.isArray(i.modifiers?.remove) && i.modifiers.remove.length)
                            ? `<div class="ticket-modifiers">
                                ${(i.modifiers?.add || []).map(m => `<span class="ticket-modifier-add">➕ ${m}</span>`).join('')}
                                ${(i.modifiers?.remove || []).map(m => `<span class="ticket-modifier-remove">➖ ${m}</span>`).join('')}
                               </div>`
                            : ''
                        }
                    </div>
                    <div style="display: flex; align-items: center; gap: 7px;">
                        ${priceHtml}
                        <button class="item-modifier-btn"
                                onclick="openItemModifierModal(${idx});event.stopPropagation();"
                                title="Ajouter ou enlever un élément">
                            ±
                        </button>
                        ${errorBtnHtml}
                    </div>
                </div>`;
                htmlByCourse[c] += itemHtml;
            }); 

          let finalHtml = '';
            [0, 1, 2, 3].forEach(c => { 
                if(htmlByCourse[c] !== '') {
                    finalHtml += `
                    <div class="course-card">
                        <div class="course-card-header" onclick="event.stopPropagation(); this.classList.toggle('collapsed'); this.nextElementSibling.classList.toggle('collapsed');">
                            <span class="course-title">${courseNames[c]}</span>
                            <span class="toggle-icon">▼</span>
                        </div>
                        <div class="course-body">
                            ${htmlByCourse[c]}
                        </div>
                    </div>`; 
                }
            });
            
            if(finalHtml === '') finalHtml = `<div style="text-align:center; color:var(--text-muted); font-weight: 300; padding:40px 0; border: 1px dashed var(--border-strong); border-radius: 4px;">En attente de saisie...</div>`;
            
            list.innerHTML = finalHtml;
            document.getElementById('ticket-total-price').innerText = `${formatMoneyPad(total)}`;
            currentTableTotal = total;

            let tvaStr = Object.entries(tvaTotals).filter(([k,v]) => v>0).map(([k,v]) => `TVA ${k}%: ${formatMoneyPad(v)}`).join(' | ');
            if(!tvaStr) tvaStr = "Aucune TVA";
            document.getElementById('ticket-tva').innerText = tvaStr + ` (HT: ${formatMoneyPad(totalHT)})`;

            let hasUnsent = currentTicket.some(i => !i.isSent);
            let btnSend = document.getElementById('btn-send-kds');
            if (hasUnsent) {
                btnSend.style.display = 'block';
            } else {
                btnSend.style.display = 'none';
            }

           updateOrderMiniBar();
            updateSequenceServicePanel();
        } // <--- C'est cette accolade qui manquait pour fermer la fonction renderTicket() !
                            
        // 🔥 LOGIQUE ANTI-RUSH : VÉRIFICATION AVANT ENVOI 🔥
        function processOrderDispatch() {
            if (isKitchenInRush && rushV3Settings.timeShift && rushV3Settings.timeShift.active) {
                let hasHotDishes = currentTicket.some(i => !i.isSent && i.dest === 'cuisine');
                if (hasHotDishes) {
                    document.getElementById('server-ts-discount').innerText = `-${rushV3Settings.timeShift.discount}%`;
                    document.getElementById('server-ts-delay').innerText = `${rushV3Settings.timeShift.delay} min`;
                    document.getElementById('ts-offer-modal').classList.add('open');
                    return; 
                }
            }
            sendOrderToKDS(false);
        }

        function acceptTimeShiftServer() {
            document.getElementById('ts-offer-modal').classList.remove('open');
            let multiplier = 1 - (rushV3Settings.timeShift.discount / 100);
            
            currentTicket.forEach(i => {
                if (!i.isSent) {
                    i.p = i.p * multiplier; 
                    i.timeShifted = true; 
                    i.obs = (i.obs ? i.obs + " | " : "") + `⏱️ DÉCALÉ (+${rushV3Settings.timeShift.delay}m)`;
                }
            });
            
            sendOrderToKDS(true);
            showToast(`✅ Le client a accepté l'offre ! Envoi différé.`);
        }

        function refuseTimeShiftServer() {
            document.getElementById('ts-offer-modal').classList.remove('open');
            sendOrderToKDS(false);
        }

        async function sendOrderToKDS(isTimeShifted = false) {
            normalizeSequenceMetadata();

            /* La cuisine reçoit toujours le convive/siège. */
            currentTicket.forEach(i => {
                if(!i) return;
                const seat = Number(i.seat || i.guestSeat || i.seatNumber || 0) || 0;
                i.seat = seat;
                i.guestSeat = seat;
                i.seatNumber = seat;
                if(!i.guestName) {
                    i.guestName = String(i.conviveName || i.personName || '').trim();
                }
            });
            const unsent = currentTicket.filter(i => !i.isSent);
            if (!unsent.length) return;

            const seqs = unsent.map(i => getItemSequence(i)).filter(s => s > 0);
            const firstSeq = seqs.length ? Math.min(...seqs) : null;
            let count = 0;

            currentTicket.forEach(i => {
                if (!i.isSent) {
                    i.isSent = true;
                    i.itemId = Date.now() + Math.floor(Math.random()*1000);
                    i.timeShifted = isTimeShifted === true;
                    i.menuKnownByKitchen = true;

                    const seq = getItemSequence(i);
                    if (seq > 0) {
                        i.sequence = seq;
                        i.sequenceStatus = (seq === firstSeq) ? 'PRODUCTION' : 'WAITING';
                        if (seq === firstSeq) i.requestedAt = Date.now();
                    } else {
                        i.sequenceStatus = 'PRODUCTION';
                    }
                    count++;
                }
            });

            if (count > 0) {
                renderTicket();
                await executeSaveTableState(false, true);

                const sequenceCount = new Set(currentTicket.map(i => getItemSequence(i)).filter(s => s > 0)).size;
                alert(`✅ Commande complète transmise à la cuisine.
${count} ligne(s) · ${sequenceCount} séquence(s).

🔥 Première séquence lancée.
⏸ Les suivantes attendent la RÉCLAME du serveur.`);
            }
        }

        const ICHEF_TABLE_WRITE_QUEUES = new Map();

        async function executeSaveTableState(fireAllNew = false, keepOpen = false) {
            if (currentTicket.length === 0 && !keepOpen) return true;

            const itemsToSave = JSON.parse(JSON.stringify(currentTicket));
            const obsNode = document.getElementById('order-obs');
            const obsToSave = obsNode ? obsNode.value.trim() : '';
            const targetTable = currentTableId;

            if (!targetTable) return false;

            if (!keepOpen) {
                closeOrder();
                renderFloor();
            }

            const previousOrder = (activeOrders && activeOrders[targetTable] && typeof activeOrders[targetTable] === 'object')
                ? activeOrders[targetTable]
                : {};

            const payload = {
                items: itemsToSave,
                time: new Date().toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'}),
                status: 'pending',
                observations: obsToSave
            };

            /* Origine/service/paiement/production sont toujours transportés
               avec la commande. Si elle vient du QR, on conserve son origine. */
            payload.orderMeta = getUnifiedOrderMeta(
                {...previousOrder, ...payload},
                targetTable,
                {
                    productionStatus: inferOrderProductionStatus(payload)
                }
            );

            /* Compatibilité avec les écrans plus anciens. */
            payload.origin = payload.orderMeta.origin;
            payload.serviceMode = payload.orderMeta.serviceMode;
            payload.paymentStatus = payload.orderMeta.paymentStatus;
            payload.productionStatus = payload.orderMeta.productionStatus;

            /* Une seule écriture à la fois par table.
               Ainsi, même pendant un gros rush, un ancien état ne peut pas
               écraser une commande plus récente. */
            const previous = ICHEF_TABLE_WRITE_QUEUES.get(targetTable) || Promise.resolve();

            const task = previous
                .catch(() => {})
                .then(async () => {
                    let lastError = null;

                    /* Deux nouvelles tentatives seulement sur erreur réseau.
                       L'ordre est conservé et aucune écriture concurrente n'est lancée. */
                    for (let attempt = 0; attempt < 3; attempt++) {
                        try {
                            await API.update(targetTable, payload, true);
                            return true;
                        } catch (err) {
                            lastError = err;
                            const message = String(err?.message || '');
                            if (/AUTH_REQUIRED|INVALID_KEY|PERMISSION|403|401/i.test(message)) break;
                            if (attempt < 2) {
                                await new Promise(resolve => setTimeout(resolve, 250 * (attempt + 1)));
                            }
                        }
                    }

                    console.error('[iCHEF] Sauvegarde table impossible', targetTable, lastError);
                    if (typeof showToast === 'function') {
                        showToast('⚠️ Synchronisation en attente — connexion à vérifier');
                    }
                    return false;
                })
                .finally(() => {
                    if (ICHEF_TABLE_WRITE_QUEUES.get(targetTable) === task) {
                        ICHEF_TABLE_WRITE_QUEUES.delete(targetTable);
                    }
                });

            ICHEF_TABLE_WRITE_QUEUES.set(targetTable, task);
            return task;
        }

        // ==========================================
        // 🤦‍♂️ GESTION DES ERREURS HUMAINES (NOUVEAU)
        // ==========================================
        let pendingErrorIndex = null;
        
        function openErrorModal(idx) {
            pendingErrorIndex = idx;
            document.getElementById('error-item-title').innerText = currentTicket[idx].n.replace(/\n/g, ' ');
            document.getElementById('error-item-modal').classList.add('open');
        }

        function closeErrorModal() {
            pendingErrorIndex = null;
            document.getElementById('error-item-modal').classList.remove('open');
        }

        async function executeErrorItem(motif) {
            if(pendingErrorIndex === null) return;
            
            let item = currentTicket[pendingErrorIndex];
            let userName = currentUser ? currentUser.name : "Serveur";
            
            // 1. On annule l'ancien plat (Il passe à 0€ pour la compta et on taggue Pertes)
            item.originalPrice = item.originalPrice !== undefined ? item.originalPrice : item.p; 
            item.p = 0; 
            item.isOffered = true; // Pour ne pas le facturer au client
            item.obs = `❌ ANNULÉ (${motif})`;
            item.done = true; // On le sort du scope de la cuisine

            // 2. On recrée un NOUVEAU plat identique avec la priorité absolue
            let newItem = JSON.parse(JSON.stringify(item));
            newItem.id = Date.now() + Math.random();
            newItem.itemId = Date.now(); // Reset du chrono pour la cuisine
            newItem.p = item.originalPrice; // Le client paiera ce nouveau plat
            newItem.isOffered = false;
            newItem.done = false;
            newItem.served = false;
            newItem.isSent = true; // Déjà envoyé pour trigger l'alarme
            newItem.timeShifted = false; // Ne DOIT PAS passer par le sas d'attente
            newItem.obs = `🔥 URGENT : REFAIRE (${motif})`; // Le tag rouge pour le chef

            currentTicket.push(newItem);
            
            closeErrorModal(); 
            renderTicket();
            executeSaveTableState(false, true);

            // 3. On déclenche l'Alerte Rouge Générale sur tous les postes
            const alerte = {
                id: 'alert_' + Date.now(),
                type: 'humain',
                message: `Table ${currentTableId} : Refaire ${newItem.n} (${motif})`,
                author: userName,
                timestamp: Date.now()
            };

            try {
                const state = await API.getState();
                let settings = (state.activeOrders && state.activeOrders['SETTINGS_MASTER']) ? state.activeOrders['SETTINGS_MASTER'].data : {};
                if (!settings.activeAlerts) settings.activeAlerts = [];
                settings.activeAlerts.unshift(alerte);
                await API.update('SETTINGS_MASTER', settings);
                
                showToast("🚨 CUISINE ALERTÉE ! Le plat repart en priorité.", true);
            } catch(e) {}
        }

    // 2. AFFICHAGE INTELLIGENT DES PLATS
        function renderMenu(categoryId) {
            currentCategory = categoryId;

            // 🔥 NOUVEAU : AUTO-DÉTECTION DE LA SÉQUENCE SELON L'ONGLET
            let lowerCat = String(categoryId).toLowerCase();
            if (lowerCat.includes('boisson') || lowerCat.includes('bar') || lowerCat.includes('vin') || lowerCat.includes('soft')) {
                currentCourseDefault = 0; // Apéritif / Boisson (Envoi direct)
            } else if (lowerCat.includes('entrée') || lowerCat.includes('entree') || lowerCat.includes('tapas') || lowerCat.includes('partager')) {
                currentCourseDefault = 1; // Séquence 1
            } else if (lowerCat.includes('dessert') || lowerCat.includes('glace') || lowerCat.includes('sucré') || lowerCat.includes('patisserie')) {
                currentCourseDefault = 3; // Séquence 3
            } else {
                currentCourseDefault = 2; // Séquence 2 (Plats) par défaut
            }

            let itemsToDisplay = [];

            // Rafraîchir les couleurs des onglets
            renderDynamicCategories();

            // On récupère strictement les plats classés dans cette catégorie...
            if (unifiedMenu[categoryId]) {
                itemsToDisplay = unifiedMenu[categoryId].filter(i => !i.hidden);
            }

            const container = document.getElementById('menu-grid');
            
            if (itemsToDisplay.length === 0) { 
                container.innerHTML = `<div style="grid-column:1/-1; text-align:center; color:var(--text-muted); padding:40px; font-style:italic; font-weight: 300;">Aucun plat dans cette catégorie.<br><br><span style="font-size: 0.85rem;">Veuillez ajouter des plats depuis le Panneau d'Administration.</span></div>`; 
                return; 
            }

            container.innerHTML = itemsToDisplay.map(item => {
                let isSoldOut = (item.stock === 0 || item.stock === "0");
                let cleanName = item.name.replace(/\n/g, '<br>');
                let escapedName = escapeQuotes(item.name);
                let price = parseFloat(item.price) || 0;
                let tvaRate = parseFloat(item.tva) || 10;
                
                let stockHtml = '';
                if (item.stock !== "" && item.stock !== undefined && item.stock > 0) {
                    let badgeClass = 'stock-badge';
                    if (item.stock <= stockAlerts.red) badgeClass += ' alert-red';
                    else if (item.stock <= stockAlerts.orange) badgeClass += ' alert-orange';
                    else if (item.stock <= stockAlerts.yellow) badgeClass += ' alert-yellow';
                    else if (item.stock <= stockAlerts.green) badgeClass += ' alert-green';
                    stockHtml = `<div class="${badgeClass}">${item.stock}</div>`;
                }

                let tagsAlert = '';
                if (item.tags && item.tags.length > 0) {
                    const tagMap = { 'vegan': '🌿', 'vege': '🥗', 'nogluten': '🌾', 'nopork': '🐷', 'spicy': '🌶️', 'lactose': '🥛' };
                    tagsAlert = `<div style="position: absolute; bottom: 8px; left: 10px; font-size: 0.75rem; pointer-events: none; opacity: 0.8;">` + 
                        item.tags.map(t => tagMap[t] || t).join(' ') + 
                    `</div>`;
                }

                // Destination dynamique en fonction de la catégorie
                let isBarItem = (typeof categoriesBar !== 'undefined') ? categoriesBar.find(c => c.id === categoryId) : false;
                let dest = item.dest || (isBarItem ? 'bar' : 'cuisine');
                
                let clickAction = (item.isMenuJour) ? `addMenuToTicket('${escapedName}', ${price}, '${dest}', ${tvaRate})` : `addToTicket('${escapedName}', ${price}, '${dest}', ${tvaRate})`;

                return `
                    <button class="btn-item ${isSoldOut ? 'sold-out' : ''}" onclick="${clickAction}" style="position: relative; padding-bottom: 25px;">
                        ${stockHtml}
                        <span style="pointer-events:none;">${cleanName}</span>
                        ${tagsAlert}
                        <span class="price" style="pointer-events:none; font-family: 'Playfair Display', serif;">${formatMoneyPad(price)}</span>
                    </button>
                `;
            }).join('');
        }
        // ==========================================
        // 💳 SYSTÈME D'ENCAISSEMENT ET FIDÉLITÉ
        // ==========================================
        let paymentsDone = [];
        let currentTableTotal = 0;
        let currentPayRemaining = 0;
        let fidelityDiscountUsed = 0; 
        let loyaltyClientName = null;

        // ==========================================
        // 🌍 PROFIL FISCAL / CONFORMITÉ FRANCE - SUISSE
        // Configuration établissement uniquement. Ne vaut pas certification juridique.
        // ==========================================
        let pendingFiscalCountry = null;

        function normalizedFiscalProfile() {
            const cfg = window.systemSettings?.taxConfig || {};
            const country = cfg.country === 'CH' ? 'CH' : (cfg.country === 'FR' ? 'FR' : null);
            return {
                country,
                currency: country === 'CH' ? 'CHF' : 'EUR',
                displayCurrency: country === 'CH' ? 'CHF' : '€',
                compliance: window.systemSettings?.compliance || {}
            };
        }

        function fiscalComplianceItems(country) {
            if (country === 'CH') return [
                ['Devise', 'CHF'],
                ['Profil TVA', 'CH · taux gérés par article/prestation'],
                ['Protection des données', 'LPD / OPDo · mesures techniques & organisationnelles'],
                ['Journalisation', 'Audit des actions sensibles'],
                ['Sécurité', 'PIN · rôles · session · HTTPS côté serveur'],
                ['Violations de données', 'Procédure de notification à documenter'],
                ['Statut', 'CONFIGURÉ · à valider juridiquement']
            ];
            return [
                ['Devise', 'EUR (€)'],
                ['Profil TVA', 'FR · taux gérés par article/prestation'],
                ['Caisse', 'Inaltérabilité · sécurisation · conservation · archivage'],
                ['Clôtures', 'Journalière · mensuelle · annuelle/exercice côté caisse fiscale'],
                ['Traçabilité', 'Corrections/annulations journalisées, sans effacement silencieux'],
                ['Protection des données', 'RGPD · sécurité et droits à documenter'],
                ['Statut', 'CONFIGURÉ · attestation/certification à valider']
            ];
        }

        function renderFiscalCompliance(country) {
            const box = document.getElementById('compliance-checks');
            if (!box) return;
            box.innerHTML = fiscalComplianceItems(country).map(([k,v]) =>
                `<div style="display:flex;justify-content:space-between;gap:14px;border-bottom:1px solid var(--border);padding:7px 0;"><span style="color:var(--text-muted)">${k}</span><strong style="text-align:right">${v}</strong></div>`
            ).join('');
            const fr = document.getElementById('fiscal-fr-btn'), ch = document.getElementById('fiscal-ch-btn');
            if (fr) fr.style.outline = country === 'FR' ? '2px solid var(--gold)' : 'none';
            if (ch) ch.style.outline = country === 'CH' ? '2px solid var(--gold)' : 'none';
        }

        function refreshFiscalProfileUI() {
            const p = normalizedFiscalProfile();
            const summary = document.getElementById('fiscal-profile-summary');
            if (summary) summary.textContent = p.country ? `${p.country === 'CH' ? '🇨🇭 SUISSE' : '🇫🇷 FRANCE'} · ${p.displayCurrency} · profil fiscal serveur` : 'Profil non configuré';
            // Remplace uniquement les affichages monétaires statiques connus; les calculs restent inchangés.
            const symbol = p.displayCurrency;
            ['ticket-total-price','ticket-tva','pay-modal-total','pay-remaining','stock-tracker','dash-ca','order-mini-total'].forEach(id => {
                const el=document.getElementById(id); if(!el) return;
                const txt=el.textContent || '';
                el.textContent=txt.replace(/\s?(€|CHF)/g,' '+symbol).trim();
            });
        }

        function openFiscalComplianceModal() {
            if (!currentUser || currentUser.role !== 'Manager') return alert('⛔ Accès Manager requis');
            const p = normalizedFiscalProfile();
            pendingFiscalCountry = p.country || 'FR';
            renderFiscalCompliance(pendingFiscalCountry);
            document.getElementById('fiscal-compliance-modal')?.classList.add('open');
        }
        function closeFiscalComplianceModal(){ document.getElementById('fiscal-compliance-modal')?.classList.remove('open'); }
        function selectFiscalCountry(country){ pendingFiscalCountry = country === 'CH' ? 'CH' : 'FR'; renderFiscalCompliance(pendingFiscalCountry); }

        async function saveFiscalComplianceProfile() {
            if (!currentUser || currentUser.role !== 'Manager') return alert('⛔ Accès Manager requis');
            const country = pendingFiscalCountry === 'CH' ? 'CH' : 'FR';
            const currency = country === 'CH' ? 'CHF' : '€';
            const currencyCode = country === 'CH' ? 'CHF' : 'EUR';
            try {
                const state = await API.getState();
                const previous = (state.activeOrders && state.activeOrders.SETTINGS_MASTER) ? (state.activeOrders.SETTINGS_MASTER.data || {}) : (window.systemSettings || {});
                const next = {
                    ...previous,
                    currency,
                    taxConfig: { ...(previous.taxConfig || {}), country, currency, currencyCode },
                    compliance: {
                        ...(previous.compliance || {}),
                        country,
                        profileVersion: 'FR_CH_2026_08',
                        configuredAt: new Date().toISOString(),
                        configuredBy: currentUser?.name || null,
                        legalStatus: 'CONFIGURED_NOT_CERTIFIED',
                        fiscalCashRegisterRequired: country === 'FR'
                    }
                };
                await API.update('SETTINGS_MASTER', next, false, { reason:'Modification profil fiscal établissement', country });
                window.systemSettings = next;
                await auditEvent('FISCAL_PROFILE_UPDATED', { country, currencyCode, legalStatus:'CONFIGURED_NOT_CERTIFIED' }, false);
                refreshFiscalProfileUI();
                closeFiscalComplianceModal();
                alert(`✅ Profil ${country === 'CH' ? 'Suisse · CHF' : 'France · EUR'} enregistré.\nLe statut reste « configuré », pas « certifié » tant que la validation légale n'est pas réalisée.`);
            } catch(e) {
                console.error(e); alert('❌ Impossible d’enregistrer le profil fiscal sur le serveur.');
            }
        }

        function attVal(id){ return (document.getElementById(id)?.value || '').trim(); }
        function attEsc(s){ return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
        function attDateFR(s){ if(!s)return '________________'; const d=new Date(s+'T12:00:00'); return d.toLocaleDateString('fr-FR'); }

        function openFranceAttestation(){
            if (!currentUser || currentUser.role !== 'Manager') return alert('⛔ Accès Manager requis');
            const p=normalizedFiscalProfile();
            if(p.country!=='FR') return alert('ℹ️ L’attestation française est disponible uniquement pour un profil fiscal FRANCE.');
            const today=new Date().toISOString().slice(0,10);
            const issued=document.getElementById('att-issued'); if(issued && !issued.value) issued.value=today;
            const version=document.getElementById('att-version'); if(version && !version.value) version.value=(window.ICHEF_VERSION || 'À RENSEIGNER');
            const lic=document.getElementById('att-license'); if(lic && !lic.value) lic.value=(window.appTenantID || '');
            document.getElementById('fr-attestation-modal')?.classList.add('open');
        }
        function closeFranceAttestation(){ document.getElementById('fr-attestation-modal')?.classList.remove('open'); }

        function buildFranceAttestationHtml(){
            const v={
              userCompany:attVal('att-user-company'), userRep:attVal('att-user-rep'),
              acquired:attVal('att-acquired'), useDate:attVal('att-use-date'),
              version:attVal('att-version'), license:attVal('att-license'),
              editorCompany:attVal('att-editor-company'), editorRep:attVal('att-editor-rep'),
              city:attVal('att-city'), issued:attVal('att-issued'),
              covered:attVal('att-covered'), notCovered:attVal('att-not-covered')
            };
            return `
              <h3>ATTESTATION INDIVIDUELLE RELATIVE À L’UTILISATION D’UN LOGICIEL OU D’UN SYSTÈME DE CAISSE SÉCURISÉ</h3>
              <p><strong>Volet 1 — Éditeur / intégrateur</strong></p>
              <p>Je soussigné(e), <strong>${attEsc(v.editorRep)||'________________'}</strong>, représentant légal de <strong>${attEsc(v.editorCompany)||'________________'}</strong>, éditeur/intégrateur du logiciel ou système de caisse <strong>iCHEF</strong>, version <strong>${attEsc(v.version)||'________________'}</strong>, licence <strong>${attEsc(v.license)||'________________'}</strong>, atteste que les fonctionnalités de caisse couvertes par la présente attestation satisfont aux conditions d’inaltérabilité, de sécurisation, de conservation et d’archivage des données en vue du contrôle de l’administration fiscale.</p>
              <p><strong>Périmètre couvert :</strong> ${attEsc(v.covered)||'________________'}</p>
              <p><strong>Fonctionnalités non couvertes :</strong> ${attEsc(v.notCovered)||'________________'}</p>
              <p>Fait à ${attEsc(v.city)||'________________'}, le ${attDateFR(v.issued)}.</p>
              <p style="margin-top:35px">Signature du représentant légal de l’éditeur / intégrateur : ______________________________</p>
              <hr style="margin:25px 0">
              <p><strong>Volet 2 — Entreprise utilisatrice</strong></p>
              <p>Je soussigné(e), <strong>${attEsc(v.userRep)||'________________'}</strong>, représentant légal de <strong>${attEsc(v.userCompany)||'________________'}</strong>, certifie avoir acquis ou téléchargé le ${attDateFR(v.acquired)}, auprès de <strong>${attEsc(v.editorCompany)||'________________'}</strong>, le logiciel / système de caisse mentionné au volet 1.</p>
              <p>J’atteste utiliser ce logiciel / système de caisse pour enregistrer les règlements de mes clients particuliers, conformément à la réglementation fiscale en vigueur, depuis le ${attDateFR(v.useDate)}.</p>
              <p>Fait à ${attEsc(v.city)||'________________'}, le __________________.</p>
              <p style="margin-top:35px">Signature du représentant légal de l’entreprise utilisatrice : ______________________________</p>
              <p style="margin-top:30px;font-size:10px"><strong>Important :</strong> document à utiliser uniquement lorsque l’éditeur est effectivement en mesure d’attester la conformité de la version concernée. L’établissement ou l’usage d’une fausse attestation expose à des sanctions pénales.</p>`;
        }

        function previewFranceAttestation(){
            const box=document.getElementById('fr-attestation-preview'); if(!box)return;
            box.innerHTML=buildFranceAttestationHtml(); box.style.display='block'; box.scrollIntoView({behavior:'smooth',block:'start'});
        }
        async function printFranceAttestation(){
            if(!document.getElementById('att-editor-approved')?.checked){
              return alert('⛔ Émission bloquée : le représentant légal de l’éditeur doit confirmer la validation réelle de la version avant impression/signature.');
            }
            const required=['att-user-company','att-user-rep','att-acquired','att-use-date','att-version','att-editor-company','att-editor-rep','att-city','att-issued'];
            const missing=required.filter(id=>!attVal(id));
            if(missing.length) return alert('⛔ Complétez tous les champs obligatoires avant l’émission.');
            previewFranceAttestation();
            try{
              if(typeof auditEvent==='function') await auditEvent('FRANCE_ATTESTATION_PREPARED',{
                version:attVal('att-version'), license:attVal('att-license'),
                userCompany:attVal('att-user-company'), issuedAt:new Date().toISOString()
              },false);
            }catch(e){ console.warn('Audit attestation non enregistré',e); }
            setTimeout(()=>window.print(),120);
        }

        function openSwissCompliance(){
            if (!currentUser || currentUser.role !== 'Manager') return alert('⛔ Accès Manager requis');
            const p=normalizedFiscalProfile();
            if(p.country!=='CH') return alert('ℹ️ Le dossier suisse est disponible uniquement pour un profil fiscal SUISSE.');
            const today=new Date().toISOString().slice(0,10);
            if(!document.getElementById('ch-issued').value) document.getElementById('ch-issued').value=today;
            if(!document.getElementById('ch-version').value) document.getElementById('ch-version').value=(window.ICHEF_VERSION || 'À RENSEIGNER');
            if(!document.getElementById('ch-license').value) document.getElementById('ch-license').value=(window.appTenantID || '');
            document.getElementById('ch-compliance-modal')?.classList.add('open');
        }
        function closeSwissCompliance(){
            document.getElementById('ch-compliance-modal')?.classList.remove('open');
            document.body.classList.remove('ch-print-mode');
        }
        function toggleSwissCertificationFields(){
            const on=!!document.getElementById('ch-certified')?.checked;
            const box=document.getElementById('ch-cert-fields');
            if(box) box.style.display=on?'grid':'none';
        }
        function chVal(id){return (document.getElementById(id)?.value||'').trim();}
        function chChecks(){
            return Array.from(document.querySelectorAll('[data-ch-check]')).map(x=>({
              key:x.dataset.chCheck, label:(x.parentElement?.textContent||'').trim(), ok:x.checked
            }));
        }
        function buildSwissComplianceHtml(){
            const certified=!!document.getElementById('ch-certified')?.checked;
            const certBody=chVal('ch-cert-body'), certRef=chVal('ch-cert-ref');
            const checks=chChecks();
            const rows=checks.map(x=>`<tr><td style="padding:5px;border-bottom:1px solid #ddd">${attEsc(x.label)}</td><td style="padding:5px;border-bottom:1px solid #ddd"><strong>${x.ok?'DOCUMENTÉ / CONFIGURÉ':'À VÉRIFIER'}</strong></td></tr>`).join('');
            let cert = certified
              ? `<p><strong>Certification indépendante déclarée :</strong> ${attEsc(certBody)||'________________'} · Réf. ${attEsc(certRef)||'________________'}. Cette mention doit être accompagnée et vérifiée au moyen du certificat réel.</p>`
              : `<p><strong>Statut :</strong> dossier technique interne — aucune certification indépendante n’est revendiquée.</p>`;
            return `
              <h3>DOSSIER TECHNIQUE DE CONFORMITÉ — SUISSE</h3>
              <p><strong>Établissement :</strong> ${attEsc(chVal('ch-company'))||'________________'}<br>
              <strong>Responsable :</strong> ${attEsc(chVal('ch-rep'))||'________________'}<br>
              <strong>Logiciel :</strong> iCHEF · version ${attEsc(chVal('ch-version'))||'________________'} · licence ${attEsc(chVal('ch-license'))||'________________'}<br>
              <strong>Profil :</strong> Suisse · devise CHF<br>
              <strong>Hébergement déclaré :</strong> ${attEsc(chVal('ch-hosting'))||'________________'}<br>
              <strong>Date :</strong> ${attDateFR(chVal('ch-issued'))}</p>
              <p>Ce dossier documente les mesures et paramètres déclarés pour le traitement des données et la sécurité. Il ne constitue pas, à lui seul, une certification officielle ou un avis juridique.</p>
              <table style="width:100%;border-collapse:collapse;margin:14px 0">${rows}</table>
              <p><strong>Mesures / remarques :</strong><br>${attEsc(chVal('ch-notes')).replace(/\n/g,'<br>')||'________________'}</p>
              ${cert}
              <p style="margin-top:28px">Signature / validation interne : ______________________________</p>`;
        }
        function previewSwissCompliance(){
            const box=document.getElementById('ch-compliance-preview'); if(!box)return;
            box.innerHTML=buildSwissComplianceHtml(); box.style.display='block';
            box.scrollIntoView({behavior:'smooth',block:'start'});
        }
        async function printSwissCompliance(){
            const required=['ch-company','ch-rep','ch-version','ch-license','ch-hosting','ch-issued'];
            if(required.some(id=>!chVal(id))) return alert('⛔ Complétez les informations principales avant l’impression.');
            if(document.getElementById('ch-certified')?.checked && (!chVal('ch-cert-body') || !chVal('ch-cert-ref'))){
                return alert('⛔ Une certification ne peut être mentionnée sans organisme et référence de certificat.');
            }
            previewSwissCompliance();
            try{
              if(typeof auditEvent==='function') await auditEvent('SWISS_COMPLIANCE_DOSSIER_PREPARED',{
                version:chVal('ch-version'), license:chVal('ch-license'),
                company:chVal('ch-company'), issuedAt:new Date().toISOString(),
                certifiedClaim:!!document.getElementById('ch-certified')?.checked
              },false);
            }catch(e){console.warn('Audit dossier CH non enregistré',e);}
            document.body.classList.add('ch-print-mode');
            const cleanup=()=>document.body.classList.remove('ch-print-mode');
            window.addEventListener('afterprint',cleanup,{once:true});
            setTimeout(()=>window.print(),120);
        }

        // ==========================================
        // 🧾 SÉPARATION PAD SERVEUR / CAISSE FISCALE
        // ==========================================
        function getCashRegisterSettings() {
            return (window.systemSettings && window.systemSettings.cashRegister) ? window.systemSettings.cashRegister : {};
        }

        function getQrNfcSettings() {
            return (window.systemSettings && window.systemSettings.qrNfc) ? window.systemSettings.qrNfc : {};
        }

        function isFiscalCashRegisterReady() {
            const cash = getCashRegisterSettings();
            return cash.enabled === true && cash.fiscalMode === true && !!(cash.backendUrl || "/api/fiscal/cash-in");
        }

        function getFiscalBackendUrl() {
            const cash = getCashRegisterSettings();
            return cash.backendUrl || "/api/fiscal/cash-in";
        }

        function getCurrencyCodeForPad() {
            const currency = window.systemSettings?.taxConfig?.currency || window.systemSettings?.currency || "€";
            if (currency === "CHF") return "CHF";
            if (currency === "$") return "USD";
            if (currency === "C$") return "CAD";
            return "EUR";
        }

        function getDisplayCurrencyForPad() {
            return window.systemSettings?.taxConfig?.currency || window.systemSettings?.currency || "€";
        }

        function formatMoneyPad(amount) {
            return `${(parseFloat(amount) || 0).toFixed(2)} ${getDisplayCurrencyForPad()}`;
        }

        function getFiscalContextForPad() {
            return {
                country: window.systemSettings?.taxConfig?.country || (getCurrencyCodeForPad() === "CHF" ? "CH" : "FR"),
                currency: getCurrencyCodeForPad(),
                displayCurrency: getDisplayCurrencyForPad(),
                taxConfig: window.systemSettings?.taxConfig || null,
                source: "PAD_SERVEUR_CONTEXT"
            };
        }

        function openCaisseTactileFromPad() {
            window.location.href = `caissetactile.html?tenantID=${appTenantID}`;
        }

        function normalizeFiscalPaymentMethod(methods) {
            const raw = Array.isArray(methods) ? methods.map(m => String(m.method || m)).join(" + ") : String(methods || "");
            if (raw.includes("CB") || raw.toUpperCase().includes("CARD")) return "CARD";
            if (raw.includes("ESPÈCES") || raw.toUpperCase().includes("CASH")) return "CASH";
            if (raw.toUpperCase().includes("STRIPE") || raw.toUpperCase().includes("ONLINE")) return "ONLINE";
            return "OTHER";
        }

        function getCurrentPaxFromPad() {
            try {
                const obsInput = document.getElementById('order-obs')?.value || "";
                const match = obsInput.match(/🍽️ (\d+) Couvert\(s\)/);
                if (match) return parseInt(match[1]);
                const tObj = tables.find(t => t && t.label === currentTableId);
                return tObj?.pax || 1;
            } catch(e) {
                return 1;
            }
        }

        function getCurrentZoneLabelForPad() {
            return currentTableZoneLabel || "Salle";
        }

        function updateCashRegisterBadge() {
            const badge = document.getElementById('badge-fiscal-cash');
            if (!badge) return;

            if (isFiscalCashRegisterReady()) {
                badge.style.display = 'block';
                badge.innerHTML = '';
                badge.style.color = 'var(--gold)';
                badge.style.borderColor = 'var(--gold)';
            } else {
                badge.style.display = 'block';
                badge.innerHTML = '';
                badge.style.color = 'var(--text-muted)';
                badge.style.borderColor = 'var(--border)';
            }
        }

        async function sendPadPaymentToFiscalBackend({ totalHT, tvaTotals }) {
            const fiscalBackendUrl = getFiscalBackendUrl();
            const normalizedMethod = normalizeFiscalPaymentMethod(paymentsDone);
            const currency = getCurrencyCodeForPad();

            const payload = {
                tenantID: appTenantID,
                tableId: currentTableId,
                deviceId: getDeviceFingerprint(),
                source: "PAD_SERVEUR_PAYMENT_REQUEST",
                fiscalContext: getFiscalContextForPad(),
                fiscalRequirements: {
                    frontendNotice: "Le Pad Serveur transmet la demande d'encaissement ; la preuve fiscale doit être créée, signée et conservée côté serveur.",
                    expectedBackendControls: ["ticket_number", "hash_chain", "digital_signature", "audit_log", "daily_closure", "archive_export"]
                },
                payment: {
                    method: normalizedMethod,
                    currency: currency,
                    amount: Number(currentTableTotal.toFixed(2)),
                    details: paymentsDone
                },
                orderSnapshot: {
                    tableId: currentTableId,
                    zone: getCurrentZoneLabelForPad(),
                    mode: currentTableId_PayMode || "standard",
                    pax: getCurrentPaxFromPad(),
                    total: Number(currentTableTotal.toFixed(2)),
                    totalHT: Number(totalHT.toFixed(2)),
                    tva: tvaTotals,
                    items: currentTicket,
                    waiter: currentUser ? currentUser.name : null,
                    cashedAt: new Date().toISOString()
                }
            };

            const response = await fetch(`${APP_SERVER_URL}${fiscalBackendUrl.startsWith('/') ? fiscalBackendUrl : '/' + fiscalBackendUrl}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            const data = await response.json().catch(() => ({}));

            if (!response.ok || data.success === false) {
                throw new Error(data.error || "Erreur lors de la création du ticket fiscal.");
            }

            return data;
        }

       function openPaymentModal() {
            if (currentGlobalScheduledMode === 'closed') {
                return alert("🛑 IMPOSSIBLE : Le restaurant est programmé comme FERMÉ à cette heure-ci.");
            }

            if (currentTicket.length === 0) return alert("Table vide.");

            let td = activeOrders[currentTableId];
            if (!td || !td.items || td.items.length !== currentTicket.length) {
                return alert("⚠️ Sauvegardez les modifications avant d'encaisser.");
            }

            const isQrOrderZone = (typeof currentTableId_PayMode !== 'undefined' && currentTableId_PayMode === 'qr_nfc') || (currentGlobalScheduledMode === 'qr_nfc');

            if (isQrOrderZone) {
                const ok = confirm(
                    "📲 Cette table est en zone QR/NFC.\n\n" +
                    "QR/NFC = prise de commande client.\n" +
                    "Caisse = encaissement séparé.\n\n" +
                    "Continuer vers l'encaissement depuis le Pad Serveur ?"
                );
                if (!ok) return;
            }

            if (!isFiscalCashRegisterReady()) {
                alert(
                    "Encaissement bloqué.\n\n" +
                    "Le Pad Serveur n'est pas une caisse fiscale autonome.\n" +
                    "Activez la caisse fiscale serveur dans l'administration ou ouvrez caissetactile.html.\n\n" +
                    "Aucun règlement client ne doit être clôturé en historique interne depuis le Pad."
                );
                return;
            }

            document.getElementById('pay-modal-title').innerText = "TABLE " + currentTableId;
            document.getElementById('pay-modal-total').innerText = formatMoneyPad(currentTableTotal);

            paymentsDone = [];
            fidelityDiscountUsed = 0;
            currentPayRemaining = currentTableTotal;
            updatePaymentUI();

            let lZone = document.getElementById('loyalty-zone');
            if (isLoyaltyActive) {
                lZone.style.display = 'flex';
                updateLoyaltyUI();
            } else {
                lZone.style.display = 'none';
            }

            document.getElementById('payment-modal').classList.add('open');
        }

        function openLoyaltyPrompt() {
            let phone = prompt("📱 Numéro de téléphone du client (ex: 0612345678) :");
            if (!phone) return;
            phone = phone.replace(/\s+/g, '');
            if(phone.length < 8) return alert("Numéro invalide.");
            
            currentLoyaltyPhone = phone;
            
            if(!globalLoyaltyData[phone]) {
                let name = prompt("✨ Nouveau client ! Quel est son prénom/nom ?");
                globalLoyaltyData[phone] = { name: name || 'Client', points: 0 };
            }
            
            loyaltyClientName = globalLoyaltyData[phone].name;
            updateLoyaltyUI();
        }

        function updateLoyaltyUI() {
            let statusText = document.getElementById('loyalty-status-text');
            let actionBtn = document.getElementById('btn-loyalty-action');
            
            if(!currentLoyaltyPhone) {
                statusText.innerText = "Aucun compte lié.";
                actionBtn.innerText = "ASSOCIER";
                actionBtn.setAttribute("onclick", "openLoyaltyPrompt()");
            } else {
                let solde = globalLoyaltyData[currentLoyaltyPhone].points || 0;
                statusText.innerHTML = `Connecté : <b>${loyaltyClientName}</b><br>Cagnotte dispo : <strong style="color:var(--text-main); font-size:1rem;">${solde.toFixed(2)} €</strong>`;
                
                if (solde > 0 && currentPayRemaining > 0) {
                    actionBtn.innerText = "DÉDUIRE";
                    actionBtn.setAttribute("onclick", "useLoyaltyPoints()");
                } else {
                    actionBtn.innerText = "MODIFIER";
                    actionBtn.setAttribute("onclick", "openLoyaltyPrompt()");
                }
            }
        }

        function useLoyaltyPoints() {
            if(!currentLoyaltyPhone || !globalLoyaltyData[currentLoyaltyPhone]) return;
            let solde = globalLoyaltyData[currentLoyaltyPhone].points || 0;
            
            let maxDeductible = Math.min(solde, currentPayRemaining);
            let deductStr = prompt(`Combien de la cagnotte voulez-vous utiliser ?\nMax possible: ${maxDeductible.toFixed(2)}€`, maxDeductible.toFixed(2));
            
            if(!deductStr) return;
            let deduct = parseFloat(deductStr.replace(',', '.'));
            
            if(isNaN(deduct) || deduct <= 0 || deduct > maxDeductible + 0.05) return alert("Montant invalide.");
            
            fidelityDiscountUsed += deduct;
            globalLoyaltyData[currentLoyaltyPhone].points -= deduct; 
            
            paymentsDone.push({ method: '🎁 CAGNOTTE', amount: deduct });
            currentPayRemaining -= deduct;
            if(currentPayRemaining < 0) currentPayRemaining = 0;
            
            updateLoyaltyUI();
            updatePaymentUI();
        }

        function setRemainderAmount() {
            document.getElementById('pay-amount-input').value = currentPayRemaining.toFixed(2);
        }

        function processPartialPayment(method) {
            let amtInput = document.getElementById('pay-amount-input').value;
            let amt = parseFloat(amtInput.replace(',', '.'));
            if(isNaN(amt) || amt <= 0) return alert("⚠️ Saisissez un montant valide.");
            
            let isVoucher = (method === 'TR' || method === 'CV');
            if(!isVoucher && amt > currentPayRemaining + 0.05) return alert("⚠️ Le montant dépasse le reste à payer.");
            if (isVoucher && amt > currentPayRemaining) { if (!confirm(`On ne rend pas la monnaie sur les ${method}. Valider ?`)) return; }

            if (method === 'ESPÈCES') {
                let cashGivenStr = prompt(`💵 Espèces données par le client ?\n(Reste à payer : ${amt.toFixed(2)}€)`);
                if (!cashGivenStr) return; 
                let cashGiven = parseFloat(cashGivenStr.replace(',', '.'));
                if (isNaN(cashGiven) || cashGiven < amt) return alert("⚠️ Montant insuffisant.");
                let changeDue = cashGiven - amt;
                if (changeDue > 0) alert(`💰 MONNAIE À RENDRE : ${changeDue.toFixed(2)} €`);
            }
            
            paymentsDone.push({ method: method, amount: amt });
            currentPayRemaining -= amt;
            if(currentPayRemaining < 0) currentPayRemaining = 0;
            updatePaymentUI();
        }

        function updatePaymentUI() {
            document.getElementById('pay-remaining').innerText = formatMoneyPad(currentPayRemaining);
            document.getElementById('pay-amount-input').value = currentPayRemaining.toFixed(2);
            
            let histList = document.getElementById('payment-history');
            if(paymentsDone.length === 0) histList.innerHTML = '<span style="color:var(--text-muted); font-weight: 300;">Aucun paiement enregistré</span>';
            else {
                histList.innerHTML = paymentsDone.map(p => `
                    <div style="display:flex; justify-content:space-between; color:var(--text-main); font-weight:500; background:transparent; padding:10px 0; border-bottom:1px solid var(--border-strong);">
                        <span>${p.method}</span>
                        <span style="color:var(--gold); font-family: 'Playfair Display', serif;">${formatMoneyPad(p.amount)}</span>
                    </div>
                 `).join('');
            }
            
            if(currentPayRemaining <= 0) {
                document.querySelector('.pay-methods').style.display = 'none';
                document.getElementById('pay-amount-input').style.display = 'none';
                document.getElementById('btn-close-table').style.display = 'block';
            } else {
                document.querySelector('.pay-methods').style.display = 'flex';
                document.getElementById('pay-amount-input').style.display = 'block';
                document.getElementById('btn-close-table').style.display = 'none';
            }
        }

        function closePaymentModal() { document.getElementById('payment-modal').classList.remove('open'); }

        async function finalizeTablePayment() {
            if (typeof isDemoMode !== 'undefined' && isDemoMode) {
                document.getElementById('payment-modal').classList.remove('open');
                closeOrder();
                return alert("✅ [MODE DÉMO] Paiement encaissé fictivement. Historique non sauvegardé.");
            }

            document.getElementById('payment-modal').classList.remove('open');

            try {
                const state = await API.getState();

                let totalHT = 0;
                let tvaTotals = {};

                currentTicket.forEach(i => {
                    let ligneTTC = (parseFloat(i.p) || 0) * (i.qty || 1);
                    let rate = parseFloat(i.tva) || 10;
                    let ligneHT = ligneTTC / (1 + (rate / 100));
                    totalHT += ligneHT;
                    tvaTotals[rate] = (tvaTotals[rate] || 0) + (ligneTTC - ligneHT);
                });

                let fiscalResult = null;
                let fiscalStatus = "INTERNAL_HISTORY_ONLY";

                if (isFiscalCashRegisterReady()) {
                    fiscalResult = await sendPadPaymentToFiscalBackend({
                        totalHT,
                        tvaTotals
                    });

                    fiscalStatus = "FISCALIZED";
                } else {
                    alert(
                        "Encaissement refusé.\n\n" +
                        "La caisse fiscale serveur n'est pas active.\n" +
                        "Le Pad Serveur peut gérer la commande et le service, mais il ne doit pas clôturer un règlement client sans ticket fiscal serveur."
                    );
                    return;
                }

                if (isLoyaltyActive && currentLoyaltyPhone && globalLoyaltyData[currentLoyaltyPhone]) {
                    let montantEligibleCashback = currentTableTotal - fidelityDiscountUsed;
                    if (montantEligibleCashback > 0) {
                        let argentGagne = montantEligibleCashback * (loyaltyPercent / 100);
                        globalLoyaltyData[currentLoyaltyPhone].points += argentGagne;

                        await API.update('LOYALTY_MASTER', globalLoyaltyData);
                        alert(`🎁 Le client ${globalLoyaltyData[currentLoyaltyPhone].name} vient de gagner ${argentGagne.toFixed(2)} € sur sa cagnotte !`);
                    }
                }

                let transaction = {
                    id: 'TX_' + Date.now(),
                    date: new Date().toISOString(),
                    method: paymentsDone.map(h => h.method).join(' + '),
                    payments: paymentsDone,
                    totalTTC: parseFloat(currentTableTotal.toFixed(2)),
                    totalHT: parseFloat(totalHT.toFixed(2)),
                    tva: tvaTotals,
                    source: 'Pad Serveur (' + currentTableId + ')',
                    zone: getCurrentZoneLabelForPad(),
                    mode: currentTableId_PayMode || "standard",
                    fiscalStatus: fiscalStatus,
                    fiscalTicket: fiscalResult ? {
                        ticketNumber: fiscalResult.ticket?.ticketNumber || fiscalResult.ticket?.ticket_number || null,
                        chainHash: fiscalResult.ticket?.chainHash || fiscalResult.ticket?.chain_hash || null,
                        createdAt: fiscalResult.ticket?.createdAt || fiscalResult.ticket?.created_at || null
                    } : null,
                    items: currentTicket
                };

                let historyNode = state.activeOrders['FINANCIAL_HISTORY'] || { data: [] };
                historyNode.data.push(transaction);
                await API.update('FINANCIAL_HISTORY', historyNode.data);
                document.dispatchEvent(new CustomEvent('ichef:financial-history-updated'));

                await API.update(currentTableId, null, true, { reason: 'Clôture de table après encaissement validé', operationType: 'TABLE_CLOSED' });
                window.print();

                if (fiscalStatus === "FISCALIZED") {
                    alert("✅ Ticket fiscal généré et table clôturée.");
                } else {
                    alert("⚠️ Clôture interne non autorisée en production.");
                }

                closeOrder();
                renderFloor();

            } catch (e) {
                console.error("Erreur clôture Pad Serveur :", e);
                alert("❌ Encaissement refusé : " + (e.message || "erreur inconnue"));
            }
        }

        function openHistoryDrawer() {
            document.getElementById('history-drawer').classList.add('open');
            API.getState().then(s => {
                let hData = s.activeOrders['FINANCIAL_HISTORY'] ? s.activeOrders['FINANCIAL_HISTORY'].data : [];
                if(typeof window.ichefFilterGhostT3History==="function"){
                    hData=window.ichefFilterGhostT3History(hData);
                }
                let container = document.getElementById('history-content');
                if(hData.length === 0) { container.innerHTML = '<div style="color:var(--text-muted); text-align:center;">Aucun historique</div>'; return; }
                
                hData.sort((a,b) => new Date(b.date) - new Date(a.date));
                const visibleHistory = hData.slice(0, 250);
                let html = visibleHistory.map(t => {
                    let d = new Date(t.date);
                    return `<div style="background:var(--panel); border:1px solid var(--border-strong); padding:15px; border-radius:4px;">
                        <div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border); padding-bottom:10px; margin-bottom:10px;">
                            <span style="color:var(--gold); font-weight:bold;">${t.source}</span>
                            <span style="color:var(--text-muted); font-size:0.8rem;">${d.toLocaleDateString()} ${d.toLocaleTimeString()}</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; font-weight:bold;">
                            <span>TOTAL</span>
                            <span style="color:var(--gold);">${formatMoneyPad(t.totalTTC)}</span>
                        </div>
                        <div style="font-size:0.7rem; color:var(--text-muted); text-align:right; margin-top:5px;">${t.method}</div>
                    </div>`;
                }).join('');
                if (hData.length > visibleHistory.length) {
                    html += `<div style="text-align:center;color:var(--text-muted);padding:12px;font-size:.72rem;">
                        Affichage des 250 opérations les plus récentes sur ${hData.length}. L'historique complet reste conservé.
                    </div>`;
                }
                container.innerHTML = html;
            });
        }
        function closeDrawer(id) { document.getElementById(id).classList.remove('open'); }

        // ==========================================
        // ➕ GESTION DES TABLES EXTRA (VOLANTES)
        // ==========================================
        function addExtraTable() {
            let tableName = prompt("Nom de la table supplémentaire (ex: EXT-2, DEBOUT, BAR) :");
            if (!tableName) return;
            tableName = tableName.trim().toUpperCase();

            if (tables.find(t => t && t.label === tableName && t.room === currentRoom)) {
                return alert("❌ Ce nom de table existe déjà dans cette salle.");
            }

            let paxStr = prompt("Combien de couverts ?", "2");
            if (!paxStr) return;
            let pax = parseInt(paxStr) || 2;

            let baseL = window.innerWidth / 2 - 40;
            let baseT = window.innerHeight / 2 - 60;

            let roomZones = zones.filter(z => z && z.room === currentRoom);
            if (roomZones.length > 0) {
                let zPrompt = "Dans quelle zone placer la table ?\n\n";
                roomZones.forEach((z, i) => { zPrompt += `[ ${i + 1} ] - ${z.label}\n`; });
                zPrompt += `[ 0 ] - Aucune zone (Hors zone)\n\nEntrez le numéro :`;
                
                let zChoice = prompt(zPrompt, "1");
                if (zChoice !== null && zChoice !== "0") {
                    let selectedZone = roomZones[parseInt(zChoice) - 1];
                    if (selectedZone) {
                        baseL = (selectedZone.l || 0) + ((selectedZone.w || 400) / 2) - 40;
                        baseT = (selectedZone.t || 0) + ((selectedZone.h || 300) / 2) - 60;
                    }
                }
            }

            let randomOffsetX = Math.floor(Math.random() * 80) - 40;
            let randomOffsetY = Math.floor(Math.random() * 80) - 40;

            tables.push({
                label: tableName,
                l: baseL + randomOffsetX,
                t: baseT + randomOffsetY,
                w: 80,
                h: 120,
                shape: "rect",
                pax: pax,
                room: currentRoom,
                isExtra: true
            });

            pushArchitecture();
            renderFloor();
        }

        async function promptRemoveExtraTable(tableName) {
            if (!(await requirePermission('FLOORPLAN_DELETE', { tableId: tableName }))) return;
            const reason = prompt('Motif obligatoire pour retirer cette table :');
            if (!reason || reason.trim().length < 5) return alert('Motif obligatoire.');

            const order = activeOrders[tableName];
            if (order && order.items && order.items.length > 0) {
                return alert('❌ Impossible de retirer une table contenant une commande active. Annulez ou transférez d’abord la commande selon la procédure autorisée.');
            }

            const response = await secureFetch('/api/floorplan/tables/archive', {
                method: 'POST',
                body: JSON.stringify({ tenantID: appTenantID, tableId: tableName, room: currentRoom, reason: reason.trim() })
            });
            const result = await response.json().catch(() => ({}));
            if (!response.ok || !result.success) return alert(result.error || 'Suppression refusée.');

            tables = tables.filter(t => !(t && t.label === tableName && t.room === currentRoom));
            await auditEvent('FLOORPLAN_TABLE_ARCHIVED', { tableId: tableName, room: currentRoom, reason: reason.trim() }, false);
            pushArchitecture(); closeOrder(); renderFloor();
        }

        // ==========================================
        // 🧑‍🤝‍🧑 GESTION DES CLIENTS EXTRA (SIÈGES EN PLUS)
        // ==========================================
        async function addExtraClient() {
            let tableName = prompt("🧑‍🤝‍🧑 À quelle table voulez-vous ajouter un client supplémentaire ?\n(ex: 12, T1)");
            if (!tableName) return;
            tableName = tableName.trim().toUpperCase();

            let tObj = tables.find(t => t && t.label === tableName && t.room === currentRoom);
            if (!tObj) {
                return alert(`❌ ERREUR HUMAINE : La table "${tableName}" n'existe pas dans la salle "${currentRoom}". Vérifiez votre saisie.`);
            }

            let extraStr = prompt(`Combien de clients voulez-vous ajouter à la table ${tableName} ?`, "1");
            let extra = parseInt(extraStr);
            if (isNaN(extra) || extra <= 0) return;

            tObj.extraPax = (tObj.extraPax || 0) + extra;
            tObj.pax = (tObj.pax || 2) + extra;
            
            pushArchitecture();

            let order = activeOrders[tableName];
            if (!order) order = { status: 'active', items: [], observations: '' };
            
            let baseObs = order.observations || "";
            baseObs = baseObs.replace(/🍽️ \d+ Couvert\(s\)( \| )?/, '').replace(/ \| $/, '').trim();
            order.observations = `🍽️ ${tObj.pax} Couvert(s) | ⚠️ +${tObj.extraPax} EXTRA(S) | ${baseObs}`;
            
            await API.update(tableName, order, true);
            
            await API.update('ALERTS_MASTER', { 
                type: 'RING', 
                message: `⚠️ NOUVEAU CLIENT EXTRA AJOUTÉ À LA TABLE ${tableName} (+${extra} Couvert(s))` 
            });

            renderFloor();
            alert(`✅ C'est validé ! ${extra} client(s) ajouté(s) à la table ${tableName}. La cuisine a été prévenue.`);
        }

        function openQuickOrder() {
            const tempTableId = "W" + Math.floor(Math.random() * 1000);
            openOrder(tempTableId);
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.btn-mini').forEach(item => {
                item.addEventListener('click', () => {
                    if(window.innerWidth <= 900 && item.id !== 'btn-rush-toggle') {
                        let sidebar = document.getElementById('sidebar');
                        if (sidebar && sidebar.classList.contains('open')) toggleMobileMenu();
                    }
                });
            });
        });

// =========================================================
// iCHEF — DOSSIERS RAPIDES / OPTIMISATION SERVICE
// =========================================================
function closeQuickFolders() {
    document.querySelectorAll('.quick-folder-panel.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.folder-btn.open').forEach(b => b.classList.remove('open'));
}

function toggleQuickFolder(id, button) {
    const panel = document.getElementById(id);
    if (!panel) return;

    const shouldOpen = !panel.classList.contains('open');
    closeQuickFolders();

    if (shouldOpen) {
        panel.classList.add('open');
        if (button) button.classList.add('open');
    }
}

function toggleCompactFiscal() {
    const banner = document.getElementById('pad-fiscal-banner');
    const btn = document.getElementById('btn-modules-toggle');
    if (!banner) return;

    const isHidden = banner.classList.toggle('compact-hidden');
    if (btn) btn.classList.toggle('modules-open', !isHidden);
}

// Fermer les dossiers avec Échap ou clic hors dossier.
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeQuickFolders();
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('.quick-folder-panel') && !e.target.closest('.folder-btn')) {
        closeQuickFolders();
    }
});
