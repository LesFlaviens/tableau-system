(function () {
    function unifyIchefHeader() {
        const dock = document.getElementById('service-tools-bar');
        if (!dock || dock.dataset.unified === '1') return;

        // Cherche le header qui contient les contrôles principaux du Pad.
        const candidates = Array.from(document.querySelectorAll('header, .topbar, #topbar, .header, body > div'));
        let header = candidates.find(el => {
            const t = (el.innerText || '').toUpperCase();
            return t.includes('PAD SERVEUR') &&
                   t.includes('LIAISON') &&
                   (t.includes('CONFIG') || t.includes('QUITTER'));
        });

        if (!header) return;

        // Évite de sélectionner un gros wrapper qui contient déjà tout le document.
        const nested = Array.from(header.querySelectorAll('header, .topbar, #topbar, .header, div')).find(el => {
            if (el === header) return false;
            const t = (el.innerText || '').toUpperCase();
            return t.includes('PAD SERVEUR') &&
                   t.includes('LIAISON') &&
                   (t.includes('CONFIG') || t.includes('QUITTER')) &&
                   !el.contains(dock);
        });
        if (nested) header = nested;

        // Insère le menu avant CONFIG/RETOUR/QUITTER si un groupe d'actions existe.
        const children = Array.from(header.children);
        let actionGroup = children.find(el => {
            const t = (el.innerText || '').toUpperCase();
            return t.includes('CONFIG') && (t.includes('RETOUR') || t.includes('QUITTER'));
        });

        if (actionGroup) {
            header.insertBefore(dock, actionGroup);
        } else {
            const configButton = Array.from(header.querySelectorAll('button,a')).find(el =>
                (el.innerText || '').toUpperCase().includes('CONFIG')
            );
            if (configButton && configButton.parentElement === header) {
                header.insertBefore(dock, configButton);
            } else {
                header.appendChild(dock);
            }
        }

        dock.dataset.unified = '1';
        document.body.classList.add('ichef-unified-header');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', unifyIchefHeader);
    } else {
        unifyIchefHeader();
    }

    // Deuxième passage si le Pad construit une partie du header dynamiquement.
    setTimeout(unifyIchefHeader, 300);
    setTimeout(unifyIchefHeader, 1200);
})();
