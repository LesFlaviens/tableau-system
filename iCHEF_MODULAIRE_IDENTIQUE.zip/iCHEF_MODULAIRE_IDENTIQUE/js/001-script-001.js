    "use strict";

    const ICHEF_ALLOWED_HOSTS = new Set(["os.ichef.ch", "localhost", "127.0.0.1"]);
    if (!ICHEF_ALLOWED_HOSTS.has(window.location.hostname)) {
        document.documentElement.innerHTML = "<h1 style='color:red;text-align:center;margin-top:20%;font-family:sans-serif'>🛑 ACCÈS NON AUTORISÉ</h1>";
        throw new Error("Hôte non autorisé");
    }

    // Les protections d'interface ne remplacent jamais la sécurité serveur.
    document.addEventListener('contextmenu', event => event.preventDefault());

    function getOrCreateDeviceId() {
        const key = 'ichef_device_id';
        let deviceId = localStorage.getItem(key);
        if (!deviceId) {
            const bytes = new Uint8Array(24);
            crypto.getRandomValues(bytes);
            deviceId = 'dev_' + Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
            localStorage.setItem(key, deviceId);
        }
        return deviceId;
    }

    window.ICHEF_SECURITY = {
        deviceId: getOrCreateDeviceId(),
        sessionToken: null, // Mémoire uniquement : jamais dans localStorage/sessionStorage.
        csrfToken: null,
        user: null,
        permissions: new Set(),
        authenticatedAt: null,
        lastActivityAt: Date.now()
    };

    (async function enforceSecurity() {
        const params = new URLSearchParams(window.location.search);
        const urlTenantID = params.get('tenantID');
        const storedTenantID = localStorage.getItem('ichef_tenant_id');

        if (urlTenantID && !/^[A-Za-z0-9_-]{2,80}$/.test(urlTenantID)) {
            throw new Error('tenantID invalide');
        }
        if (urlTenantID && urlTenantID !== storedTenantID) {
            localStorage.removeItem('EMPIRE_GLOBAL_SYNC');
            localStorage.setItem('ichef_tenant_id', urlTenantID);
        }

        const tenantID = urlTenantID || storedTenantID;
        if (!tenantID) {
            window.location.replace('connexionpartenaire.html');
            return;
        }

        const SERVER_URL = (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
            ? 'http://localhost:10000'
            : 'https://tableau-system.onrender.com';

        try {
            const response = await fetch(`${SERVER_URL}/api/security/bootstrap`, {
                method: 'POST',
                credentials: 'include',
                cache: 'no-store',
                headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'iCHEF-PWA' },
                body: JSON.stringify({ tenantID, deviceId: window.ICHEF_SECURITY.deviceId, page: location.pathname.split('/').pop() || 'index.html' })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.success) {
                alert(data.error || 'Terminal non autorisé.');
                window.location.replace('connexionpartenaire.html');
                return;
            }
            window.ICHEF_SECURITY.csrfToken = data.csrfToken || null;
        } catch (error) {
            console.error('Initialisation sécurité impossible', error);
            document.addEventListener('DOMContentLoaded', () => {
                const tag = document.getElementById('stock-tag');
                if (tag) tag.textContent = '● SÉCURITÉ INDISPONIBLE';
            });
        }
    })();
    
