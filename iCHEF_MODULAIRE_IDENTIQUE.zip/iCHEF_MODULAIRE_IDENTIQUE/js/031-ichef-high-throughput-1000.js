(function(){
    'use strict';

    /* Empêche les GET complets de se chevaucher lorsque le réseau ralentit. */
    if (typeof syncData === 'function' && !window.__ichefHighLoadSyncInstalled) {
        window.__ichefHighLoadSyncInstalled = true;

        const originalSyncData = syncData;
        let syncInFlight = null;
        let lastSyncStartedAt = 0;

        syncData = async function(){
            if (document.hidden || !navigator.onLine) return false;

            if (syncInFlight) return syncInFlight;

            lastSyncStartedAt = Date.now();
            syncInFlight = Promise.resolve()
                .then(() => originalSyncData())
                .catch(err => {
                    console.warn('[iCHEF] Sync haute charge:', err);
                    return false;
                })
                .finally(() => {
                    syncInFlight = null;
                });

            return syncInFlight;
        };

        window.ICHEF_HIGH_LOAD_STATUS = {
            profile: '1000_COVERS_DAY',
            get syncBusy(){ return !!syncInFlight; },
            get lastSyncStartedAt(){ return lastSyncStartedAt; },
            get pendingTableWrites(){
                try { return ICHEF_TABLE_WRITE_QUEUES.size; }
                catch(_) { return 0; }
            }
        };
    }

    /* Dès que le pad revient au premier plan, une seule synchro immédiate. */
    let resumeTimer = 0;
    function resumeSync(){
        clearTimeout(resumeTimer);
        resumeTimer = setTimeout(() => {
            if (!document.hidden && navigator.onLine && typeof syncData === 'function') {
                syncData();
            }
        }, 80);
    }

    document.addEventListener('visibilitychange', function(){
        if (!document.hidden) resumeSync();
    }, {passive:true});

    window.addEventListener('online', resumeSync, {passive:true});
})();
