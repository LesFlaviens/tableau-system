/* PRIORITÉ SERVICE : tables PRÊTES toujours en tête de grille. */
(function(){
"use strict";

function normState(v){
    return String(v == null ? "" : v)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g,"")
        .trim()
        .toUpperCase();
}

function normTable(v){
    return String(v == null ? "" : v)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g,"")
        .toUpperCase()
        .replace(/[^A-Z0-9]/g,"");
}

function served(item){
    if(!item) return false;
    const st=normState(item.status);
    const seq=normState(item.sequenceStatus);
    return item.served===true ||
           st==="SERVI" ||
           st==="SERVED" ||
           seq==="SERVED";
}

function taken(item){
    if(!item) return false;
    const st=normState(item.status);
    return item.pickedByServer===true ||
           st==="PRIS_PAR_SERVEUR" ||
           st==="PRIS PAR SERVEUR";
}

function ready(item){
    if(!item || served(item) || taken(item)) return false;

    const st=normState(item.status);
    const seq=normState(item.sequenceStatus);

    return item.done===true ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(seq) ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(st);
}

function readyCount(order){
    if(!order || !Array.isArray(order.items)) return 0;

    return order.items.reduce((sum,item)=>{
        if(!ready(item)) return sum;
        const q=Math.max(1,Number(item.qty ?? item.quantity ?? 1) || 1);
        return sum + q;
    },0);
}

function orderReady(order){
    if(!order) return false;

    const count=readyCount(order);
    if(count>0) return true;

    /* secours pour anciens tickets sans détail article */
    if(!Array.isArray(order.items) || !order.items.length){
        const s=normState(
            order.productionStatus ||
            order.orderMeta?.productionStatus ||
            order.status
        );
        return ["READY","PRET_AU_PASS","PRET AU PASS"].includes(s);
    }

    return false;
}

function readySince(order){
    if(!order || !Array.isArray(order.items)) return Number.MAX_SAFE_INTEGER;

    const times=order.items
        .filter(ready)
        .map(item=>{
            const raw =
                item.readyAt ??
                item.updatedAt ??
                item.productionReadyAt ??
                null;

            if(raw==null) return null;

            if(typeof raw==="number" && Number.isFinite(raw)) return raw;

            const parsed=Date.parse(raw);
            return Number.isFinite(parsed) ? parsed : null;
        })
        .filter(v=>Number.isFinite(v));

    return times.length ? Math.min(...times) : Number.MAX_SAFE_INTEGER;
}

function baseTableIndex(label){
    try{
        const wanted=normTable(label);
        const room=(typeof currentRoom!=="undefined") ? currentRoom : null;
        const list=(typeof tables!=="undefined" && Array.isArray(tables))
            ? tables.filter(t=>t && (!room || t.room===room))
            : [];

        const idx=list.findIndex(t=>normTable(t?.label)===wanted);
        return idx>=0 ? idx : 999999;
    }catch(_){
        return 999999;
    }
}

function sortReadyTablesFirst(){
    const grid=document.querySelector("#pro-table-grid");
    if(!grid) return;

    const cards=Array.from(grid.querySelectorAll(":scope > .pro-table-card[data-table]"));
    if(cards.length<2) return;

    const decorated=cards.map(card=>{
        const label=card.dataset.table || "";
        const order=findOrder(label);
        const isReady=orderReady(order);

        return {
            card,
            label,
            isReady,
            since:isReady ? readySince(order) : Number.MAX_SAFE_INTEGER,
            base:baseTableIndex(label)
        };
    });

    decorated.sort((a,b)=>{
        if(a.isReady!==b.isReady) return a.isReady ? -1 : 1;

        /* Parmi les PRÊTES : celle qui attend depuis le plus longtemps d'abord. */
        if(a.isReady && b.isReady && a.since!==b.since){
            return a.since-b.since;
        }

        /* Sinon : ordre normal de la salle. */
        return a.base-b.base;
    });

    /*
      PERFORMANCE :
      Ne déplacer les cartes QUE si l'ordre visuel doit réellement changer.
      Cela évite de déclencher en boucle tous les MutationObserver du PAD.
    */
    const currentOrder=cards.map(card=>card.dataset.table||"").join("|");
    const targetOrder=decorated.map(x=>x.label).join("|");

    if(currentOrder===targetOrder) return;

    const frag=document.createDocumentFragment();
    decorated.forEach(x=>frag.appendChild(x.card));
    grid.appendChild(frag);
}

function orders(){
    try{
        if(typeof activeOrders!=="undefined" && activeOrders){
            return activeOrders;
        }
    }catch(_){}
    return {};
}

function findOrder(label){
    const all=orders();
    const wanted=normTable(label);
    if(!wanted) return null;

    try{
        if(all[label]) return all[label];
    }catch(_){}

    for(const key of Object.keys(all)){
        if(/MASTER|ARCHIVE|SETTINGS|RESERVATIONS|ALERTS/i.test(key)) continue;

        const nk=normTable(key);
        if(nk===wanted || ("T"+nk)===wanted || nk===("T"+wanted)){
            return all[key];
        }
    }
    return null;
}

function ensureBadge(card,count){
    let badge=card.querySelector(".ichef-card-live-state");

    if(!badge){
        badge=document.createElement("div");
        badge.className="ichef-card-live-state";
        card.appendChild(badge);
    }

    badge.textContent = count>1 ? `✅ ${count} PRÊTS` : "✅ PRÊT";
}

function clearReadyBadge(card){
    const badge=card.querySelector(".ichef-card-live-state");
    if(
        badge &&
        /PRÊT|PRET/i.test(badge.textContent||"") &&
        !card.classList.contains("ichef-order-production") &&
        !card.classList.contains("ichef-order-input")
    ){
        badge.remove();
    }
}

function syncCards(){
    document.querySelectorAll(".pro-table-card[data-table]").forEach(card=>{
        const order=findOrder(card.dataset.table);
        const isReady=orderReady(order);
        const count=readyCount(order);

        card.classList.toggle("ichef-ready-neon-fixed",isReady);

        if(isReady){
            ensureBadge(card,count || 1);
        }else{
            clearReadyBadge(card);
        }
    });

    document.querySelectorAll(".mobile-exact-table[data-table]").forEach(card=>{
        const order=findOrder(card.dataset.table);
        card.classList.toggle("ichef-ready-neon-fixed",orderReady(order));
    });
}

function syncFloor(){
    document.querySelectorAll(".floor-plan .table-wrapper").forEach(wrapper=>{
        const label=
            wrapper.dataset.id ||
            wrapper.dataset.table ||
            wrapper.dataset.tableId ||
            wrapper.dataset.label ||
            "";

        const order=findOrder(label);
        wrapper.classList.toggle("ichef-ready-neon-fixed",orderReady(order));
    });
}

function sync(){
    syncCards();
    syncFloor();
    sortReadyTablesFirst();
}

window.ichefRefreshReadyNeon=sync;

/* Mise à jour légère, sans animation et sans modifier la géométrie */
/* Fallback seulement. Les changements serveur déclenchent déjà le refresh immédiat. */
let __ichefReadyFallbackTimer=setInterval(()=>{
    if(document.hidden) return;
    sync();
},1500);

window.addEventListener("focus",sync,{passive:true});
document.addEventListener("visibilitychange",()=>{
    if(!document.hidden) sync();
});

if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",()=>{
        setTimeout(sync,200);
    },{once:true});
}else{
    setTimeout(sync,200);
}

})();
