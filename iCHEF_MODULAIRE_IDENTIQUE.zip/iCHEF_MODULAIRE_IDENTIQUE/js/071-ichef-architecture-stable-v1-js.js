(function(){
'use strict';
if(window.__ICHEF_ARCHITECTURE_STABLE_V1__) return;
window.__ICHEF_ARCHITECTURE_STABLE_V1__=true;

let rushBeforeArchitecture=false;
let archiPointerActive=false;

function clamp(v,min,max){
    if(!Number.isFinite(v)) return min;
    return Math.max(min,Math.min(max,v));
}

/* Remplace le moteur historique mouse/touch par Pointer Events.
   Le même code gère souris, doigt et stylet et ne remplace plus
   document.onmousemove / document.ontouchmove globalement. */
try{
    makeInteractive=function(elmnt,tableObj,resizerElnt){
        if(!elmnt || !tableObj || !resizerElnt) return;

        let state=null;
        const MOVE_THRESHOLD=5;

        function floorNode(){
            return document.getElementById('floor-plan') || elmnt.parentElement;
        }

        function begin(e,mode){
            if(!isArchiMode) return;
            if(e.pointerType==='mouse' && e.button!==0) return;

            e.preventDefault();
            e.stopPropagation();

            const floor=floorNode();
            state={
                mode,
                pointerId:e.pointerId,
                startX:e.clientX,
                startY:e.clientY,
                startL:Number(tableObj.l)||elmnt.offsetLeft||0,
                startT:Number(tableObj.t)||elmnt.offsetTop||0,
                startW:Number(tableObj.w)||elmnt.offsetWidth||80,
                startH:Number(tableObj.h)||elmnt.offsetHeight||80,
                moved:false,
                floorW:floor ? (floor.scrollWidth || floor.clientWidth || 2000) : 2000,
                floorH:floor ? (floor.scrollHeight || floor.clientHeight || 1500) : 1500
            };
            archiPointerActive=true;
            isDraggingTable=false;
            elmnt.classList.add(mode==='resize'?'ichef-archi-resizing':'ichef-archi-moving');
            try{elmnt.setPointerCapture(e.pointerId);}catch(_){ }
        }

        function move(e){
            if(!state || e.pointerId!==state.pointerId || !isArchiMode) return;
            e.preventDefault();

            const dx=e.clientX-state.startX;
            const dy=e.clientY-state.startY;
            if(!state.moved && Math.hypot(dx,dy)>=MOVE_THRESHOLD){
                state.moved=true;
                isDraggingTable=true;
            }
            if(!state.moved) return;

            if(state.mode==='resize'){
                const minW=40,minH=40;
                const maxW=Math.max(minW,state.floorW-state.startL);
                const maxH=Math.max(minH,state.floorH-state.startT);
                const w=clamp(state.startW+dx,minW,maxW);
                const h=clamp(state.startH+dy,minH,maxH);
                elmnt.style.width=w+'px';
                elmnt.style.height=h+'px';
                tableObj.w=Math.round(w);
                tableObj.h=Math.round(h);
            }else{
                const maxL=Math.max(0,state.floorW-elmnt.offsetWidth);
                const maxT=Math.max(0,state.floorH-elmnt.offsetHeight);
                const l=clamp(state.startL+dx,0,maxL);
                const t=clamp(state.startT+dy,0,maxT);
                elmnt.style.left=l+'px';
                elmnt.style.top=t+'px';
                tableObj.l=Math.round(l);
                tableObj.t=Math.round(t);
            }
        }

        function end(e){
            if(!state || (e && e.pointerId!==state.pointerId)) return;
            const moved=state.moved;
            const pointerId=state.pointerId;
            state=null;
            archiPointerActive=false;
            elmnt.classList.remove('ichef-archi-moving','ichef-archi-resizing');
            try{elmnt.releasePointerCapture(pointerId);}catch(_){ }

            if(moved){
                /* Le click synthétique tactile peut arriver plusieurs centaines de ms après. */
                elmnt.dataset.ichefArchiSuppressClickUntil=String(Date.now()+850);
                isDraggingTable=true;
                setTimeout(()=>{ if(!archiPointerActive) isDraggingTable=false; },900);
            }else{
                isDraggingTable=false;
            }
            /* IMPORTANT : aucun renderFloor() ici.
               L'objet tables/zones est déjà à jour et le DOM est déjà positionné. */
        }

        elmnt.addEventListener('pointerdown',function(e){
            if(e.target===resizerElnt || resizerElnt.contains(e.target)) return;
            begin(e,'drag');
        },{passive:false});
        resizerElnt.addEventListener('pointerdown',function(e){begin(e,'resize');},{passive:false});
        elmnt.addEventListener('pointermove',move,{passive:false});
        elmnt.addEventListener('pointerup',end,{passive:false});
        elmnt.addEventListener('pointercancel',end,{passive:false});
        elmnt.addEventListener('lostpointercapture',function(){
            if(state) end({pointerId:state.pointerId});
        });
    };
}catch(err){
    console.error('[iCHEF] installation moteur Architecture',err);
}

/* Un déplacement ne doit jamais être interprété ensuite comme un tap
   ouvrant la configuration de la table/zone. */
document.addEventListener('click',function(e){
    if(!document.body.classList.contains('edit-mode')) return;
    const wrapper=e.target?.closest?.('#floor-plan .table-wrapper, #floor-plan .zone-wrapper');
    if(!wrapper) return;
    const until=Number(wrapper.dataset.ichefArchiSuppressClickUntil||0);
    if(until>Date.now()){
        e.preventDefault();
        e.stopImmediatePropagation();
    }
},true);

/* Architecture doit toujours afficher la géométrie réelle, jamais la vue Rush. */
try{
    const originalUnlock=unlockArchiMode;
    unlockArchiMode=function(){
        if(!currentUser || currentUser.role!=='Manager'){
            return alert('⛔ Accès Manager requis');
        }

        rushBeforeArchitecture=!!isRushMode || document.body.classList.contains('rush-mode');
        if(isRushMode) isRushMode=false;
        document.body.classList.remove('rush-mode');

        try{ window.ichefCloseTableDetails?.(); }catch(_){ }
        isArchiMode=true;
        isDraggingTable=false;
        document.body.classList.add('edit-mode');
        renderRooms();
        renderFloor();

        const btn=document.getElementById('btn-rush-toggle');
        if(btn){
            btn.innerHTML='⚡ MODE RUSH';
            btn.style.borderColor='var(--text-main)';
            btn.style.color='var(--bg)';
            btn.style.background='var(--text-main)';
        }
    };
}catch(err){console.error('[iCHEF] unlock Architecture',err);}

try{
    closeArchiMode=async function(){
        isDraggingTable=false;
        archiPointerActive=false;
        isArchiMode=false;
        document.body.classList.remove('edit-mode');

        /* On revient en vue plan normale après édition. Le mode Rush ne se
           réactive pas tout seul : cela évite un changement de géométrie surprise. */
        isRushMode=false;
        document.body.classList.remove('rush-mode');
        renderRooms();
        renderFloor();
        rushBeforeArchitecture=false;
    };
}catch(err){console.error('[iCHEF] close Architecture',err);}

/* Filet de sécurité : si un ancien script tente de basculer Rush pendant
   l'édition Architecture, on refuse le changement. */
try{
    const originalToggleRush=toggleRushMode;
    toggleRushMode=function(){
        if(isArchiMode || document.body.classList.contains('edit-mode')) return;
        return originalToggleRush.apply(this,arguments);
    };
}catch(_){ }

})();
