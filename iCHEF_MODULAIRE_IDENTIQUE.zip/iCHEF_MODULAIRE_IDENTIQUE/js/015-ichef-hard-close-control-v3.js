window.ichefHardCloseControl = function(ev){
  try{
    if(ev){
      ev.preventDefault();
      ev.stopPropagation();
      if(ev.stopImmediatePropagation) ev.stopImmediatePropagation();
    }
    var m = document.getElementById('control-mode-modal');
    if(!m) return false;
    m.classList.remove('open');
    m.hidden = true;
    m.setAttribute('aria-hidden','true');
    m.style.cssText += ';display:none !important;visibility:hidden !important;opacity:0 !important;pointer-events:none !important;';
  }catch(e){ console.error('[iCHEF hard close]',e); }
  return false;
};

window.ichefHardOpenControlReset = function(){
  var m=document.getElementById('control-mode-modal');
  if(!m) return;
  m.hidden=false;
  m.removeAttribute('aria-hidden');
  m.style.removeProperty('display');
  m.style.removeProperty('visibility');
  m.style.removeProperty('opacity');
  m.style.removeProperty('pointer-events');
};

// Capture at document level BEFORE normal bubbling handlers.
document.addEventListener('pointerdown', function(e){
  var b=e.target && e.target.closest ? e.target.closest('#control-close-btn') : null;
  if(b) window.ichefHardCloseControl(e);
}, true);
document.addEventListener('touchstart', function(e){
  var b=e.target && e.target.closest ? e.target.closest('#control-close-btn') : null;
  if(b) window.ichefHardCloseControl(e);
}, {capture:true,passive:false});
