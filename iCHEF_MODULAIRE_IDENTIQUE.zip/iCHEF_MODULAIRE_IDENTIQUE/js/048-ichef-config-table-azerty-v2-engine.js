(function(){
'use strict';
function panel(){return document.getElementById('table-config-modal')}
function display(){return document.getElementById('config-table-name-display')}
function sync(v){
 v=String(v||'').toUpperCase().slice(0,20);
 window.currentTactileName=v;
 try{currentTactileName=v}catch(e){}
 const d=display(); if(d)d.textContent=v||'—';
}
function value(){
 try{if(typeof currentTactileName!=='undefined')return String(currentTactileName||'')}catch(e){}
 const d=display(); return d&&d.textContent!=='—'?String(d.textContent||''):'';
}
function hideOriginalKeys(p){
 const cap=[...p.querySelectorAll('label')].find(x=>(x.textContent||'').toUpperCase().includes('CAPACITÉ'));
 const capTop=cap?cap.getBoundingClientRect().top:Infinity;
 p.querySelectorAll('.key-row').forEach(r=>{if(r.getBoundingClientRect().top<capTop)r.style.display='none'});
 [...p.querySelectorAll('button')].forEach(b=>{if((b.textContent||'').trim().toUpperCase()==='EFFACER' && b.getBoundingClientRect().top<capTop)b.style.display='none'});
}
function key(k,cls=''){return `<button type="button" class="${cls}" data-key="${k}">${k}</button>`}
function build(){
 const p=panel(); if(!p)return;
 hideOriginalKeys(p);
 let kb=p.querySelector('#ichef-config-table-azerty-v2');
 if(!kb){
   kb=document.createElement('div'); kb.id='ichef-config-table-azerty-v2';
   const nums='1234567890'.split('').map(x=>key(x)).join('');
   const r1='AZERTYUIOP'.split('').map(x=>key(x)).join('');
   const r2='QSDFGHJKLM'.split('').map(x=>key(x)).join('');
   const r3='WXCVBN'.split('').map(x=>key(x)).join('')+key('-')+key('.')+key("'");
   kb.innerHTML=`<div class="kb-row kb-num">${nums}</div><div class="kb-row kb-r1">${r1}</div><div class="kb-row kb-r2">${r2}</div><div class="kb-row kb-r3">${r3}</div><div class="kb-row kb-actions"><button type="button" class="kb-clear" data-action="clear">C</button><button type="button" class="kb-space" data-key=" ">ESPACE</button><button type="button" class="kb-back" data-action="back">⌫</button><button type="button" data-action="done">OK</button></div><div class="kb-shortcuts"><button type="button" data-short="T">TABLE T</button><button type="button" data-short="EXT">EXT</button><button type="button" data-short="CH">CHAMBRE</button><button type="button" data-short="S">SUITE</button><button type="button" data-short="RS">ROOM SERVICE</button></div>`;
   kb.addEventListener('click',e=>{
     const b=e.target.closest('button'); if(!b)return; e.preventDefault();e.stopPropagation();
     let v=value();
     if(b.dataset.action==='clear')return sync('');
     if(b.dataset.action==='back')return sync(v.slice(0,-1));
     if(b.dataset.action==='done'){const cap=[...p.querySelectorAll('label')].find(x=>(x.textContent||'').toUpperCase().includes('CAPACITÉ'));cap?.scrollIntoView({behavior:'smooth',block:'center'});return}
     if(b.dataset.short)return sync(v+b.dataset.short);
     if('key' in b.dataset)return sync(v+b.dataset.key);
   });
   const d=display();
   const host=d?.parentElement?.parentElement || p.querySelector('div');
   const cap=[...p.querySelectorAll('label')].find(x=>(x.textContent||'').toUpperCase().includes('CAPACITÉ'));
   if(cap) cap.parentElement.insertBefore(kb,cap.previousElementSibling||cap); else host?.appendChild(kb);
 }
 sync(value());
}
const oldOpen=window.openTableConfigModal;
if(typeof oldOpen==='function')window.openTableConfigModal=function(){const r=oldOpen.apply(this,arguments);setTimeout(build,0);return r};
document.addEventListener('click',()=>setTimeout(build,10),true);
{const p=panel();if(p){let raf=0;new MutationObserver(()=>{if(raf)return;raf=requestAnimationFrame(()=>{raf=0;if(getComputedStyle(p).display!=='none')build();});}).observe(p,{subtree:true,childList:true,attributes:true,attributeFilter:['style','class']});}}
setTimeout(build,200);
})();
