(function(){
"use strict";

const REGION_KEY="ichef_ticket_top_region_v11";
const LIST_KEY="ichef_ticket_split_v4";
const MIN_REGION=0;
const MIN_LIST=30;

let drag=null;
let raf=0;
let pendingRegionH=0;

function getParts(){
    const drawer=document.getElementById("order-drawer");
    if(!drawer || !drawer.classList.contains("open")) return null;

    const ticket=drawer.querySelector(".ticket-view");
    const list=document.getElementById("ticket-list");

    if(!ticket || !list) return null;

    const region=document.getElementById("ichef-ticket-top-region-v11");
    const bar=document.getElementById("ichef-ticket-topbar-v11");

    return {drawer,ticket,list,region,bar};
}

function setRegionHeight(region,h){
    const value=Math.max(MIN_REGION,Math.round(Number(h)||0));
    region.style.setProperty(
        "--ichef-top-region-v11-h",
        value+"px"
    );
}

function setListHeight(list,h){
    const value=Math.max(MIN_LIST,Math.round(Number(h)||MIN_LIST));

    list.classList.add("ichef-ticket-list-resizable");
    list.style.setProperty(
        "--ichef-ticket-white-h",
        value+"px"
    );
}

function regionHeight(region){
    return Math.max(
        0,
        region.getBoundingClientRect().height
    );
}

function listHeight(list){
    return Math.max(
        MIN_LIST,
        list.getBoundingClientRect().height
    );
}

function applyFrame(){
    raf=0;
    if(!drag) return;

    /*
      Somme constante :
      région supérieure + zone des plats.
      La barre se déplace réellement parce que la région
      change réellement de hauteur.
    */
    const maxRegion=Math.max(
        MIN_REGION,
        drag.totalFlexible-MIN_LIST
    );

    const newRegion=Math.max(
        MIN_REGION,
        Math.min(pendingRegionH,maxRegion)
    );

    const newList=Math.max(
        MIN_LIST,
        drag.totalFlexible-newRegion
    );

    setRegionHeight(drag.region,newRegion);
    setListHeight(drag.list,newList);
}

function onMove(e){
    if(!drag || e.pointerId!==drag.pointerId) return;

    if(e.cancelable) e.preventDefault();
    e.stopPropagation();

    const delta=e.clientY-drag.startY;

    /*
      Monter = delta négatif = région se rétracte.
      Descendre = delta positif = région s'agrandit.
    */
    pendingRegionH=drag.startRegionH+delta;

    if(!raf){
        raf=requestAnimationFrame(applyFrame);
    }
}

function finish(e){
    if(!drag) return;
    if(e && e.pointerId!=null && e.pointerId!==drag.pointerId) return;

    if(raf){
        cancelAnimationFrame(raf);
        raf=0;
        applyFrame();
    }

    const finalRegion=regionHeight(drag.region);
    const finalList=listHeight(drag.list);

    try{
        localStorage.setItem(
            REGION_KEY,
            String(Math.round(finalRegion))
        );
        localStorage.setItem(
            LIST_KEY,
            String(Math.round(finalList))
        );
    }catch(_){}

    drag.bar.classList.remove("dragging");
    document.body.classList.remove("ichef-topbar-v11-dragging");

    try{
        drag.bar.releasePointerCapture(drag.pointerId);
    }catch(_){}

    window.removeEventListener("pointermove",onMove,true);
    window.removeEventListener("pointerup",finish,true);
    window.removeEventListener("pointercancel",finish,true);

    drag=null;
}

function start(e){
    if(window.innerWidth<900) return;
    if(e.pointerType==="mouse" && e.button!==0) return;

    const p=getParts();
    if(!p?.region || !p?.bar) return;

    if(e.cancelable) e.preventDefault();
    e.stopPropagation();

    const rh=regionHeight(p.region);
    const lh=listHeight(p.list);

    drag={
        ...p,
        pointerId:e.pointerId,
        startY:e.clientY,
        startRegionH:rh,
        startListH:lh,
        totalFlexible:rh+lh
    };

    pendingRegionH=rh;

    p.bar.classList.add("dragging");
    document.body.classList.add("ichef-topbar-v11-dragging");

    try{
        p.bar.setPointerCapture(e.pointerId);
    }catch(_){}

    window.addEventListener(
        "pointermove",
        onMove,
        {capture:true,passive:false}
    );
    window.addEventListener(
        "pointerup",
        finish,
        {capture:true,passive:false}
    );
    window.addEventListener(
        "pointercancel",
        finish,
        {capture:true,passive:false}
    );
}

function resetToNormal(){
    const p=getParts();
    if(!p?.region) return;

    /*
      Mesure de la hauteur naturelle complète du bloc supérieur.
    */
    const old=p.region.style.getPropertyValue(
        "--ichef-top-region-v11-h"
    );

    p.region.style.removeProperty(
        "--ichef-top-region-v11-h"
    );

    requestAnimationFrame(function(){
        const natural=Math.max(
            0,
            p.region.scrollHeight
        );

        const currentList=listHeight(p.list);
        const currentRegion=regionHeight(p.region);

        /*
          On garde une hauteur globale cohérente.
        */
        const total=Math.max(
            natural+MIN_LIST,
            currentList+currentRegion
        );

        const targetRegion=Math.min(
            natural,
            total-MIN_LIST
        );

        const targetList=Math.max(
            MIN_LIST,
            total-targetRegion
        );

        setRegionHeight(p.region,targetRegion);
        setListHeight(p.list,targetList);

        try{
            localStorage.setItem(
                REGION_KEY,
                String(Math.round(targetRegion))
            );
            localStorage.setItem(
                LIST_KEY,
                String(Math.round(targetList))
            );
        }catch(_){}
    });
}

function jumpTop(){
    const p=getParts();
    if(!p?.region) return;

    const total=regionHeight(p.region)+listHeight(p.list);

    setRegionHeight(p.region,0);
    setListHeight(p.list,total);

    try{
        localStorage.setItem(REGION_KEY,"0");
        localStorage.setItem(
            LIST_KEY,
            String(Math.round(total))
        );
    }catch(_){}
}

function createRegion(ticket){
    let region=document.getElementById(
        "ichef-ticket-top-region-v11"
    );

    if(region) return region;

    region=document.createElement("div");
    region.id="ichef-ticket-top-region-v11";

    /*
      On prend exactement les éléments situés après l'en-tête
      TABLE/FERMER et jusqu'à Observation inclus.
    */
    const header=ticket.firstElementChild;
    const obs=document.getElementById("order-obs");

    if(!header || !obs) return null;

    header.insertAdjacentElement("afterend",region);

    let node=region.nextSibling;

    while(node){
        const next=node.nextSibling;

        /*
          Ne déplacer que les éléments jusqu'à Observation inclus.
        */
        region.appendChild(node);

        if(node===obs) break;

        node=next;
    }

    return region;
}

function createBar(region){
    let bar=document.getElementById(
        "ichef-ticket-topbar-v11"
    );

    if(!bar){
        bar=document.createElement("div");
        bar.id="ichef-ticket-topbar-v11";
        bar.setAttribute("role","separator");
        bar.setAttribute("aria-orientation","horizontal");
        bar.setAttribute(
            "aria-label",
            "Agrandir au maximum la zone des plats"
        );

        const line=document.createElement("span");
        line.className="ichef-v11-line";

        const handle=document.createElement("span");
        handle.className="ichef-v11-handle";
        handle.textContent="⋮";

        bar.append(line,handle);

        bar.addEventListener(
            "pointerdown",
            start,
            {passive:false}
        );

        /*
          Double-clic / double-tap souris :
          bascule directement entre normal et HAUT MAXIMUM.
        */
        bar.addEventListener("dblclick",function(e){
            e.preventDefault();

            const p=getParts();
            if(!p?.region) return;

            if(regionHeight(p.region)>8){
                jumpTop();
            }else{
                resetToNormal();
            }
        });
    }

    /*
      La barre est physiquement APRÈS le bloc rétractable.
      Donc si le bloc vaut 0 px, elle est vraiment juste
      sous TABLE / FERMER.
    */
    if(
        bar.parentElement!==region.parentElement ||
        bar.previousElementSibling!==region
    ){
        region.insertAdjacentElement("afterend",bar);
    }

    return bar;
}

function restore(p){
    if(!p?.region) return;

    /*
      D'abord mesurer la hauteur naturelle du bloc supérieur.
    */
    p.region.style.removeProperty(
        "--ichef-top-region-v11-h"
    );

    requestAnimationFrame(function(){
        const natural=Math.max(
            0,
            p.region.scrollHeight
        );

        let savedRegion=null;

        try{
            const raw=localStorage.getItem(REGION_KEY);
            if(raw!==null){
                const n=parseFloat(raw);
                if(Number.isFinite(n)){
                    savedRegion=Math.max(0,n);
                }
            }
        }catch(_){}

        /*
          Première ouverture V11 = disposition normale complète.
        */
        const desired=
            savedRegion===null
                ? natural
                : savedRegion;

        const currentList=listHeight(p.list);
        const total=Math.max(
            desired+MIN_LIST,
            natural+currentList
        );

        const maxRegion=Math.max(
            0,
            total-MIN_LIST
        );

        const regionH=Math.min(
            desired,
            maxRegion
        );

        setRegionHeight(p.region,regionH);

        /*
          On n'écrase pas inutilement le réglage V4 de la liste
          s'il existe déjà.
        */
        if(
            !p.list.style.getPropertyValue(
                "--ichef-ticket-white-h"
            )
        ){
            setListHeight(
                p.list,
                Math.max(
                    MIN_LIST,
                    total-regionH
                )
            );
        }
    });
}

function install(){
    if(window.innerWidth<900) return;

    const drawer=document.getElementById("order-drawer");
    if(!drawer || !drawer.classList.contains("open")) return;

    const ticket=drawer.querySelector(".ticket-view");
    const list=document.getElementById("ticket-list");

    if(!ticket || !list) return;

    const region=createRegion(ticket);
    if(!region) return;

    const bar=createBar(region);
    if(!bar) return;

    list.classList.add(
        "ichef-ticket-list-resizable"
    );

    if(bar.dataset.v11Ready!=="1"){
        bar.dataset.v11Ready="1";
        restore({
            drawer,
            ticket,
            list,
            region,
            bar
        });
    }
}

function drawerState(){
    const drawer=document.getElementById("order-drawer");
    if(!drawer) return;

    if(drawer.classList.contains("open")){
        const bar=document.getElementById(
            "ichef-ticket-topbar-v11"
        );

        if(bar){
            delete bar.dataset.v11Ready;
        }

        requestAnimationFrame(install);
    }else{
        finish();
    }
}

function boot(){
    const drawer=document.getElementById("order-drawer");

    if(drawer){
        new MutationObserver(drawerState)
            .observe(
                drawer,
                {
                    attributes:true,
                    attributeFilter:["class"]
                }
            );
    }

    if(drawer?.classList.contains("open")){
        install();
    }

    window.addEventListener(
        "resize",
        function(){
            if(window.innerWidth>=900){
                requestAnimationFrame(install);
            }else{
                finish();
            }
        },
        {passive:true}
    );

    setTimeout(function(){
        if(
            document
                .getElementById("order-drawer")
                ?.classList.contains("open")
        ){
            install();
        }
    },250);
}

if(document.readyState==="loading"){
    document.addEventListener(
        "DOMContentLoaded",
        boot,
        {once:true}
    );
}else{
    boot();
}

})();
