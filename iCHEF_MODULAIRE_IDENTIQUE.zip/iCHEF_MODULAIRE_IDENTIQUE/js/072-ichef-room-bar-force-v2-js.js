(function(){
    'use strict';
    if(window.__ICHEF_ROOM_BAR_FORCE_V2__) return;
    window.__ICHEF_ROOM_BAR_FORCE_V2__=true;

    function setImp(el,prop,val){
        if(el) el.style.setProperty(prop,val,'important');
    }

    function applyRoomBarForce(){
        const tabs=document.querySelector('#pro-table-panel > #pro-room-tabs');
        if(!tabs) return;
        setImp(tabs,'display','flex');
        setImp(tabs,'align-items','center');
        setImp(tabs,'gap','10px');
        setImp(tabs,'padding','12px 16px');
        setImp(tabs,'min-height','78px');
        setImp(tabs,'flex','0 0 auto');
        setImp(tabs,'background','#090b0b');
        setImp(tabs,'border-bottom','2px solid rgba(244,200,90,.75)');
        setImp(tabs,'box-sizing','border-box');

        tabs.querySelectorAll('button.pro-room-btn').forEach(btn=>{
            setImp(btn,'flex','1 1 0');
            setImp(btn,'min-width','0');
            setImp(btn,'min-height','58px');
            setImp(btn,'height','58px');
            setImp(btn,'padding','10px 20px');
            setImp(btn,'border-radius','30px');
            setImp(btn,'font-size','1.18rem');
            setImp(btn,'line-height','1');
            setImp(btn,'font-weight','950');
            setImp(btn,'letter-spacing','.35px');
            setImp(btn,'text-align','center');
            if(btn.classList.contains('active')){
                setImp(btn,'background','#f4c85a');
                setImp(btn,'background-image','linear-gradient(180deg,#ffdc7c 0%,#e8b84b 100%)');
                setImp(btn,'color','#111');
                setImp(btn,'border','3px solid #ffe7a4');
                setImp(btn,'box-shadow','0 0 0 1px rgba(244,200,90,.35), 0 5px 14px rgba(0,0,0,.35)');
                setImp(btn,'text-shadow','none');
            }
        });
    }

    window.ichefApplyRoomBarForce=applyRoomBarForce;
    applyRoomBarForce();

    const mo=new MutationObserver(()=>applyRoomBarForce());
    mo.observe(document.documentElement,{childList:true,subtree:true});

    // Les cartes peuvent être recréées par renderProRooms(). On réapplique après rendu.
    try{
        if(typeof renderProRooms==='function' && !renderProRooms.__ichefRoomBarWrapped){
            const original=renderProRooms;
            renderProRooms=function(){
                const r=original.apply(this,arguments);
                queueMicrotask(applyRoomBarForce);
                return r;
            };
            renderProRooms.__ichefRoomBarWrapped=true;
        }
    }catch(_){ }

    setTimeout(applyRoomBarForce,100);
    setTimeout(applyRoomBarForce,500);
    setTimeout(applyRoomBarForce,1200);
})();
