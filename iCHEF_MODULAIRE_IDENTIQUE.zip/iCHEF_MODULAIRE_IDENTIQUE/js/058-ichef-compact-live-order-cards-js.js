(function(){
"use strict";

const CARD_STATE_CLASSES=[
    "ichef-order-input",
    "ichef-order-production",
    "ichef-order-ready",
    "ichef-order-finished"
];

function clean(v){
    return String(v == null ? "" : v).trim();
}

function realOrder(label){
    let o=null;
    try{o=window.activeOrders?.[label] || null;}catch(_){}
    if(!o) return null;

    try{
        if(typeof window.isRealServiceOrder==="function" &&
           !window.isRealServiceOrder(label,o)){
            return null;
        }
    }catch(_){}

    const items=Array.isArray(o.items)?o.items:[];
    const hasItem=items.some(i=>{
        if(!i || typeof i!=="object")return false;
        const name=clean(i.n ?? i.name ?? i.productName ?? i.title);
        const qty=Number(i.qty ?? i.quantity ?? 1);
        return !!name && Number.isFinite(qty) && qty>0;
    });

    return hasItem ? o : null;
}

function freshProductionStatus(order){
  if(!order)return "NONE";

  const norm=v=>String(v||"").trim().toUpperCase()
    .normalize("NFD").replace(/[\\u0300-\\u036f]/g,"");

  const items=(Array.isArray(order.items)?order.items:[]).filter(Boolean);
  if(!items.length){
    const meta=norm(order.productionStatus || order.orderMeta?.productionStatus || order.status);
    return ["READY","PRET_AU_PASS","PRET AU PASS"].includes(meta) ? "READY" :
           ["SERVED","SERVI"].includes(meta) ? "SERVED" :
           meta==="PRODUCTION" ? "PRODUCTION" : "WAITING";
  }

  const served=i =>
    i.served===true ||
    ["SERVED","SERVI"].includes(norm(i.sequenceStatus)) ||
    ["SERVED","SERVI"].includes(norm(i.status));

  const ready=i =>
    !served(i) && (
      i.done===true ||
      ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(norm(i.sequenceStatus)) ||
      ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(norm(i.status))
    );

  if(items.every(served)) return "SERVED";

  /* Une seule assiette/boisson prête suffit pour prévenir le serveur. */
  if(items.some(ready)) return "READY";

  if(items.some(i=>
    !served(i) &&
    i.isSent===true &&
    !["WAITING","DRAFT"].includes(norm(i.sequenceStatus))
  )) return "PRODUCTION";

  const meta=norm(order.productionStatus || order.orderMeta?.productionStatus || order.status);
  if(["READY","PRET_AU_PASS","PRET AU PASS"].includes(meta)) return "READY";
  if(["SERVED","SERVI"].includes(meta)) return "SERVED";
  if(meta==="PRODUCTION") return "PRODUCTION";

  return "WAITING";
}

function paymentFinished(order){
    const s=clean(order?.status).toUpperCase();
    if(s==="EN ATTENTE PAIEMENT") return true;

    const p=clean(
        order?.paymentStatus ||
        order?.orderMeta?.paymentStatus
    ).toUpperCase();

    return p==="PAYE" || p==="PAID" || p==="PARTIEL";
}

function seatOf(item){
    const n=Number(
        item?.seat ??
        item?.guestSeat ??
        item?.seatNumber ??
        0
    );
    return Number.isFinite(n) && n>0 ? Math.floor(n) : 0;
}

function itemName(item){
    return clean(
        item?.n ??
        item?.name ??
        item?.productName ??
        item?.title ??
        "Article"
    );
}

function compactOrderLines(order,maxLines=3){
    const items=(Array.isArray(order?.items)?order.items:[])
        .filter(i=>i && itemName(i));

    const lines=[];

    items.forEach(item=>{
        const qty=Math.max(1,Number(item.qty ?? item.quantity ?? 1)||1);
        const seat=seatOf(item);
        const prefix=seat>0 ? `👤︎${seat}` : "•";
        const qtyText=qty>1 ? ` ×${qty}` : "";
        lines.push(`${prefix} ${itemName(item)}${qtyText}`);
    });

    return {
        shown:lines.slice(0,maxLines),
        hidden:Math.max(0,lines.length-maxLines)
    };
}

function stateInfo(order){
    if(!order) return null;

    const production=freshProductionStatus(order);

    if(paymentFinished(order) || production==="SERVED"){
        return {
            cls:"ichef-order-finished",
            label:"● À RÉGLER",
            production
        };
    }

    if(production==="READY"){
        return {
            cls:"ichef-order-ready",
            label:"● PRÊT",
            production
        };
    }

    if(production==="PRODUCTION"){
        return {
            cls:"ichef-order-production",
            label:"● EN PRODUCTION",
            production
        };
    }

    return {
        cls:"ichef-order-input",
        label:"● SAISIE",
        production
    };
}

function ensureCardElements(card){
    let preview=card.querySelector(".ichef-card-order-preview");
    if(!preview){
        preview=document.createElement("div");
        preview.className="ichef-card-order-preview";

        const badges=card.querySelector(".ichef-order-badges");
        if(badges) card.insertBefore(preview,badges);
        else card.appendChild(preview);
    }

    let state=card.querySelector(".ichef-card-live-state");
    if(!state){
        state=document.createElement("div");
        state.className="ichef-card-live-state";
        card.appendChild(state);
    }

    return {preview,state};
}

function clearCard(card){
    card.classList.remove("ichef-live-order-card",...CARD_STATE_CLASSES);

    const preview=card.querySelector(".ichef-card-order-preview");
    if(preview) preview.replaceChildren();

    const state=card.querySelector(".ichef-card-live-state");
    if(state) state.remove();
}

function updateCard(card){
    const label=clean(card?.dataset?.table);
    if(!label)return;

    const order=realOrder(label);
    if(!order){
        clearCard(card);
        return;
    }

    const info=stateInfo(order);
    const {preview,state}=ensureCardElements(card);

    card.classList.add("ichef-live-order-card");
    CARD_STATE_CLASSES.forEach(c=>card.classList.toggle(c,c===info.cls));

    const compact=compactOrderLines(order,3);
    const signature=compact.shown.join("|")+"|"+compact.hidden;

    if(preview.dataset.signature!==signature){
        preview.dataset.signature=signature;
        preview.replaceChildren();

        compact.shown.forEach(txt=>{
            const line=document.createElement("div");
            line.className="ichef-card-order-line";
            line.textContent=txt;
            preview.appendChild(line);
        });

        if(compact.hidden>0){
            const more=document.createElement("div");
            more.className="ichef-card-order-more";
            more.textContent=`+${compact.hidden} autre${compact.hidden>1?"s":""}`;
            preview.appendChild(more);
        }
    }

    if(state.textContent!==info.label) state.textContent=info.label;
}

function updateAllCards(){
    document.querySelectorAll(".pro-table-card[data-table]").forEach(updateCard);
}

function ensureReadyBanner(){
    const ticket=document.querySelector("#order-drawer .ticket-view");
    if(!ticket)return null;

    let banner=document.getElementById("ichef-global-ready-banner");
    if(banner)return banner;

    banner=document.createElement("div");
    banner.id="ichef-global-ready-banner";
    banner.innerHTML=
        `<div>🔔 PRÊT À SERVIR</div>`+
        `<div id="ichef-global-ready-items"></div>`;

    const seq=document.getElementById("sequence-ready-banner");
    if(seq){
        seq.insertAdjacentElement("beforebegin",banner);
    }else{
        const list=document.getElementById("ticket-list");
        if(list) list.insertAdjacentElement("beforebegin",banner);
        else ticket.prepend(banner);
    }

    return banner;
}

function readyItemLabels(order){
    const items=(Array.isArray(order?.items)?order.items:[])
        .filter(i=>{
            if(!i)return false;
            return i.done===true ||
                   String(i.sequenceStatus||"").toUpperCase()==="READY";
        });

    return items.slice(0,6).map(item=>{
        const seat=seatOf(item);
        return `${seat>0?`👤︎${seat} `:""}${itemName(item)}`;
    });
}

function updateReadyDrawer(){
    const banner=ensureReadyBanner();
    if(!banner)return;

    const drawer=document.getElementById("order-drawer");
    if(!drawer?.classList.contains("open")){
        banner.classList.remove("show");
        return;
    }

    const label=clean(window.currentTableId);
    const order=label ? realOrder(label) : null;
    const status=freshProductionStatus(order);

    if(order && status==="READY"){
        banner.classList.add("show");

        const items=document.getElementById("ichef-global-ready-items");
        if(items){
            const labels=readyItemLabels(order);
            items.replaceChildren();

            labels.forEach(txt=>{
                const span=document.createElement("span");
                span.textContent="✓ "+txt;
                items.appendChild(span);
            });

            const total=(Array.isArray(order.items)?order.items:[]).length;
            if(total>labels.length){
                const extra=document.createElement("span");
                extra.textContent=`+${total-labels.length} autre${total-labels.length>1?"s":""}`;
                items.appendChild(extra);
            }
        }
    }else{
        banner.classList.remove("show");
        const items=document.getElementById("ichef-global-ready-items");
        if(items)items.replaceChildren();
    }
}

window.ichefRefreshCompactOrderCards=function(){
    updateAllCards();
    updateReadyDrawer();
};

/* Les données KDS/QR/PAD peuvent changer sans reconstruire la grille. */
setInterval(()=>{if(!document.hidden) window.ichefRefreshCompactOrderCards();},1400);

window.addEventListener("focus",window.ichefRefreshCompactOrderCards,{passive:true});
document.addEventListener("visibilitychange",()=>{
    if(!document.hidden)window.ichefRefreshCompactOrderCards();
});

{
  let __ichefCompactRaf=0;
  const __ichefCompactSchedule=()=>{if(__ichefCompactRaf)return;__ichefCompactRaf=requestAnimationFrame(()=>{__ichefCompactRaf=0;window.ichefRefreshCompactOrderCards();});};
  [document.getElementById('pro-table-panel'),document.getElementById('order-drawer')].filter(Boolean).forEach(root=>{
    new MutationObserver(__ichefCompactSchedule).observe(root,{childList:true,subtree:true});
  });
}

if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",()=>{
        setTimeout(window.ichefRefreshCompactOrderCards,350);
    },{once:true});
}else{
    setTimeout(window.ichefRefreshCompactOrderCards,350);
}

})();
