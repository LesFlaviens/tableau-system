(function(){
  "use strict";

  function hardCloseOrderUI(ev){
    if(ev){
      ev.preventDefault();
      ev.stopPropagation();
    }

    // First use the application's real business/navigation function.
    try{
      if(typeof window.closeOrder === 'function'){
        window.closeOrder();
      }else if(typeof closeOrder === 'function'){
        closeOrder();
      }
    }catch(err){
      console.warn('[iCHEF] closeOrder fallback', err);
    }

    // Mobile NEXUS order/ticket panels: remove only their open/active visual state.
    const selectors = [
      '#order-drawer',
      '.order-drawer',
      '#mobile-order-screen',
      '#nexus-order-screen',
      '.nexus-order-screen',
      '#mobile-ticket-screen',
      '.mobile-ticket-screen'
    ];
    selectors.forEach(sel=>{
      document.querySelectorAll(sel).forEach(el=>{
        el.classList.remove('open','active','show','visible');
      });
    });

    // If the mobile 3-panel interface exposes a first/salle page, return to it
    // through its existing navigation helpers when present.
    const helpers = ['mobileGoToSalle','goToSalle','showServiceScreen','showMobileService','mobileShowService'];
    for(const name of helpers){
      try{
        if(typeof window[name] === 'function'){
          window[name]();
          break;
        }
      }catch(_){}
    }
    return false;
  }

  function isOrderCloseButton(el){
    if(!el || !el.closest) return false;
    const btn = el.closest('button');
    if(!btn) return false;
    if(btn.id === 'control-close-btn') return false;
    const txt = (btn.textContent || '').replace(/\s+/g,' ').trim().toUpperCase();
    if(!txt.includes('FERMER')) return false;

    // Match the TABLE T4 / ticket close area, not unrelated settings modals.
    return !!btn.closest('#order-drawer, .order-drawer, #mobile-order-screen, #nexus-order-screen, .nexus-order-screen, #mobile-ticket-screen, .mobile-ticket-screen, .mobile-ticket, .order-panel, .ticket-panel');
  }

  // Capture phase: receives the touch before swipe/drag layers can swallow it.
  document.addEventListener('pointerdown', function(e){
    if(isOrderCloseButton(e.target)) hardCloseOrderUI(e);
  }, true);

  document.addEventListener('touchstart', function(e){
    if(isOrderCloseButton(e.target)) hardCloseOrderUI(e);
  }, {capture:true, passive:false});

  // Fallback for desktop mouse.
  document.addEventListener('click', function(e){
    if(isOrderCloseButton(e.target)) hardCloseOrderUI(e);
  }, true);

  window.ichefHardCloseOrderUI = hardCloseOrderUI;
})();
