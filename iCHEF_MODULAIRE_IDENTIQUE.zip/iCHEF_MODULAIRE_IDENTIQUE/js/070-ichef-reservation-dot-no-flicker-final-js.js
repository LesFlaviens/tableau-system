(function(){
'use strict';

const STATE_CLASSES=[
  'ichef-reservation-dot-reserved',
  'ichef-reservation-dot-soon',
  'ichef-reservation-dot-late',
  'ichef-reservation-dot-arrived'
];

function norm(v){
  return String(v==null?'':v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
}
function localToday(){
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function reservations(){
  try{ if(typeof reservationsData!=='undefined' && Array.isArray(reservationsData)) return reservationsData; }catch(_){}
  try{ if(Array.isArray(window.reservationsData)) return window.reservationsData; }catch(_){}
  return [];
}
function active(r){
  return !['rejected','cancelled','canceled','annule','annulee','completed','done','noshow','no show'].includes(norm(r?.status||r?.reservationStatus));
}
function tableOf(r){ return String(r?.assignedTable||r?.tableId||r?.table||'').trim(); }
function stateOf(r){
  const s=norm(r?.status||r?.reservationStatus);
  if(['arrived','arrive','seated','installed','installe'].includes(s)) return 'arrived';
  const ts=Date.parse(`${r?.date||localToday()}T${r?.time||'00:00'}`);
  if(Number.isFinite(ts)){
    const delta=ts-Date.now();
    if(delta < -15*60000) return 'late';
    if(delta <= 30*60000 && delta >= -15*60000) return 'soon';
  }
  return 'reserved';
}
function reservationFor(label){
  const day=localToday();
  const now=Date.now();
  return reservations()
    .filter(r=>{
      if(!r || !active(r) || tableOf(r)!==String(label)) return false;
      if(r.date && String(r.date)!==day) return false;
      return true;
    })
    .sort((a,b)=>{
      const ta=Date.parse(`${a.date||day}T${a.time||'00:00'}`)||0;
      const tb=Date.parse(`${b.date||day}T${b.time||'00:00'}`)||0;
      return Math.abs(ta-now)-Math.abs(tb-now);
    })[0]||null;
}
function labelOf(w){
  return String(w?.dataset?.id||w?.dataset?.table||w?.dataset?.tableId||w?.dataset?.label||'').trim();
}
function apply(w){
  const label=labelOf(w);
  if(!label) return;
  const r=reservationFor(label);
  const wanted=r ? 'ichef-reservation-dot-'+stateOf(r) : '';
  STATE_CLASSES.forEach(c=>w.classList.toggle(c,c===wanted));
}
function refresh(){
  document.querySelectorAll('#floor-plan .table-wrapper').forEach(apply);
}

/* Classes uniquement : aucun append/remove de point. */
window.ichefRefreshStableReservationDots=refresh;
setInterval(()=>{ if(!document.hidden) refresh(); },4000);
window.addEventListener('focus',refresh,{passive:true});
document.addEventListener('visibilitychange',()=>{ if(!document.hidden) refresh(); });

/* Si renderFloor reconstruit les tables, la classe est déjà posée dans le rendu principal.
   Ce MutationObserver ne fait qu'un filet de sécurité pour des tables créées ailleurs. */
const floor=document.getElementById('floor-plan');
if(floor && !floor.__ichefStableReservationClassObserver){
  let raf=0;
  const obs=new MutationObserver(()=>{
    if(raf) return;
    raf=requestAnimationFrame(()=>{ raf=0; refresh(); });
  });
  obs.observe(floor,{childList:true,subtree:false});
  floor.__ichefStableReservationClassObserver=obs;
}

setTimeout(refresh,50);
})();
