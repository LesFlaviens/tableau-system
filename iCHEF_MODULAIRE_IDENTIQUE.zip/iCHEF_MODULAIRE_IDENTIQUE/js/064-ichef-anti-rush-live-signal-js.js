(function(){
"use strict";

const SYSTEM_KEYS=/MASTER|ARCHIVE|SETTINGS|RESERVATIONS|ALERTS|CATEGORIES|STAFF_ACCESS|LOYALTY/i;
const START_RUSH_AT=35;

let lastSignature="";
let fallbackTimer=null;

function st(v){
    return String(v==null?"":v)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g,"")
        .trim()
        .toUpperCase();
}

function ts(v){
    if(v==null || v==="") return null;

    if(typeof v==="number" && Number.isFinite(v)){
        return v>0 && v<1e11 ? v*1000 : v;
    }

    const n=Number(v);
    if(String(v).trim()!=="" && Number.isFinite(n)){
        return n>0 && n<1e11 ? n*1000 : n;
    }

    const p=Date.parse(v);
    return Number.isFinite(p)?p:null;
}

function cancelled(item){
    const s=st(item?.status);
    const q=st(item?.sequenceStatus);

    return item?.cancelled===true ||
        item?.canceled===true ||
        s.includes("ANNU") ||
        s.includes("CANCEL") ||
        q.includes("ANNU") ||
        q.includes("CANCEL");
}

function served(item){
    const s=st(item?.status);
    const q=st(item?.sequenceStatus);

    return item?.served===true ||
        s==="SERVI" ||
        s==="SERVED" ||
        q==="SERVED";
}

function taken(item){
    const s=st(item?.status);

    return item?.pickedByServer===true ||
        s==="PRIS_PAR_SERVEUR" ||
        s==="PRIS PAR SERVEUR" ||
        s==="TAKEN_BY_WAITER" ||
        s==="RUNNER_TAKEN";
}

function ready(item){
    if(!item || cancelled(item) || served(item) || taken(item)) return false;

    const s=st(item.status);
    const q=st(item.sequenceStatus);

    return item.done===true ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(s) ||
        ["READY","PRET_AU_PASS","PRET AU PASS","READY_AT_PASS"].includes(q);
}

function sent(item){
    if(!item || cancelled(item) || served(item)) return false;

    const s=st(item.status);
    const q=st(item.sequenceStatus);

    if(item.isSent===true) return true;

    return [
        "PRODUCTION",
        "READY",
        "PRET_AU_PASS",
        "PRET AU PASS"
    ].includes(q) || [
        "EN_PREPARATION",
        "EN PREPARATION",
        "READY",
        "PRET_AU_PASS",
        "PRET AU PASS"
    ].includes(s);
}

function qty(item){
    return Math.max(
        1,
        Number(item?.qty ?? item?.quantity ?? 1) || 1
    );
}

function destination(item){
    const raw=st(
        item?.dest ??
        item?.destination ??
        item?.category ??
        item?.cat ??
        ""
    );

    if(
        raw.includes("BAR") ||
        raw.includes("BOISSON") ||
        raw.includes("DRINK") ||
        raw.includes("COCKTAIL") ||
        raw.includes("APERITIF") ||
        raw.includes("APERO")
    ){
        return "BAR";
    }

    return "CUISINE";
}

function itemSentAt(item,now){
    return (
        ts(item?.sentAt) ||
        ts(item?.productionStartedAt) ||
        ts(item?.startedAt) ||
        ts(item?.updatedAt) ||
        now
    );
}

function itemReadyAt(item,now){
    return (
        ts(item?.readyAt) ||
        ts(item?.productionReadyAt) ||
        ts(item?.updatedAt) ||
        now
    );
}

function getOrders(){
    try{
        if(typeof activeOrders!=="undefined" && activeOrders){
            return activeOrders;
        }
    }catch(_){}

    return {};
}

function snapshot(){
    const all=getOrders();
    const now=Date.now();

    let cuisineQty=0;
    let barQty=0;
    let passQty=0;

    let cuisineAgeBonus=0;
    let barAgeBonus=0;
    let passAgeBonus=0;

    let activeTables=0;

    for(const [tableId,order] of Object.entries(all||{})){
        if(!tableId || SYSTEM_KEYS.test(tableId)) continue;
        if(!order || typeof order!=="object") continue;

        try{
            if(
                typeof isRealServiceOrder==="function" &&
                !isRealServiceOrder(tableId,order)
            ){
                continue;
            }
        }catch(_){}

        const items=Array.isArray(order.items)
            ? order.items.filter(Boolean)
            : [];

        if(!items.length) continue;

        let tableActive=false;

        for(const item of items){
            if(cancelled(item) || served(item)) continue;

            const q=qty(item);

            if(ready(item)){
                tableActive=true;
                passQty+=q;

                const waitMin=Math.max(
                    0,
                    (now-itemReadyAt(item,now))/60000
                );

                /*
                  Le Pass devient sensible très vite :
                  dès 2 minutes d'attente, la charge monte.
                */
                passAgeBonus+=Math.max(
                    0,
                    Math.min(30,(waitMin-2)*3*q)
                );

                continue;
            }

            if(!sent(item)) continue;

            tableActive=true;

            const dest=destination(item);
            const ageMin=Math.max(
                0,
                (now-itemSentAt(item,now))/60000
            );

            if(dest==="BAR"){
                barQty+=q;
                barAgeBonus+=Math.max(
                    0,
                    Math.min(24,(ageMin-4)*2*q)
                );
            }else{
                cuisineQty+=q;
                cuisineAgeBonus+=Math.max(
                    0,
                    Math.min(24,(ageMin-8)*1.5*q)
                );
            }
        }

        if(tableActive) activeTables++;
    }

    /*
      On conserve les coefficients historiques du PAD
      (Cuisine 8 / Bar 10), mais on ne compte plus les articles servis,
      annulés ou non envoyés. Le Pass repose sur les plats réellement prêts.
    */
    const cuisine=Math.min(
        100,
        Math.round(cuisineQty*8+cuisineAgeBonus)
    );

    const bar=Math.min(
        100,
        Math.round(barQty*10+barAgeBonus)
    );

    const pass=Math.min(
        100,
        Math.round(passQty*12+passAgeBonus)
    );

    const maxLoad=Math.max(cuisine,bar,pass);

    let level=0;
    let state="CALME";

    if(maxLoad>=80){
        level=5;
        state="CRITIQUE";
    }else if(maxLoad>=70){
        level=4;
        state="ÉLEVÉ";
    }else if(maxLoad>=60){
        level=3;
        state="TENDU";
    }else if(maxLoad>=45){
        level=2;
        state="ACTIF";
    }else if(maxLoad>=START_RUSH_AT){
        level=1;
        state="VIGILANCE";
    }

    const sectors=[
        ["CUISINE",cuisine],
        ["BAR",bar],
        ["PASS",pass]
    ]
    .filter(([,load])=>load>=START_RUSH_AT)
    .sort((a,b)=>b[1]-a[1]);

    return {
        cuisine,
        bar,
        pass,
        maxLoad,
        level,
        state,
        sectors,
        activeTables
    };
}

function sectorText(snap){
    if(!snap.sectors.length){
        return "CALME";
    }

    return snap.sectors
        .map(([name,load])=>`${name} ${load}%`)
        .join(" · ");
}

function visualClass(level){
    if(level>=5) return "ichef-ar-live-critical";
    if(level>=3) return "ichef-ar-live-hot";
    if(level>=1) return "ichef-ar-live-watch";
    return "ichef-ar-live-calm";
}

function ensureMeter(btn){
    if(!btn) return null;

    let meter=btn.querySelector(".ichef-ar-button-meter");

    if(!meter){
        meter=document.createElement("span");
        meter.className="ichef-ar-button-meter";
        meter.setAttribute("aria-hidden","true");

        for(let i=0;i<6;i++){
            meter.appendChild(document.createElement("i"));
        }

        btn.appendChild(meter);
    }

    return meter;
}

function paintMeter(meter,level){
    if(!meter) return;

    /*
      6 positions = états 0 à 5.
      Comme sur la capture : au niveau 0, le premier segment vert
      représente l'état CALME actuel.
    */
    meter.querySelectorAll("i").forEach((el,idx)=>{
        el.classList.toggle("on",idx<=level);
    });
}

function clearClasses(btn){
    if(!btn) return;

    btn.classList.remove(
        "ichef-ar-live-calm",
        "ichef-ar-live-watch",
        "ichef-ar-live-hot",
        "ichef-ar-live-critical"
    );
}

function updateMainButton(snap){
    const btn=document.getElementById("btn-anti-rush-panel");
    const label=document.getElementById("anti-rush-toggle-label");

    if(!btn || !label) return;

    const panel=document.getElementById("anti-rush-server-panel");
    const open=!!panel?.classList.contains("open");

    clearClasses(btn);
    btn.classList.add(visualClass(snap.level));

    const prefix=
        snap.level===0
            ? "ANTI-RUSH"
            : snap.level>=4
                ? "🔥 ANTI-RUSH"
                : "⚠ ANTI-RUSH";

    label.innerHTML=
        `<span class="ichef-ar-live-main">${
            open ? "✕ FERMER" : `${prefix} · N${snap.level}`
        }</span>`+
        `<span class="ichef-ar-live-sector">${
            sectorText(snap)
        }</span>`;

    const meter=ensureMeter(btn);
    paintMeter(meter,snap.level);

    btn.title=
        snap.level===0
            ? "Anti-Rush : service calme"
            : `Anti-Rush ${snap.state} — ${sectorText(snap)}`;
}

function updateDrawerButton(snap){
    const btn=document.getElementById("ichef-anti-rush-drawer-btn");
    if(!btn) return;

    const panel=document.getElementById("anti-rush-server-panel");
    const open=!!panel?.classList.contains("open");

    clearClasses(btn);
    btn.classList.add(visualClass(snap.level));

    const icon=
        snap.level===0 ? "●" :
        snap.level>=4 ? "🔥" : "⚠";

    const sector=sectorText(snap);

    btn.innerHTML=
        `<span class="ichef-ar-live-dot"></span>`+
        `<span class="ichef-ar-drawer-copy">`+
            `<span class="ichef-ar-drawer-main">${
                open ? `✕ FERMER · N${snap.level}` : `${icon} ANTI-RUSH · N${snap.level}`
            }</span>`+
            `<span class="ichef-ar-drawer-sector">${sector}</span>`+
        `</span>`;

    const meter=ensureMeter(btn);
    paintMeter(meter,snap.level);

    btn.title=
        snap.level===0
            ? "Anti-Rush : service calme"
            : `Niveau ${snap.level} ${snap.state} — ${sector}`;
}

function updateWindowHeader(snap){
    /*
      Si la fenêtre est déjà ouverte, son en-tête reflète immédiatement
      le niveau local sans attendre le prochain cycle.
    */
    const levelEl=document.getElementById("ichef-ar-level");

    if(levelEl){
        levelEl.textContent=`NIVEAU ${snap.level} · ${snap.state}`;
    }

    document.querySelectorAll("#ichef-ar-meter i").forEach((el,idx)=>{
        el.classList.toggle("on",idx<=snap.level);
    });
}

function update(force=false){
    const snap=snapshot();

    /*
      Rend le niveau local disponible au moteur de la fenêtre Anti-Rush.
    */
    window.__ichefAntiRushLiveLevel=snap.level;
    window.__ichefAntiRushLiveSnapshot=snap;

    const signature=JSON.stringify([
        snap.cuisine,
        snap.bar,
        snap.pass,
        snap.level,
        snap.state,
        snap.sectors
    ]);

    if(!force && signature===lastSignature){
        return snap;
    }

    lastSignature=signature;

    updateMainButton(snap);
    updateDrawerButton(snap);
    updateWindowHeader(snap);

    return snap;
}

window.ichefUpdateAntiRushSignal=function(force=false){
    return update(force===true);
};

window.ichefGetAntiRushLiveSnapshot=function(){
    return window.__ichefAntiRushLiveSnapshot || update(true);
};

function boot(){
    update(true);

    /*
      Très léger fallback chrono :
      même si aucune commande ne change, une attente peut progressivement
      devenir un rush. 5 secondes suffit et ne réordonne aucun DOM.
    */
    if(fallbackTimer) clearInterval(fallbackTimer);

    fallbackTimer=setInterval(()=>{
        if(document.hidden) return;
        update(false);
    },5000);

    document.addEventListener("visibilitychange",()=>{
        if(!document.hidden) update(true);
    });

    /*
      Après clic ouverture/fermeture, remettre immédiatement le libellé LIVE.
    */
    document.addEventListener("click",e=>{
        if(
            e.target?.closest?.(
                "#btn-anti-rush-panel,#ichef-anti-rush-drawer-btn,#ichef-ar-close"
            )
        ){
            setTimeout(()=>update(true),60);
        }
    },true);
}

if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",boot,{once:true});
}else{
    boot();
}

})();
