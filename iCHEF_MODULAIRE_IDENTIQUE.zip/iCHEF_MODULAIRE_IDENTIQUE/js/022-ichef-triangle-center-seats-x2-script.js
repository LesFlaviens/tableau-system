(function(){
    "use strict";

    function reinforceTriangleCenter(){
        document.querySelectorAll('.table-wrapper').forEach(function(w){
            const obj = w.querySelector('.table-obj');
            if(!obj) return;

            const isTriangle =
                w.classList.contains('shape-triangle') ||
                obj.classList.contains('shape-triangle') ||
                w.dataset.shape === 'triangle' ||
                obj.dataset.shape === 'triangle';

            if(isTriangle){
                const content = obj.querySelector('.table-content');
                obj.style.setProperty('display','flex','important');
                obj.style.setProperty('align-items','center','important');
                obj.style.setProperty('justify-content','center','important');

                if(content){
                    content.style.setProperty('display','flex','important');
                    content.style.setProperty('align-items','center','important');
                    content.style.setProperty('justify-content','center','important');
                    content.style.setProperty('padding','0','important');
                    content.style.setProperty('margin','0','important');
                    content.style.setProperty('transform','none','important');
                    content.style.setProperty('text-align','center','important');
                }
            }
        });
    }

    const oldRender = window.renderFloor;
    if(typeof oldRender === 'function'){
        window.renderFloor = function(){
            const result = oldRender.apply(this, arguments);
            requestAnimationFrame(reinforceTriangleCenter);
            return result;
        };
    }

    document.addEventListener('DOMContentLoaded', reinforceTriangleCenter);
    setTimeout(reinforceTriangleCenter, 250);
    setTimeout(reinforceTriangleCenter, 900);
})();
