(function(){
    "use strict";

    function cleanup(){
        const d = document.getElementById("order-drawer");
        const p = document.getElementById("pro-table-panel");

        if(d){
            d.classList.remove("ichef-room-pane-fullscreen");
        }
        if(p){
            p.classList.remove("ichef-room-longpress-armed");
            delete p.dataset.ichefRoomLongpressV2;
        }
    }

    if(document.readyState === "loading"){
        document.addEventListener("DOMContentLoaded", cleanup, {once:true});
    }else{
        cleanup();
    }

    const d = document.getElementById("order-drawer");
    if(d){
        new MutationObserver(function(){
            if(d.classList.contains("ichef-room-pane-fullscreen")){
                d.classList.remove("ichef-room-pane-fullscreen");
            }
        }).observe(d,{attributes:true,attributeFilter:["class"]});
    }
})();
