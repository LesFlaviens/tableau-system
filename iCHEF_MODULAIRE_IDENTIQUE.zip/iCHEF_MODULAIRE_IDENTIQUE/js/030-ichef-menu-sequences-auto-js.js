(function(){
    'use strict';

    const norm = (v) => String(v ?? '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g,'')
        .replace(/[^\p{L}\p{N}]+/gu,' ')
        .replace(/\s+/g,' ')
        .trim();

    const courseLabel = (course) =>
        Number(course) === 1 ? '🥗 ENTRÉES' :
        Number(course) === 2 ? '🔥 PLATS' :
        Number(course) === 3 ? '🍰 DESSERTS' : '🍽️ SÉQUENCE';

    function inferCourseFromConfiguredMenu(name){
        const target = norm(name);
        if(!target) return 0;

        try{
            const source = (typeof unifiedMenu === 'object' && unifiedMenu) ? unifiedMenu : {};
            for(const [category, items] of Object.entries(source)){
                const cat = norm(category);
                let course =
                    /\b(entree|entrees|starter|starters)\b/.test(cat) ? 1 :
                    /\b(plat|plats|principal|principaux|main|mains)\b/.test(cat) ? 2 :
                    /\b(dessert|desserts|patisserie|patisseries)\b/.test(cat) ? 3 : 0;

                if(!course || !Array.isArray(items)) continue;

                const found = items.some(it => {
                    const candidate = typeof it === 'string'
                        ? it
                        : (it?.name ?? it?.nom ?? it?.title ?? it?.label ?? '');
                    return norm(candidate) === target;
                });
                if(found) return course;
            }
        }catch(_){}
        return 0;
    }

    function inferCourse(part){
        const t = norm(part);

        if(/\b(entree|entrees|starter|starters|hors d oeuvre|hors oeuvre)\b/.test(t) ||
           /🥗/.test(String(part))) return 1;

        if(/\b(dessert|desserts|patisserie|patisseries|glace|glaces|sorbet|sorbets)\b/.test(t) ||
           /🍰/.test(String(part))) return 3;

        if(/\b(plat|plats|principal|principaux|main course|mains)\b/.test(t) ||
           /🔥/.test(String(part))) return 2;

        return inferCourseFromConfiguredMenu(part) || 0;
    }

    /* Analyse les titres du type :
       Entrée + Plat + Dessert
       Plat + Dessert
       Entrée + Plat
       2 Entrées + 2 Plats + 2 Desserts
       3 Entrées + 3 Plats + 3 Desserts
       etc. */
    function parseFormulaFromName(menuName){
        const t = norm(menuName);
        const specs = [];

        const patterns = [
            {course:1, re:/(\d+)?\s*(?:x\s*)?\bentrees?\b/g},
            {course:2, re:/(\d+)?\s*(?:x\s*)?\bplats?\b/g},
            {course:3, re:/(\d+)?\s*(?:x\s*)?\bdesserts?\b/g}
        ];

        patterns.forEach(({course,re}) => {
            let m;
            while((m = re.exec(t))){
                specs.push({
                    course,
                    count: Math.max(1, parseInt(m[1] || '1',10) || 1),
                    index:m.index
                });
            }
        });

        specs.sort((a,b)=>a.index-b.index);

        /* Si aucune catégorie explicite n'est présente, aucune invention :
           le fallback historique E/P/D reste disponible. */
        return specs;
    }

    function createSyntheticPart(menuName, course){
        const clean = String(menuName || '').replace(/^🌟\s*/,'').trim();
        if(course === 1) return `🥗 Entrée (${clean})`;
        if(course === 2) return `🔥 Plat (${clean})`;
        return `🍰 Dessert (${clean})`;
    }

    /* Remplace proprement l'ancien ajout de menu. */
    window.addMenuToTicket = function(n, p, dest, tvaRate = 10){
        const cleanMenuName = String(n || '').replace(/^🌟\s*/,'').trim();
        const rawParts = String(n || '')
            .split('[BR]')
            .map(x=>x.replace(/^🌟\s*/,'').trim())
            .filter(Boolean);

        const explicitParts = rawParts.length > 1 ? rawParts : [];
        let components = [];

        if(explicitParts.length){
            /* Les vrais éléments d'un menu configuré sont classés automatiquement. */
            explicitParts.forEach((part, idx) => {
                let course = inferCourse(part);

                /* En dernier recours seulement, ordre restauration classique. */
                if(!course){
                    if(explicitParts.length === 2){
                        /* Si un élément est identifiable, on déduit l'autre sans
                           transformer arbitrairement Plat+Dessert en Entrée+Plat. */
                        const otherIdx = idx === 0 ? 1 : 0;
                        const otherCourse = inferCourse(explicitParts[otherIdx]);
                        if(otherCourse === 3) course = 2;
                        else if(otherCourse === 1) course = 2;
                        else course = idx + 2; // Plat puis Dessert par défaut sur formule 2 temps
                    }else{
                        course = Math.min(3, idx + 1);
                    }
                }
                components.push({name:part, course, qty:1});
            });
        }else{
            /* Menu décrit par sa formule : "2 entrées 2 plats 2 desserts", etc. */
            const formula = parseFormulaFromName(cleanMenuName);
            if(formula.length){
                formula.forEach(f => components.push({
                    name:createSyntheticPart(cleanMenuName,f.course),
                    course:f.course,
                    qty:f.count
                }));
            }else{
                /* Compatibilité : un menu sans détail reste un menu complet E/P/D. */
                components = [
                    {name:createSyntheticPart(cleanMenuName,1),course:1,qty:1},
                    {name:createSyntheticPart(cleanMenuName,2),course:2,qty:1},
                    {name:createSyntheticPart(cleanMenuName,3),course:3,qty:1}
                ];
            }
        }

        /* Regroupe les mêmes catégories/éléments et garde une séquence par type. */
        const menuId = `MENU_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
        let priceApplied = false;

        components.forEach((part) => {
            const course = Number(part.course) || 2;
            const unitPrice = priceApplied ? 0 : Number(p || 0);
            priceApplied = true;

            const beforeLen = currentTicket.length;
            executeAddToCart(part.name, unitPrice, dest, course, n, tvaRate);

            let added = [...currentTicket].reverse().find(item =>
                !item.isSent &&
                item.n === part.name &&
                Number(item.course) === course
            );

            if(added){
                if(Number(part.qty) > 1){
                    /* Si la ligne vient d'être créée, sa quantité vaut 1.
                       Pour un menu "3 entrées", on la passe directement à 3. */
                    added.qty = Math.max(Number(added.qty)||1, Number(part.qty));
                }
                added.menuId = menuId;
                added.menuName = cleanMenuName;
                added.sequence = course; /* 1=entrée, 2=plat, 3=dessert */
                added.sequenceStatus = 'DRAFT';
                added.menuCourse = course;
            }
        });

        if(typeof renderTicket === 'function') renderTicket();
        if(typeof showToast === 'function'){
            const counts = [1,2,3]
                .map(c => {
                    const q = components
                        .filter(x=>Number(x.course)===c)
                        .reduce((a,x)=>a+(Number(x.qty)||1),0);
                    return q ? `${q} ${c===1?'entrée'+(q>1?'s':''):c===2?'plat'+(q>1?'s':''):'dessert'+(q>1?'s':'')}` : '';
                })
                .filter(Boolean)
                .join(' · ');
            showToast(`🍽️ Menu détecté : ${counts}`);
        }
    };

    /* Fonction appelée par sendOrderToKDS dans le code existant.
       Elle remet toutes les métadonnées de séquence au propre avant envoi. */
    window.normalizeSequenceMetadata = function(){
        if(!Array.isArray(currentTicket)) return;

        currentTicket.forEach(item => {
            if(!item) return;

            let course = Number(item.course);
            if(![1,2,3].includes(course)){
                course = inferCourse(item.n || item.originalName || '');
                if(course) item.course = course;
            }

            if([1,2,3].includes(course)){
                item.sequence = course;
                if(!item.sequenceStatus) item.sequenceStatus = item.isSent ? 'WAITING' : 'DRAFT';
            }
        });
    };

    function sequenceEntries(){
        const map = new Map();
        (currentTicket || []).forEach((item,idx)=>{
            const seq = Number(item?.sequence || item?.course || 0);
            if(![1,2,3].includes(seq)) return;
            if(!map.has(seq)) map.set(seq,[]);
            map.get(seq).push({item,idx});
        });
        return new Map([...map.entries()].sort((a,b)=>a[0]-b[0]));
    }

    function stateOf(entries){
        const items=(entries||[]).map(x=>x.item||x);
        if(!items.length) return 'DRAFT';
        if(items.every(i=>i.served)) return 'SERVED';
        if(items.every(i=>i.done)) return 'READY';
        if(items.some(i=>String(i.sequenceStatus||'').toUpperCase()==='PRODUCTION')) return 'PRODUCTION';
        if(items.some(i=>i.isSent)) return 'WAITING';
        return 'DRAFT';
    }

    function previousSequenceServed(seq,map){
        const keys=[...map.keys()];
        const pos=keys.indexOf(Number(seq));
        if(pos<=0) return true;
        return stateOf(map.get(keys[pos-1])) === 'SERVED';
    }

    window.requestSequence = async function(seq){
        const map=sequenceEntries();
        const entries=map.get(Number(seq));
        if(!entries?.length) return;

        if(!previousSequenceServed(Number(seq),map)){
            if(typeof showToast==='function') showToast('⏸ Servez d’abord la séquence précédente');
            else alert('⏸ Servez d’abord la séquence précédente.');
            return;
        }

        entries.forEach(({item})=>{
            item.isSent=true;                // déjà connue de la cuisine
            item.done=false;
            item.served=false;
            item.sequence=Number(seq);
            item.sequenceStatus='PRODUCTION';
            item.requestedAt=Date.now();
        });

        if(typeof renderTicket==='function') renderTicket();

        try{
            await executeSaveTableState(false,true);
            if(typeof showToast==='function'){
                showToast(`🔥 ${courseLabel(seq)} réclamé${Number(seq)===1?'es':''} en cuisine`);
            }
        }catch(e){
            console.error('[iCHEF] Réclame séquence impossible',e);
        }
    };

    window.updateSequenceServicePanel = function(){
        const panel=document.getElementById('sequence-service-panel');
        const readyBanner=document.getElementById('sequence-ready-banner');
        if(!panel) return;

        const map=sequenceEntries();
        if(!map.size){
            panel.style.display='none';
            panel.innerHTML='';
            if(readyBanner){
                readyBanner.classList.remove('show');
                readyBanner.style.display='none';
                readyBanner.innerHTML='';
            }
            return;
        }

        panel.style.display='block';

        const states=[];
        let html=`<div class="ichef-seq-head">
            <span>🍽️ SERVICE PAR SÉQUENCES</span>
            <span style="color:var(--text-muted);font-size:.58rem">CUISINE INFORMÉE DE TOUTE LA COMMANDE</span>
        </div>`;

        for(const [seq,entries] of map){
            const state=stateOf(entries);
            states.push({seq,state});

            const qty=entries.reduce((a,{item})=>a+(Number(item.qty)||1),0);
            const allowed=previousSequenceServed(seq,map);

            const stateText =
                state==='PRODUCTION' ? '🔥 EN PRODUCTION' :
                state==='READY' ? '🔔 PRÊT' :
                state==='SERVED' ? '✅ SERVI' :
                state==='WAITING' ? '⏸ EN ATTENTE' : '📝 À ENVOYER';

            const stateClass =
                state==='PRODUCTION'?'production':
                state==='READY'?'ready':
                state==='SERVED'?'served':'waiting';

            let action='';
            if(state==='WAITING' || state==='DRAFT'){
                action=`<button class="ichef-seq-request"
                    onclick="requestSequence(${seq});event.stopPropagation();"
                    ${allowed?'':'disabled'}>
                    ▶ RÉCLAMER LA SUITE
                </button>`;
            }

            html+=`<div class="ichef-seq-row">
                <div class="ichef-seq-name">${courseLabel(seq)} <span style="color:var(--text-muted)">×${qty}</span></div>
                <div class="ichef-seq-state ${stateClass}">${stateText}</div>
                ${action}
            </div>`;
        }

        panel.innerHTML=html;

        const ready=states.filter(s=>s.state==='READY');
        if(readyBanner){
            if(ready.length){
                readyBanner.style.display='block';
                readyBanner.classList.add('show');
                readyBanner.innerHTML=`🔔 <strong>${ready.map(s=>courseLabel(s.seq)).join(' + ')}</strong> PRÊT${ready.length>1?'S':''} — À RÉCUPÉRER`;
            }else{
                readyBanner.classList.remove('show');
                readyBanner.style.display='none';
                readyBanner.innerHTML='';
            }
        }
    };

    /* Le marquage "servi" d'un article doit permettre de réclamer la suite.
       On garde la fonction existante et on rafraîchit le panneau juste après. */
    if(typeof window.markAsServed === 'function'){
        const originalMarkAsServed=window.markAsServed;
        window.markAsServed=async function(idx){
            await originalMarkAsServed(idx);
            if(typeof window.updateSequenceServicePanel==='function'){
                window.updateSequenceServicePanel();
            }
        };
    }

    /* Après un retour cuisine / synchro, le panneau doit refléter immédiatement PRÊT. */
    const refreshSequences=()=>{
        try{
            if(typeof window.normalizeSequenceMetadata==='function') window.normalizeSequenceMetadata();
            if(typeof window.updateSequenceServicePanel==='function') window.updateSequenceServicePanel();
        }catch(_){}
    };

    document.addEventListener('DOMContentLoaded',refreshSequences,{once:true});
    window.addEventListener('focus',refreshSequences,{passive:true});

    /* Petit rafraîchissement visuel seulement : aucun envoi réseau supplémentaire. */
    setInterval(()=>{
        const drawer=document.getElementById('order-drawer');
        if(drawer?.classList.contains('open')) refreshSequences();
    },1000);
})();
