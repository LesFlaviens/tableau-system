(function(){
    "use strict";

    async function ichefServerHealthCheck(){
        try{
            const controller = new AbortController();
            const timer = setTimeout(()=>controller.abort(),4500);

            const res = await fetch(`${APP_SERVER_URL}/get-current-state?tenantID=${encodeURIComponent(appTenantID || '')}`,{
                method:"GET",
                credentials:"include",
                cache:"no-store",
                headers:{
                    "Accept":"application/json",
                    "X-Requested-With":"iCHEF-PWA"
                },
                signal:controller.signal
            });

            clearTimeout(timer);
            window.ICHEF_SERVER_REACHABLE = res.ok;
            return res.ok;
        }catch(err){
            window.ICHEF_SERVER_REACHABLE = false;
            console.warn("[iCHEF] Serveur non joignable :",err);
            return false;
        }
    }

    window.ichefServerHealthCheck = ichefServerHealthCheck;

    window.addEventListener("online",()=>{
        setTimeout(ichefServerHealthCheck,150);
    },{passive:true});

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",()=>{
            setTimeout(ichefServerHealthCheck,350);
        },{once:true});
    }else{
        setTimeout(ichefServerHealthCheck,350);
    }
})();
