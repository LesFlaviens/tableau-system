(function(){
    "use strict";

    function pinButtonFrom(node){
        return node?.closest?.("#login-screen .pin-btn") || null;
    }

    /* On laisse le click normal du bouton fonctionner,
       mais on empêche les gardes globaux postérieurs de l'annuler. */
    document.addEventListener("pointerdown", function(e){
        const btn=pinButtonFrom(e.target);
        if(!btn) return;

        /* Rien n'est annulé : on marque seulement le geste comme prioritaire. */
        btn.dataset.ichefPinPress="1";
    }, true);

    document.addEventListener("click", function(e){
        const btn=pinButtonFrom(e.target);
        if(!btn) return;

        /* Ne pas preventDefault : l'onclick / handler existant doit s'exécuter. */
        delete btn.dataset.ichefPinPress;
    }, true);

    /* Filet de sécurité contre un pointer-events hérité ou modifié dynamiquement. */
    function restorePin(){
        document.querySelectorAll("#login-screen .pin-btn").forEach(btn=>{
            btn.style.pointerEvents="auto";
            btn.style.touchAction="manipulation";
        });
    }

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",restorePin,{once:true});
    }else{
        restorePin();
    }

    const login=document.getElementById("login-screen");
    if(login){
        new MutationObserver(()=>requestAnimationFrame(restorePin))
            .observe(login,{attributes:true,childList:true,subtree:true});
    }
})();
