(function(){
  "use strict";
  let controlSnapshot = null;

  function controlManagerAllowed(){
    return !!currentUser && currentUser.role === 'Manager';
  }

  function controlIsoDate(d){
    const x = new Date(d);
    return Number.isNaN(x.getTime()) ? null : x.toISOString();
  }

  function controlMoneySymbol(){
    const p = normalizedFiscalProfile();
    return p.country === 'CH' ? 'CHF' : '€';
  }

  window.openControlMode = async function(){
    if(!controlManagerAllowed()){
      try{ if(typeof auditEvent === 'function') await auditEvent('CONTROL_MODE_DENIED',{reason:'MANAGER_REQUIRED'},false); }catch(e){}
      return alert('⛔ Accès Manager requis');
    }
    const p = normalizedFiscalProfile();
    if(!p.country) return alert('ℹ️ Configurez d’abord le profil fiscal France ou Suisse.');
    const modal = document.getElementById('control-mode-modal');
    if(!modal) return;
    if(typeof window.ichefHardOpenControlReset === 'function') window.ichefHardOpenControlReset();
    else { modal.hidden=false; modal.style.removeProperty('display'); modal.removeAttribute('aria-hidden'); }
    modal.classList.add('open');

    const now = new Date();
    const first = new Date(now.getFullYear(),0,1);
    const from = document.getElementById('control-date-from');
    const to = document.getElementById('control-date-to');
    if(from && !from.value) from.value = first.toISOString().slice(0,10);
    if(to && !to.value) to.value = now.toISOString().slice(0,10);

    await refreshControlMode();
    try{ if(typeof auditEvent === 'function') await auditEvent('CONTROL_MODE_OPENED',{country:p.country},false); }catch(e){}
  };

  window.closeControlMode = function(){
    const modal = document.getElementById('control-mode-modal');
    if(!modal) return false;
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
    modal.style.setProperty('display','none','important');
    return false;
  };

  // Sécurisation tactile du bouton FERMER (portable/tablette)
  function bindControlClose(){
    const btn = document.getElementById('control-close-btn');
    const modal = document.getElementById('control-mode-modal');
    if(!btn || !modal || btn.dataset.closeBound === '1') return;
    btn.dataset.closeBound = '1';
    btn.style.pointerEvents = 'auto';
    btn.style.position = 'relative';
    btn.style.zIndex = '5';

    let touched = false;
    btn.addEventListener('touchend', function(e){
      touched = true;
      e.preventDefault();
      e.stopPropagation();
      window.closeControlMode();
      setTimeout(()=>{ touched = false; }, 350);
    }, {passive:false});

    btn.addEventListener('click', function(e){
      e.preventDefault();
      e.stopPropagation();
      if(!touched) window.closeControlMode();
    });

    // Clic sur le fond noir = fermeture aussi
    modal.addEventListener('click', function(e){
      if(e.target === modal) window.closeControlMode();
    });
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bindControlClose);
  }else{
    bindControlClose();
  }
  setTimeout(bindControlClose, 300);
  document.addEventListener('pointerup', function(e){
    const btn = e.target && e.target.closest ? e.target.closest('#control-close-btn') : null;
    if(!btn) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    window.closeControlMode();
  }, true);

  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape' && document.getElementById('control-mode-modal')?.classList.contains('open')){
      window.closeControlMode();
    }
  }, true);

  window.refreshControlMode = async function(){
    if(!controlManagerAllowed()) return alert('⛔ Accès Manager requis');
    const box = document.getElementById('control-summary');
    const label = document.getElementById('control-profile-label');
    const p = normalizedFiscalProfile();
    if(label) label.textContent = p.country === 'CH' ? '🇨🇭 SUISSE · CHF · dossier technique' : '🇫🇷 FRANCE · EUR € · attestation / données caisse';
    if(box) box.innerHTML = 'Chargement sécurisé des données serveur…';

    try{
      const state = await API.getState();
      const orders = state?.activeOrders || {};
      const settings = orders.SETTINGS_MASTER?.data || window.systemSettings || {};
      const keys = Object.keys(orders);
      const orderKeys = keys.filter(k => /^(order_|W|T|WEB_)/.test(k));
      const fiscalKeys = keys.filter(k => /fiscal|ticket|closure|cloture|archive|audit|payment|caisse/i.test(k));

      const from = document.getElementById('control-date-from')?.value || '';
      const to = document.getElementById('control-date-to')?.value || '';

      controlSnapshot = {
        generatedAt:new Date().toISOString(),
        tenantID:typeof appTenantID !== 'undefined' ? appTenantID : null,
        user:currentUser?.name || null,
        profile:{
          country:p.country,
          currency:p.currency,
          legalStatus:settings?.compliance?.legalStatus || 'NON_RENSEIGNE',
          profileVersion:settings?.compliance?.profileVersion || null
        },
        period:{from,to},
        serverInventory:{
          totalKeys:keys.length,
          orderLikeRecords:orderKeys.length,
          fiscalRelatedRecords:fiscalKeys.length,
          fiscalRelatedKeys:fiscalKeys.slice(0,100)
        }
      };

      if(box){
        box.innerHTML = `
          <div class="control-kv"><span>Établissement / tenant</span><strong>${controlSnapshot.tenantID || 'Non renseigné'}</strong></div>
          <div class="control-kv"><span>Profil actif</span><strong>${p.country === 'CH' ? '🇨🇭 SUISSE · CHF' : '🇫🇷 FRANCE · EUR €'}</strong></div>
          <div class="control-kv"><span>Statut déclaré</span><strong>${controlSnapshot.profile.legalStatus}</strong></div>
          <div class="control-kv"><span>Période demandée</span><strong>${from || '—'} → ${to || '—'}</strong></div>
          <div class="control-kv"><span>Enregistrements commande/table détectés</span><strong>${orderKeys.length}</strong></div>
          <div class="control-kv"><span>Enregistrements à libellé fiscal/caisse détectés</span><strong>${fiscalKeys.length}</strong></div>
          <div style="margin-top:10px;color:var(--text-muted);font-size:.7rem">
            Inventaire de contrôle uniquement : les éléments ci-dessus indiquent ce que le serveur expose actuellement. Les exports fiscaux réglementaires doivent provenir des écritures réellement enregistrées par le moteur fiscal.
          </div>`;
      }
    }catch(err){
      console.error('[iCHEF] Mode contrôle',err);
      if(box) box.innerHTML = '<strong style="color:var(--alert)">Impossible de lire les données serveur.</strong><br>Le mode contrôle ne génère aucune donnée de remplacement.';
    }
  };

  window.openControlProfileDocument = function(){
    const p = normalizedFiscalProfile();
    if(p.country === 'CH'){
      if(typeof openSwissCompliance === 'function') return openSwissCompliance();
    }else{
      if(typeof openFranceAttestation === 'function') return openFranceAttestation();
    }
    alert('Document de profil indisponible.');
  };

  window.exportControlSnapshot = async function(){
    if(!controlManagerAllowed()) return alert('⛔ Accès Manager requis');
    if(!controlSnapshot) await refreshControlMode();
    if(!controlSnapshot) return;
    const blob = new Blob([JSON.stringify(controlSnapshot,null,2)],{type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `iCHEF_controle_${controlSnapshot.profile.country}_${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),1000);
    try{ if(typeof auditEvent === 'function') await auditEvent('CONTROL_SNAPSHOT_EXPORTED',{country:controlSnapshot.profile.country,period:controlSnapshot.period},false); }catch(e){}
  };

  window.printControlSummary = async function(){
    if(!controlManagerAllowed()) return alert('⛔ Accès Manager requis');
    if(!controlSnapshot) await refreshControlMode();
    try{ if(typeof auditEvent === 'function') await auditEvent('CONTROL_SUMMARY_PRINTED',{country:controlSnapshot?.profile?.country || null},false); }catch(e){}
    window.print();
  };
})();
