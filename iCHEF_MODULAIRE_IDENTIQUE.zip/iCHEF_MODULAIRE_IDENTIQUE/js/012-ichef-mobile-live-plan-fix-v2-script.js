(function(){
  'use strict';
  const isPhone=()=>window.matchMedia('(max-width:600px)').matches;
  const $=(s,r=document)=>r.querySelector(s);
  let timer=null,startX=0,startY=0,openedAt=0;

  function getRooms(){
    try{
      if(Array.isArray(window.rooms)&&window.rooms.length) return window.rooms.filter(Boolean);
      if(typeof rooms!=='undefined'&&Array.isArray(rooms)&&rooms.length) return rooms.filter(Boolean);
    }catch(_){}
    try{
      const vals=[...new Set((typeof tables!=='undefined'&&Array.isArray(tables)?tables:[]).map(t=>t&&t.room).filter(Boolean))];
      if(vals.length) return vals;
    }catch(_){}
    return ['Salle Principale'];
  }
  function currentRoomName(){
    try{return currentRoom||getRooms()[0]||'Salle Principale';}catch(_){return getRooms()[0]||'Salle Principale';}
  }
  function ensureChrome(){
    if($('#mobile-live-plan-chrome')) return;
    const bar=document.createElement('div');bar.id='mobile-live-plan-chrome';
    bar.innerHTML='<div id="mobile-live-plan-title">🗺 PLAN</div><div id="mobile-live-plan-rooms"></div><button id="mobile-live-plan-close" type="button" aria-label="Fermer">×</button>';
    document.body.appendChild(bar);
    const help=document.createElement('div');help.id='mobile-live-plan-help';help.textContent='Glissez pour vous déplacer · Touchez une table pour l’ouvrir';document.body.appendChild(help);
    $('#mobile-live-plan-close').addEventListener('click',()=>closePlan(true));
  }
  function renderRooms(){
    const box=$('#mobile-live-plan-rooms');if(!box)return;
    const cur=currentRoomName();box.innerHTML='';
    getRooms().forEach(name=>{
      const b=document.createElement('button');b.type='button';b.textContent=String(name);
      if(String(name)===String(cur))b.classList.add('active');
      b.addEventListener('click',e=>{
        e.preventDefault();e.stopPropagation();
        try{currentRoom=name;}catch(_){}
        try{if(typeof renderRooms==='function')window.renderRooms();}catch(_){}
        try{if(typeof renderFloor==='function')renderFloor();}catch(err){console.error(err);}
        renderRooms();
        const w=$('.floor-plan-wrapper');if(w){w.scrollLeft=0;w.scrollTop=0;}
      });
      box.appendChild(b);
    });
  }
  function openPlan(){
    if(!isPhone())return;
    const wrap=$('.floor-plan-wrapper');if(!wrap)return;
    ensureChrome();
    try{if(typeof renderFloor==='function')renderFloor();}catch(err){console.error(err);}
    renderRooms();
    document.body.classList.add('mobile-live-plan-open');openedAt=Date.now();
    try{if(navigator.vibrate)navigator.vibrate(25);}catch(_){}
  }
  function closePlan(returnService){
    document.body.classList.remove('mobile-live-plan-open');
    if(returnService){
      try{if(typeof renderService==='function')renderService();}catch(_){}
    }
  }
  function cancel(){clearTimeout(timer);timer=null;}
  function install(){
    const service=$('#mobile-exact-service');if(!service||service.dataset.planLongV2==='1')return;
    service.dataset.planLongV2='1';
    service.addEventListener('pointerdown',e=>{
      if(!isPhone()||e.pointerType==='mouse'&&e.button!==0)return;
      startX=e.clientX;startY=e.clientY;cancel();
      timer=setTimeout(()=>{timer=null;openPlan();},900);
    },{passive:true});
    service.addEventListener('pointermove',e=>{
      if(!timer)return;
      if(Math.abs(e.clientX-startX)>16||Math.abs(e.clientY-startY)>16)cancel();
    },{passive:true});
    ['pointerup','pointercancel','pointerleave'].forEach(n=>service.addEventListener(n,cancel,{passive:true}));
    service.addEventListener('click',e=>{
      if(Date.now()-openedAt<700){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();}
    },true);
  }
  function bindPlanTableClose(){
    const wrap=$('.floor-plan-wrapper');if(!wrap||wrap.dataset.planCloseV2==='1')return;
    wrap.dataset.planCloseV2='1';
    wrap.addEventListener('click',e=>{
      if(!document.body.classList.contains('mobile-live-plan-open'))return;
      const table=e.target.closest('.table-wrapper,.table-obj');if(!table)return;
      setTimeout(()=>{
        const drawer=$('#order-drawer');
        if(drawer&&drawer.classList.contains('open')) closePlan(false);
      },80);
    },true);
  }
  function init(){
    ensureChrome();install();bindPlanTableClose();
    new MutationObserver(()=>{install();bindPlanTableClose();}).observe(document.body,{childList:true,subtree:true});
    window.addEventListener('resize',()=>{if(!isPhone())closePlan(false);},{passive:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
