(function(){
    "use strict";

    function killTableAnimations(){
        document.querySelectorAll(
            ".table-wrapper,.table-obj,.table-content,.chair,.zone-wrapper,.zone-obj"
        ).forEach(el=>{
            el.style.setProperty("animation","none","important");
            el.style.setProperty("transition","none","important");
        });
    }

    function boot(){
        killTableAnimations();

        const floor=document.getElementById("floor-plan");
        if(floor){
            new MutationObserver(()=>{
                requestAnimationFrame(killTableAnimations);
            }).observe(floor,{
                childList:true,
                subtree:true,
                attributes:true,
                attributeFilter:["class","style"]
            });
        }
    }

    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",boot,{once:true});
    }else{
        boot();
    }
})();
