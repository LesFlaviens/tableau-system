(function(){
  'use strict';
  const q=(s,r=document)=>r.querySelector(s);

  function fmtElapsed(ms){
    if(!ms || !Number.isFinite(ms)) return '00:00';
    const sec=Math.max(0,Math.floor((Date.now()-ms)/1000));
    const m=Math.floor(sec/60), s=sec%60;
    return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  }
  function orderStart(label){
    try{
      const o=(typeof activeOrders!=='undefined'&&activeOrders)?activeOrders[label]:null;
      if(!o) return null;

      /* Un "vrai article" doit avoir au minimum un nom/libellé.
         Les objets vides, placeholders, métadonnées ou anciennes commandes
         fantômes ne doivent jamais lancer le chrono. */
      const items=(Array.isArray(o.items)?o.items:[]).filter(i=>{
        if(!i || typeof i!=='object') return false;
        const name=String(i.n ?? i.name ?? i.label ?? i.title ?? '').trim();
        const qty=Number(i.qty ?? i.quantity ?? 1);
        return !!name && Number.isFinite(qty) && qty>0;
      });

      if(items.length===0) return null;

      if(Number.isFinite(Number(o.createdAt)) && Number(o.createdAt)>0){
        return Number(o.createdAt);
      }

      const ids=items
        .map(i=>Number(i.itemId || i.createdAt || i.addedAt || 0))
        .filter(v=>Number.isFinite(v) && v>0);

      return ids.length?Math.min(...ids):Date.now();
    }catch(_){return null;}
  }
  function tablePax(t){
    if(t && Number.isFinite(Number(t.pax))) return Number(t.pax);
    try{
      const o=activeOrders[t.label];
      const m=String(o?.observations||'').match(/🍽️\s*(\d+)/);
      return m?Number(m[1]):2;
    }catch(_){return 2;}
  }
  function isReserved(label){
    try{return activeOrders?.[label]?.status==='reserved';}catch(_){return false;}
  }
  function renderProTables(){
    const grid=q('#pro-table-grid');
    if(!grid) return;

    let list=[];
    try{
      list=(Array.isArray(tables)?tables:[])
        .filter(t=>t && (!currentRoom || t.room===currentRoom));
    }catch(_){list=[];}

    const wanted=new Set(list.map(t=>String(t.label||'')));

    /* Supprime uniquement les tables qui n'existent réellement plus.
       Aucune reconstruction globale de la grille. */
    grid.querySelectorAll('.pro-table-card').forEach(btn=>{
      if(!wanted.has(String(btn.dataset.table||''))) btn.remove();
    });

    const empty=grid.querySelector('.ichef-no-table');
    if(empty) empty.remove();

    if(!list.length){
      if(!grid.querySelector('.ichef-no-table')){
        const d=document.createElement('div');
        d.className='ichef-no-table';
        d.style.cssText='color:#888;padding:20px;grid-column:1/-1;text-align:center';
        d.textContent='Aucune table';
        grid.appendChild(d);
      }
      return;
    }

    list.forEach(t=>{
      const label=String(t.label||'');
      let btn=Array.from(grid.querySelectorAll('.pro-table-card'))
        .find(b=>String(b.dataset.table||'')===label);

      /* Création UNE SEULE FOIS. */
      if(!btn){
        btn=document.createElement('button');
        btn.type='button';
        btn.className='pro-table-card';
        btn.dataset.table=label;
        btn.innerHTML=
          '<span class="pro-table-num"></span>'+
          '<span class="pro-table-meta"></span>'+
          '<span class="pro-table-time">00:00</span>'+
          '<span class="ichef-order-badges"></span>';

        btn.addEventListener('click',()=>{
          const tableLabel=btn.dataset.table;
          if(!tableLabel) return;
          if(typeof handleTableOrderTap==='function'){
            handleTableOrderTap(tableLabel,tableLabel);
          }else if(typeof openOrder==='function'){
            openOrder(tableLabel);
          }
        });

        grid.appendChild(btn);
      }

      /* Mise à jour EN PLACE : aucun remove/recreate. */
      const rawOrd=(typeof activeOrders!=='undefined'&&activeOrders)
        ? activeOrders[label]
        : null;
      const ord=(rawOrd && (
        typeof isRealServiceOrder!=='function' ||
        isRealServiceOrder(label,rawOrd)
      )) ? rawOrd : null;

      const meta=ord?getUnifiedOrderMeta(ord,label):null;
      const labels=meta?lifecycleLabels(meta):null;

      btn.classList.toggle('current',
        typeof currentTableId!=='undefined' &&
        String(currentTableId)===label
      );
      btn.classList.toggle('reserved',isReserved(label));
      btn.classList.toggle('service-counter',meta?.serviceMode==='COMPTOIR');
      btn.classList.toggle('service-server',!!meta && meta?.serviceMode!=='COMPTOIR');

      const num=btn.querySelector('.pro-table-num');
      const pax=btn.querySelector('.pro-table-meta');
      const time=btn.querySelector('.pro-table-time');
      const badges=btn.querySelector('.ichef-order-badges');

      if(num && num.textContent!==label) num.textContent=label;

      const paxText='👥 '+tablePax(t);
      if(pax && pax.textContent!==paxText) pax.textContent=paxText;

      const start=orderStart(label);
      const elapsedMs=start?Date.now()-start:0;
      const timeText=start?fmtElapsed(start):'00:00';
      if(time && time.textContent!==timeText) time.textContent=timeText;
      if(time){
        time.classList.toggle('late',elapsedMs>60*60*1000);
        time.classList.toggle('warn',
          elapsedMs>20*60*1000 && elapsedMs<=60*60*1000
        );
      }

      if(badges){
        if(!meta){
          if(badges.childElementCount) badges.replaceChildren();
        }else{
          const payClass=meta.paymentStatus==='PAYE'
            ?'pay-paid'
            :(meta.paymentStatus==='PARTIEL'?'pay-partial':'pay-due');
          const prodClass=meta.productionStatus==='READY'
            ?'prod-ready'
            :meta.productionStatus==='PRODUCTION'
              ?'prod-production'
              :meta.productionStatus==='SERVED'
                ?'prod-served'
                :'prod-waiting';

          const signature=[
            meta.origin,labels.service,labels.pay,labels.prod,payClass,prodClass
          ].join('|');

          if(badges.dataset.signature!==signature){
            badges.dataset.signature=signature;
            badges.replaceChildren();

            const defs=[
              [meta.origin, meta.origin==='QR'?'origin-qr':'origin-pad'],
              [labels.service,''],
              [labels.pay,payClass],
              [labels.prod,prodClass]
            ];

            defs.forEach(([txt,cls])=>{
              const s=document.createElement('span');
              s.className='ichef-order-badge '+cls;
              s.textContent=txt;
              badges.appendChild(s);
            });
          }
        }
      }
    });
  }
  function renderProRooms(){
    const tabs=q('#pro-room-tabs'); if(!tabs) return;
    let list=[];try{list=Array.isArray(rooms)?rooms:[];}catch(_){list=[];}
    tabs.innerHTML=list.map(r=>`<button type="button" class="pro-room-btn ${r===currentRoom?'active':''}" data-room="${String(r).replace(/&/g,'&amp;').replace(/"/g,'&quot;')}">${String(r).replace(/</g,'&lt;')}</button>`).join('');
    tabs.querySelectorAll('.pro-room-btn').forEach(b=>b.addEventListener('click',()=>{
      try{currentRoom=b.dataset.room; if(typeof renderRooms==='function') renderRooms(); if(typeof renderFloor==='function') renderFloor();}catch(_){ }
      renderProRooms();renderProTables();
    }));
  }
  function ensureTablePanel(){
    const body=q('#order-drawer .drawer-body'); if(!body || q('#pro-table-panel')) return;
    const panel=document.createElement('aside'); panel.id='pro-table-panel';
    panel.innerHTML='<div id="pro-room-tabs"></div><div id="pro-table-grid"></div>';
    body.insertBefore(panel,body.firstChild);
    renderProRooms();renderProTables();
  }
  function ensureStatus(){
    const drawer=q('#order-drawer'); if(!drawer || q('#pro-status-bar')) return;
    const s=document.createElement('div');s.id='pro-status-bar';
    s.innerHTML='<div class="pro-stat">CUISINE <strong id="pro-rush">ACTIF</strong></div><div class="pro-stat">LIAISON <strong id="pro-link">SÉCURISÉE</strong></div><div class="pro-stat">TABLES <strong id="pro-tables">0</strong></div><div class="pro-stat">COUVERTS <strong id="pro-covers">0</strong></div><div class="pro-stat">HEURE <strong id="pro-time">--:--</strong></div>';
    drawer.appendChild(s);
  }
  function updateStatus(){
    try{
      const tt=q('#pro-tables'),cc=q('#pro-covers'),tm=q('#pro-time'),rr=q('#pro-rush');
      if(tt) tt.textContent=String((Array.isArray(tables)?tables:[]).length);
      if(cc) cc.textContent=String((Array.isArray(tables)?tables:[]).reduce((a,t)=>a+(Number(t?.pax)||0),0));
      if(tm) tm.textContent=new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
      if(rr) rr.textContent=(typeof currentRushLevel!=='undefined'&&currentRushLevel>=4)?'RUSH':'ACTIF';
    }catch(_){ }
  }
  function promoteActions(){
    const send=q('#btn-send-kds');
    if(send){send.innerHTML='👨‍🍳 ENVOYER EN CUISINE';}
    const pay=send?.nextElementSibling;
    if(pay && pay.classList.contains('pay-btn')) pay.innerHTML='🧾 CAISSE';
  }
  function updateProTableTimes(){
    const grid=q('#pro-table-grid');
    if(!grid) return;

    grid.querySelectorAll('.pro-table-card').forEach(btn=>{
      const label=btn.dataset.table;
      if(!label) return;

      const start=orderStart(label);
      const time=btn.querySelector('.pro-table-time');
      if(!time) return;

      const elapsed=start?Date.now()-start:0;
      time.textContent=start?fmtElapsed(start):'00:00';
      time.classList.toggle('late', elapsed>60*60*1000);
      time.classList.toggle('warn', elapsed>20*60*1000 && elapsed<=60*60*1000);
    });
  }

  function init(){
    ensureTablePanel();ensureStatus();promoteActions();updateStatus();renderProRooms();renderProTables();

    /* IMPORTANT :
       avant, renderProTables() détruisait/recréait toute la grille chaque seconde,
       ce qui provoquait le clignotement visuel.
       Désormais seul le texte des chronos est actualisé. */
    setInterval(()=>{
      if(q('#order-drawer.open')){
        updateProTableTimes();
        updateStatus();
        promoteActions();
      }
    },1000);

    const drawer=q('#order-drawer');
    if(drawer){
      new MutationObserver(()=>{
        if(drawer.classList.contains('open')){
          ensureTablePanel();
          ensureStatus();
          renderProRooms();
          renderProTables();
          promoteActions();
        }
      }).observe(drawer,{attributes:true,attributeFilter:['class']});
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();
