(function(){
    "use strict";

    const SENSITIVE = new Set([
        "GESTE_COMMERCIAL",
        "REFUS_PAYER",
        "DEPART_SANS_PAYER"
    ]);

    function el(id){ return document.getElementById(id); }

    function selectedReason(){
        return document.querySelector(
            'input[name="ichef-cancel-reason"]:checked'
        )?.value || "";
    }

    function resetQcm(){
        document.querySelectorAll(
            'input[name="ichef-cancel-reason"]'
        ).forEach(r => r.checked = false);

        const other = el("ichef-cancel-other");
        const error = el("ichef-cancel-error");
        const confirm = el("ichef-cancel-confirm");

        if(other){
            other.value = "";
            other.classList.remove("show");
        }
        if(error) error.textContent = "";
        if(confirm) confirm.disabled = true;
    }

    function validateQcm(){
        const reason = selectedReason();
        const other = el("ichef-cancel-other");
        const error = el("ichef-cancel-error");
        const confirm = el("ichef-cancel-confirm");

        if(!other || !confirm) return;

        const needsText = reason === "AUTRE";
        other.classList.toggle("show", needsText);

        const text = other.value.trim();
        const valid = !!reason && (!needsText || text.length >= 5);

        confirm.disabled = !valid;

        if(error){
            error.textContent =
                needsText && text.length > 0 && text.length < 5
                    ? "Le motif « Autre » doit contenir au moins 5 caractères."
                    : "";
        }
    }

    window.ichefOpenCancelQcm = function(){
        const modal = el("ichef-cancel-qcm");
        if(!modal) return;

        resetQcm();
        modal.classList.add("show");
        modal.setAttribute("aria-hidden","false");
    };

    function closeQcm(){
        const modal = el("ichef-cancel-qcm");
        if(!modal) return;
        modal.classList.remove("show");
        modal.setAttribute("aria-hidden","true");
    }

    function makeAuditRecord(reason, comment, tableId, order, ticket){
        return {
            id: "CANCEL-" + Date.now() + "-" +
                Math.random().toString(36).slice(2,8),

            type: "ANNULATION_COMMANDE",
            tenantID:
                typeof appTenantID !== "undefined"
                    ? String(appTenantID || "")
                    : "",

            tableId: String(tableId || ""),
            waiter:
                typeof currentUser !== "undefined"
                    ? currentUser?.name || null
                    : null,

            waiterId:
                typeof currentUser !== "undefined"
                    ? currentUser?.id || null
                    : null,

            deviceId: window.ICHEF_SECURITY?.deviceId || null,

            reason,
            comment: comment || null,
            sensitive: SENSITIVE.has(reason),

            createdAt: new Date().toISOString(),

            items: ticket.map(i => ({
                name: String(i?.n ?? i?.name ?? ""),
                qty: Number(i?.qty ?? 1),
                price: Number(i?.p ?? i?.price ?? 0),
                tva: Number(i?.tva ?? i?.vat ?? 0),
                sent: !!i?.isSent
            })),

            orderMeta: order?.orderMeta || null
        };
    }

    async function saveFiscalAudit(record){
        /* Copie locale de secours */
        try{
            const key = "ICHEF_FISCAL_CANCEL_AUDIT";
            const arr = JSON.parse(localStorage.getItem(key) || "[]");
            arr.push(record);
            if(arr.length > 3000){
                arr.splice(0, arr.length - 3000);
            }
            localStorage.setItem(key, JSON.stringify(arr));
        }catch(_){}

        /* Copie serveur persistante séparée de la table.
           FINANCIAL_ est volontairement conservé par le filtre central. */
        if(typeof API !== "undefined" && API?.update){
            const auditKey = "FINANCIAL_CANCEL_" + record.id;
            await API.update(
                auditKey,
                record,
                false,
                { reason: "Annulation commande" }
            );
        }
    }

    async function executeValidatedCancellation(){
        const reason = selectedReason();
        const comment = (el("ichef-cancel-other")?.value || "").trim();

        if(!reason){
            validateQcm();
            return;
        }

        if(reason === "AUTRE" && comment.length < 5){
            validateQcm();
            return;
        }

        const tableId =
            typeof currentTableId !== "undefined"
                ? String(currentTableId || "")
                : "";

        if(!tableId){
            const error = el("ichef-cancel-error");
            if(error) error.textContent = "Aucune table active à annuler.";
            return;
        }

        const order =
            typeof activeOrders !== "undefined"
                ? activeOrders?.[tableId] || {}
                : {};

        const ticket =
            typeof currentTicket !== "undefined" &&
            Array.isArray(currentTicket)
                ? JSON.parse(JSON.stringify(currentTicket))
                : [];

        const record = makeAuditRecord(
            reason,
            comment,
            tableId,
            order,
            ticket
        );

        const confirm = el("ichef-cancel-confirm");
        if(confirm){
            confirm.disabled = true;
            confirm.textContent = "ANNULATION…";
        }

        try{
            /* 1. Audit fiscal AVANT suppression */
            await saveFiscalAudit(record);

            /* 2. Suppression réelle de la commande côté serveur */
            if(typeof API !== "undefined" && API?.update){
                await API.update(tableId, null, true, {
                    reason,
                    comment,
                    auditId: record.id
                });
            }

            /* 3. Libération immédiate locale */
            if(typeof activeOrders !== "undefined" && activeOrders){
                delete activeOrders[tableId];
            }

            if(typeof currentTicket !== "undefined"){
                currentTicket = [];
            }

            if(typeof currentTableId !== "undefined"){
                currentTableId = null;
            }

            closeQcm();

            try{
                if(typeof closeOrder === "function") closeOrder();
            }catch(_){}

            try{
                if(typeof renderFloor === "function") renderFloor();
            }catch(_){}

            try{
                if(typeof renderProTables === "function") renderProTables();
            }catch(_){}

            try{
                if(typeof renderService === "function") renderService();
            }catch(_){}

            try{
                if(typeof forceServerSync === "function"){
                    setTimeout(
                        () => forceServerSync("cancel-order-final"),
                        250
                    );
                }
            }catch(_){}

            try{
                if(typeof showToast === "function"){
                    showToast("🗑️ Commande annulée — table libérée");
                }
            }catch(_){}

        }catch(err){
            console.error("[iCHEF] Annulation impossible :", err);

            const error = el("ichef-cancel-error");
            if(error){
                error.textContent =
                    "Impossible d'enregistrer l'annulation. Réessayez.";
            }

        }finally{
            if(confirm){
                confirm.textContent = "VALIDER L'ANNULATION";
                validateQcm();
            }
        }
    }

    function boot(){
        const close = el("ichef-cancel-close");
        const confirm = el("ichef-cancel-confirm");
        const other = el("ichef-cancel-other");

        if(close){
            close.onclick = closeQcm;
        }

        if(confirm){
            confirm.onclick = executeValidatedCancellation;
        }

        if(other){
            other.oninput = validateQcm;
        }

        document.querySelectorAll(
            'input[name="ichef-cancel-reason"]'
        ).forEach(r => {
            r.onchange = validateQcm;
        });
    }

    if(document.readyState === "loading"){
        document.addEventListener(
            "DOMContentLoaded",
            boot,
            { once:true }
        );
    }else{
        boot();
    }
})();
