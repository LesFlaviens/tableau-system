(function(){

    window.updateReservationQuickBadge = function(){
        const badge = document.getElementById('reservation-count-badge');
        if(!badge || typeof reservationsData === 'undefined') return;

        const today = new Date().toISOString().split('T')[0];
        const todayReservations = (Array.isArray(reservationsData) ? reservationsData : [])
            .filter(r => r && r.date === today && r.status !== 'rejected');

        badge.textContent = String(todayReservations.length);

        const btn = document.getElementById('btn-reservations-quick');
        if(btn){
            const waiting = todayReservations.filter(r => !r.assignedTable).length;
            btn.title = `${todayReservations.length} réservation(s) aujourd'hui · ${waiting} à placer`;
            btn.classList.toggle('has-waiting-reservations', waiting > 0);
        }
    };

    window.smartPlacementAssistant = async function(){
        if (!currentUser || currentUser.role !== 'Manager') {
            return alert("⛔ Accès Manager requis pour le placement automatique.");
        }

        const today = new Date().toISOString().split('T')[0];
        const pending = (Array.isArray(reservationsData) ? reservationsData : [])
            .filter(r => r && r.date === today && r.status === 'confirmed' && !r.assignedTable);

        if(!pending.length){
            return alert("✅ Toutes les réservations confirmées d'aujourd'hui sont déjà placées.");
        }

        const state = await API.getState();
        const orders = state?.activeOrders || {};

        const suggestions = [];
        const reservedLabels = new Set();

        for(const resa of pending){
            const pax = parseInt(resa.couverts || resa.pax || resa.personnes) || 1;

            const candidates = tables
                .filter(t => {
                    if(!t || t.isExtra) return false;
                    if(reservedLabels.has(t.label)) return false;

                    const order = orders[t.label];
                    const occupied = order &&
                        (order.status === 'reserved' ||
                         (Array.isArray(order.items) && order.items.length > 0));

                    return !occupied && (parseInt(t.pax) || 0) >= pax;
                })
                .sort((a,b) => {
                    // Priorité à la table qui gaspille le moins de places.
                    const wasteA = (parseInt(a.pax)||0) - pax;
                    const wasteB = (parseInt(b.pax)||0) - pax;
                    if(wasteA !== wasteB) return wasteA - wasteB;

                    // Ensuite favoriser la salle actuellement affichée.
                    const aCurrent = a.room === currentRoom ? 0 : 1;
                    const bCurrent = b.room === currentRoom ? 0 : 1;
                    return aCurrent - bCurrent;
                });

            if(candidates.length){
                const best = candidates[0];
                reservedLabels.add(best.label);
                suggestions.push({
                    reservation: resa,
                    table: best,
                    pax
                });
            }
        }

        if(!suggestions.length){
            return alert("⚠️ Aucune table disponible ne correspond aux réservations en attente.");
        }

        const preview = suggestions.map(s => {
            const phone = s.reservation.phone ? ` · ${s.reservation.phone}` : '';
            return `${s.reservation.time || '??:??'} — ${s.reservation.name || 'Client'}${phone}\n`
                 + `${s.pax} pers. → ${s.table.label} (${s.table.pax} places, ${s.table.room || 'Salle'})`;
        }).join('\n\n');

        const ok = confirm(
            `🧠 AIDE INTELLIGENTE AU PLACEMENT\n\n`
            + `${preview}\n\n`
            + `Valider ces propositions ?`
        );

        if(!ok) return;

        // Réutilise la fonction existante et sûre d'auto-placement.
        await autoAssignToday();
        updateReservationQuickBadge();
    };

    // Le compteur suit les données de réservation chargées par syncData.
    setInterval(()=>{if(!document.hidden) updateReservationQuickBadge();}, 3000);

    if(document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', updateReservationQuickBadge);
    } else {
        updateReservationQuickBadge();
    }
})();
