function toggleOutilsMenuFinal(event, button) {
    if (typeof toggleOutilsMenu === 'function') {
        return toggleOutilsMenu(event, button);
    }
    const panel = document.getElementById('folder-outils');
    if (!panel) return;
    panel.classList.toggle('open');
}
