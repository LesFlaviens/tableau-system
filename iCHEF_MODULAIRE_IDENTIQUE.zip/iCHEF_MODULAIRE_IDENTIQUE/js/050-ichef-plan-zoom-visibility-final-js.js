(function(){
"use strict";
function isShown(el){
  if(!el) return false;
  const cs=getComputedStyle(el);
  if(cs.display==='none'||cs.visibility==='hidden'||Number(cs.opacity)===0) return false;
  const r=el.getBoundingClientRect();
  return r.width>2&&r.height>2;
}
function updatePlanZoomVisibility(){
  const plan=document.getElementById('floor-plan')||document.querySelector('.floor-plan');
  const wrapper=plan?.closest('.floor-plan-wrapper')||plan?.parentElement;
  const login=document.getElementById('login-screen');
  const openModal=[...document.querySelectorAll('.modal.open')].some(isShown);
  const openDrawer=[...document.querySelectorAll('.drawer.open')].some(isShown);
  const planVisible=isShown(plan)&&isShown(wrapper)&&!isShown(login)&&!openModal&&!openDrawer;
  document.body?.classList.toggle('ichef-floor-plan-visible',!!planVisible);
}
window.ichefUpdatePlanZoomVisibility=updatePlanZoomVisibility;
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',updatePlanZoomVisibility,{once:true});
else updatePlanZoomVisibility();
{
  let __ichefZoomVisRaf=0;
  const __ichefZoomVisSchedule=()=>{
    if(__ichefZoomVisRaf) return;
    __ichefZoomVisRaf=requestAnimationFrame(()=>{__ichefZoomVisRaf=0;updatePlanZoomVisibility();});
  };
  document.querySelectorAll('.modal,.drawer,#login-screen,.floor-plan-wrapper,#floor-plan').forEach(el=>{
    try{new MutationObserver(__ichefZoomVisSchedule).observe(el,{attributes:true,attributeFilter:['class','style','hidden']});}catch(_){ }
  });
}
document.addEventListener('click',()=>setTimeout(updatePlanZoomVisibility,0),true);
window.addEventListener('resize',updatePlanZoomVisibility,{passive:true});
})();
