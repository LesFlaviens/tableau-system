(function(){
  function placeSeats(){
    document.querySelectorAll('.table-wrapper').forEach(function(w){
      const obj=w.querySelector('.table-obj');
      if(!obj) return;
      const chairs=Array.from(w.querySelectorAll('.chair'));
      if(!chairs.length) return;

      const shape=(w.dataset.shape || obj.dataset.shape || '').toLowerCase();
      const isTriangle=shape==='triangle' ||
        w.classList.contains('shape-triangle') ||
        obj.classList.contains('shape-triangle');

      if(isTriangle && chairs.length>=4){
        /* 1 sommet, 2 droite au milieu, 3 bas, 4 gauche au milieu */
        const pos=[
          ['50%','-18px','translate(-50%,-50%)'],
          ['calc(100% + 18px)','50%','translate(-50%,-50%)'],
          ['50%','calc(100% + 18px)','translate(-50%,-50%)'],
          ['-18px','50%','translate(-50%,-50%)']
        ];
        chairs.slice(0,4).forEach(function(c,i){
          c.style.setProperty('left',pos[i][0],'important');
          c.style.setProperty('top',pos[i][1],'important');
          c.style.setProperty('right','auto','important');
          c.style.setProperty('bottom','auto','important');
          c.style.setProperty('transform',pos[i][2],'important');
        });
      }
    });
  }

  const previousRender=window.renderFloor;
  if(typeof previousRender==='function'){
    window.renderFloor=function(){
      const r=previousRender.apply(this,arguments);
      requestAnimationFrame(placeSeats);
      return r;
    };
  }
  document.addEventListener('DOMContentLoaded',placeSeats);
  setTimeout(placeSeats,250);
  setTimeout(placeSeats,900);
})();
