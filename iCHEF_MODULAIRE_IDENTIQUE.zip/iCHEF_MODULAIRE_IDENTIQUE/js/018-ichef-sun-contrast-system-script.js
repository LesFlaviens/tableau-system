(function(){
    "use strict";
    const KEY='ichef_display_contrast_mode_v1';
    let preference='auto';
    let sensor=null;
    let lux=null;

    function safeGet(){
        try{return localStorage.getItem(KEY)||'auto';}catch(e){return 'auto';}
    }
    function safeSet(v){
        try{localStorage.setItem(KEY,v);}catch(e){}
    }
    function hourSuggestsSun(){
        const h=new Date().getHours();
        return h>=8 && h<19;
    }
    function systemSuggestsHighContrast(){
        try{return !!window.matchMedia && (
            window.matchMedia('(prefers-contrast: more)').matches ||
            window.matchMedia('(forced-colors: active)').matches
        );}catch(e){return false;}
    }
    function autoWantsSun(){
        // Si un capteur compatible est disponible, il est prioritaire.
        if(typeof lux==='number') return lux >= 12000;
        // Fallback prudent : ne force le mode fort que si le système demande
        // davantage de contraste. L'heure seule ne suffit pas à décider.
        return systemSuggestsHighContrast();
    }
    function apply(on, reason){
        document.documentElement.classList.toggle('ichef-sun-mode', !!on);
        const auto=document.getElementById('sun-auto-btn');
        const man=document.getElementById('sun-manual-btn');
        const normal=document.getElementById('sun-normal-btn');
        const status=document.getElementById('ichef-sun-status');
        if(auto) auto.classList.toggle('active', preference==='auto');
        if(man) man.classList.toggle('active', preference==='sun');
        if(normal) normal.classList.toggle('active', preference==='normal');
        if(status){
            const luxTxt = typeof lux === 'number' ? Math.round(lux) + ' lux' : (on ? 'ÉLEVÉE' : 'NORMALE');
            status.innerHTML = `☀ Luminosité : <strong>${luxTxt}</strong> → Mode <strong>${on ? 'ANTI-SOLEIL' : 'NORMAL'}</strong>`;
            status.title = reason || '';
        }
    }
    function refresh(){
        if(preference==='sun') return apply(true,'Mode manuel anti-soleil');
        if(preference==='normal') return apply(false,'Mode manuel normal');
        apply(autoWantsSun(), typeof lux==='number' ? Math.round(lux)+' lux' : 'AUTO système');
    }

    window.iChefSetSunPreference=function(v){
        if(!['auto','sun','normal'].includes(v)) v='auto';
        preference=v; safeSet(v); refresh();
    };
    window.iChefToggleManualSun=function(){
        // ☀️ alterne anti-soleil forcé / normal forcé.
        preference = document.documentElement.classList.contains('ichef-sun-mode') ? 'normal' : 'sun';
        safeSet(preference); refresh();
    };

    function tryAmbientSensor(){
        // AmbientLightSensor n'est pas disponible sur tous les navigateurs/appareils.
        try{
            if(!('AmbientLightSensor' in window)) return;
            sensor=new AmbientLightSensor({frequency:1});
            sensor.addEventListener('reading',()=>{
                lux=sensor.illuminance;
                if(preference==='auto') refresh();
            });
            sensor.addEventListener('error',()=>{lux=null; if(preference==='auto') refresh();});
            sensor.start();
        }catch(e){lux=null;}
    }

    preference=safeGet();
    refresh();
    tryAmbientSensor();

    if(window.matchMedia){
        try{
            const mq=window.matchMedia('(prefers-contrast: more)');
            mq.addEventListener?.('change',()=>{if(preference==='auto')refresh();});
        }catch(e){}
    }
    setInterval(()=>{if(preference==='auto' && lux===null)refresh();},60000);
})();
