(function(){
'use strict';
if(window.__ICHEF_DEVICE_KEYBOARD_DICTATION__) return;
window.__ICHEF_DEVICE_KEYBOARD_DICTATION__=true;

const SpeechAPI=window.SpeechRecognition||window.webkitSpeechRecognition||null;
let recognition=null;
let voiceAuto=false;
let voiceTarget=null;
let voiceButton=null;
let voiceBase='';
let voiceRestartTimer=0;

function tableModal(){return document.getElementById('table-config-modal')}
function zoneModal(){return document.getElementById('zone-config-modal')}
function backing(){return document.getElementById('config-table-name-display')}
function nativeInput(){return document.getElementById('ichef-table-name-native-input')}
function sanitize(v,max=30){
    return String(v??'')
        .replace(/[\r\n\t]+/g,' ')
        .replace(/\s{2,}/g,' ')
        .trimStart()
        .toUpperCase()
        .slice(0,max);
}
function setTableValue(v,keepCaret=true){
    v=sanitize(v,30);
    const d=backing();
    const i=nativeInput();
    if(d && d.textContent!==v) d.textContent=v;
    if(i && i.value!==v){
        const pos=keepCaret?i.selectionStart:null;
        i.value=v;
        if(keepCaret && document.activeElement===i){
            const p=Math.min(v.length,Number.isFinite(pos)?pos:v.length);
            try{i.setSelectionRange(p,p)}catch(_){ }
        }
    }
    try{currentTactileName=v}catch(_){ }
    try{window.currentTactileName=v}catch(_){ }
    return v;
}
function syncFromBacking(){
    const d=backing();
    if(!d)return;
    let v=String(d.textContent||'');
    if(v==='—')v='';
    setTableValue(v,false);
}
function status(root,msg){
    const n=root?.querySelector?.('.ichef-input-mode-status');
    if(n)n.textContent=msg||'';
}
function isTouchLike(){
    try{return matchMedia('(hover:none), (pointer:coarse)').matches}catch(_){return false}
}
function showNativeKeyboard(){
    const modal=tableModal();
    const i=nativeInput();
    if(!modal||!i)return;
    modal.classList.add('ichef-native-input-active');
    status(modal,'Clavier de l’appareil actif · PC / téléphone / tablette');
    i.focus({preventScroll:true});
    try{i.setSelectionRange(i.value.length,i.value.length)}catch(_){ }
}
function showIchefKeyboard(){
    const modal=tableModal();
    if(!modal)return;
    modal.classList.remove('ichef-native-input-active');
    nativeInput()?.blur();
    status(modal,'Clavier tactile iCHEF actif · le clavier physique reste disponible');
    setTimeout(()=>document.getElementById('ichef-config-table-azerty-v2')?.scrollIntoView({block:'nearest'}),0);
}
function ensureTableControls(){
    const modal=tableModal();
    const d=backing();
    if(!modal||!d)return;
    d.classList.add('ichef-native-backing');
    d.setAttribute('aria-hidden','true');
    d.removeAttribute('contenteditable');

    let wrap=document.getElementById('ichef-table-native-input-wrap');
    if(!wrap){
        wrap=document.createElement('div');
        wrap.id='ichef-table-native-input-wrap';
        wrap.innerHTML='<input id="ichef-table-name-native-input" type="text" maxlength="30" autocomplete="off" autocorrect="off" autocapitalize="characters" spellcheck="false" inputmode="text" enterkeyhint="done" aria-label="Nom de la table" placeholder="Nom de la table"><button type="button" id="ichef-table-name-native-clear">EFFACER</button>';
        const originalRow=d.parentElement;
        if(originalRow) originalRow.parentElement.insertBefore(wrap,originalRow);
    }
    const originalRow=d.parentElement;
    if(originalRow) originalRow.style.display='none';

    let tools=document.getElementById('ichef-device-input-tools');
    if(!tools){
        tools=document.createElement('div');
        tools.id='ichef-device-input-tools';
        tools.innerHTML='<button type="button" data-mode="device">⌨ APPAREIL</button><button type="button" data-mode="ichef">⌨ iCHEF</button><button type="button" data-mode="voice">🎙 DICTÉE AUTO</button><div class="ichef-input-mode-status" aria-live="polite"></div>';
        wrap.insertAdjacentElement('afterend',tools);
    }
    const i=nativeInput();
    if(i && i.dataset.bound!=='1'){
        i.dataset.bound='1';
        i.addEventListener('input',()=>setTableValue(i.value,true));
        i.addEventListener('keydown',e=>{
            if(e.key==='Enter'){e.preventDefault();i.blur();}
            if(e.key==='Escape'){e.preventDefault();i.blur();}
        });
        i.addEventListener('focus',()=>{
            if(isTouchLike()) modal.classList.add('ichef-native-input-active');
            status(modal,'Saisie appareil active · utilisez aussi le micro du clavier si disponible');
        });
    }
    const clear=document.getElementById('ichef-table-name-native-clear');
    if(clear && clear.dataset.bound!=='1'){
        clear.dataset.bound='1';
        clear.addEventListener('click',()=>{setTableValue('',false);nativeInput()?.focus();});
    }
    if(tools.dataset.bound!=='1'){
        tools.dataset.bound='1';
        tools.addEventListener('click',e=>{
            const b=e.target.closest('button[data-mode]');if(!b)return;
            e.preventDefault();e.stopPropagation();
            if(b.dataset.mode==='device')showNativeKeyboard();
            else if(b.dataset.mode==='ichef')showIchefKeyboard();
            else if(b.dataset.mode==='voice')toggleVoice(nativeInput(),b,tableModal());
        });
    }
    syncFromBacking();
    if(!status(modal,'')){}
}

function ensureZoneControls(){
    const modal=zoneModal();
    const input=document.getElementById('config-zone-name');
    if(!modal||!input)return;
    input.setAttribute('autocomplete','off');
    input.setAttribute('autocorrect','off');
    input.setAttribute('autocapitalize','sentences');
    input.setAttribute('spellcheck','false');
    input.setAttribute('inputmode','text');
    input.setAttribute('enterkeyhint','done');
    if(input.dataset.deviceBound!=='1'){
        input.dataset.deviceBound='1';
        input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();input.blur();}});
    }
    let tools=modal.querySelector('.ichef-zone-device-tools');
    if(!tools){
        tools=document.createElement('div');
        tools.className='ichef-zone-device-tools';
        tools.innerHTML='<button type="button" data-zone-device>⌨ CLAVIER APPAREIL</button><button type="button" data-zone-voice>🎙 DICTÉE AUTO</button><div class="ichef-input-mode-status" aria-live="polite"></div>';
        input.insertAdjacentElement('afterend',tools);
        tools.addEventListener('click',e=>{
            const dev=e.target.closest('button[data-zone-device]');
            const voice=e.target.closest('button[data-zone-voice]');
            if(dev){e.preventDefault();input.focus();return;}
            if(voice){e.preventDefault();toggleVoice(input,voice,modal);}
        });
    }
}

function stopVoice(reason=''){
    voiceAuto=false;
    clearTimeout(voiceRestartTimer);
    voiceRestartTimer=0;
    if(recognition){
        try{recognition.onend=null;recognition.stop()}catch(_){ }
        try{recognition.abort()}catch(_){ }
    }
    recognition=null;
    if(voiceButton){voiceButton.classList.remove('voice-listening','active');voiceButton.textContent='🎙 DICTÉE AUTO';}
    if(voiceTarget){
        const root=voiceTarget.closest?.('.modal');
        if(root)status(root,reason||'Dictée arrêtée');
    }
    voiceTarget=null;voiceButton=null;voiceBase='';
}
function applyVoiceText(target,text){
    const v=sanitize(text,target===nativeInput()?30:40);
    if(target===nativeInput())setTableValue(v,false);
    else if(target){target.value=v;target.dispatchEvent(new Event('input',{bubbles:true}));}
}
function startVoice(target,button,root){
    if(!target)return;
    if(!SpeechAPI){
        if(target===nativeInput())showNativeKeyboard(); else target.focus();
        status(root,'Reconnaissance vocale navigateur indisponible · utilisez 🎙 du clavier de votre appareil');
        return;
    }
    stopVoice('');
    voiceAuto=true;voiceTarget=target;voiceButton=button;voiceBase='';
    button.classList.add('voice-listening','active');
    button.textContent='⏹ ARRÊTER DICTÉE';
    status(root,'🎙 Écoute… parlez maintenant');

    function launch(){
        if(!voiceAuto||!voiceTarget)return;
        recognition=new SpeechAPI();
        recognition.lang=(navigator.language&&navigator.language.toLowerCase().startsWith('fr'))?navigator.language:'fr-FR';
        recognition.interimResults=true;
        recognition.continuous=false;
        recognition.maxAlternatives=1;
        recognition.onresult=function(ev){
            let text='';
            for(let i=0;i<ev.results.length;i++) text+=ev.results[i][0]?.transcript||'';
            if(text)applyVoiceText(voiceTarget,text);
            status(root,'🎙 '+sanitize(text||'Écoute…',60));
        };
        recognition.onerror=function(ev){
            const code=String(ev.error||'');
            if(code==='not-allowed'||code==='service-not-allowed'){
                status(root,'Micro refusé · autorisez le micro ou utilisez le micro du clavier');
                stopVoice('Micro non autorisé');
            }else if(code!=='no-speech'&&code!=='aborted'){
                status(root,'Dictée indisponible : '+code);
            }
        };
        recognition.onend=function(){
            recognition=null;
            if(voiceAuto && root && getComputedStyle(root).display!=='none'){
                voiceRestartTimer=setTimeout(launch,300);
            }else if(voiceAuto){stopVoice('Dictée arrêtée');}
        };
        try{recognition.start()}catch(err){
            status(root,'Impossible de démarrer la dictée');
            stopVoice('Dictée arrêtée');
        }
    }
    launch();
}
function toggleVoice(target,button,root){
    if(voiceAuto && voiceTarget===target){stopVoice('Dictée arrêtée');return;}
    startVoice(target,button,root);
}

function observeBacking(){
    const d=backing();if(!d||d.dataset.nativeObserver==='1')return;
    d.dataset.nativeObserver='1';
    new MutationObserver(()=>syncFromBacking()).observe(d,{childList:true,characterData:true,subtree:true});
}
function init(){
    ensureTableControls();
    ensureZoneControls();
    observeBacking();
}

const oldOpenTable=window.openTableConfigModal;
if(typeof oldOpenTable==='function'){
    window.openTableConfigModal=function(){
        const r=oldOpenTable.apply(this,arguments);
        requestAnimationFrame(()=>{init();syncFromBacking();tableModal()?.classList.remove('ichef-native-input-active');status(tableModal(),'Touchez le champ pour le clavier téléphone/tablette, ou utilisez le clavier PC');});
        return r;
    };
}
const oldCloseTable=window.closeTableConfigModal;
if(typeof oldCloseTable==='function'){
    window.closeTableConfigModal=function(){stopVoice('');return oldCloseTable.apply(this,arguments)};
}
const oldOpenZone=window.openZoneConfigModal;
if(typeof oldOpenZone==='function'){
    window.openZoneConfigModal=function(){const r=oldOpenZone.apply(this,arguments);requestAnimationFrame(init);return r;};
}
const oldCloseZone=window.closeZoneConfigModal;
if(typeof oldCloseZone==='function'){
    window.closeZoneConfigModal=function(){stopVoice('');return oldCloseZone.apply(this,arguments)};
}

document.addEventListener('visibilitychange',()=>{if(document.hidden&&voiceAuto)stopVoice('Dictée arrêtée');});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
setTimeout(init,300);
})();
