(function(){
  'use strict';
  let socket = null;
  let lastServerSyncAt = 0;
  let syncBusy = false;

  function setLinkStatus(label, ok){
    const el = document.getElementById('pro-link');
    if(!el) return;
    el.textContent = label;
    el.style.color = ok ? '#57e565' : '#f0b84f';
  }

  async function forceServerSync(reason){
    if(syncBusy || typeof syncData !== 'function' || document.hidden) return;
    syncBusy = true;
    try{
      await syncData();
      lastServerSyncAt = Date.now();
      setLinkStatus(socket && socket.connected ? 'TEMPS RÉEL' : 'SYNCHRO OK', true);
    }catch(err){
      console.warn('[iCHEF] Synchronisation serveur impossible', reason, err);
      setLinkStatus('HORS LIGNE', false);
    }finally{
      syncBusy = false;
    }
  }

  function connectRealtime(){
    if(typeof io !== 'function' || !APP_SERVER_URL || !appTenantID) {
      setLinkStatus('SYNCHRO 3s', true);
      return;
    }
    try{
      socket = io(APP_SERVER_URL, {
        withCredentials: true,
        transports: ['websocket','polling'],
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 5000,
        auth: {
          tenantID: appTenantID,
          deviceId: window.ICHEF_SECURITY?.deviceId || null
        }
      });

      socket.on('connect', function(){
        setLinkStatus('TEMPS RÉEL', true);

        /* Rejoint explicitement le réseau temps réel du restaurant. */
        socket.emit('joinTenant', {
          tenantID: appTenantID,
          deviceId: window.ICHEF_SECURITY?.deviceId || null,
          page: 'PAD_SERVEUR'
        });

        forceServerSync('socket-connect');
      });

      /* Mise à jour légère et instantanée d'une seule commande. */
      socket.on('orderLifecycle', function(evt){
        try{
          if(!evt || String(evt.tenantID||'').toLowerCase() !== String(appTenantID||'').toLowerCase()) return;
          const tableId=String(evt.tableId||'');
          if(!tableId) return;

          if(evt.deleted){
            delete activeOrders[tableId];
          }else if(evt.order){
            if(
                typeof isRealServiceOrder === 'function' &&
                !isRealServiceOrder(tableId, evt.order)
            ){
                delete activeOrders[tableId];
            }else{
                activeOrders[tableId]=evt.order;
            }
          }

          if(typeof renderFloor==='function') renderFloor();
          if(typeof renderProTables==='function') renderProTables();
          if(typeof renderService==='function') renderService();
          if(typeof updateSequenceServicePanel==='function' && String(currentTableId)===tableId){
            updateSequenceServicePanel();
          }
          if(typeof window.ichefRefreshCompactOrderCards==='function'){
            window.ichefRefreshCompactOrderCards();
          }
          if(typeof window.ichefRefreshReadyNeon==='function'){
            window.ichefRefreshReadyNeon();
          }
          if(typeof window.ichefUpdateAntiRushSignal==='function'){
            window.ichefUpdateAntiRushSignal();
          }
        }catch(err){
          console.warn('[iCHEF] orderLifecycle:',err);
        }
      });

      /* Compatibilité avec les écrans existants qui reçoivent l'état complet. */
      socket.on('updateState', function(state){
        try{
          if(state && state.activeOrders){
            activeOrders = (typeof sanitizeServerOrders === 'function')
                ? sanitizeServerOrders(state.activeOrders)
                : state.activeOrders;
            if(typeof renderFloor==='function') renderFloor();
            if(typeof renderProTables==='function') renderProTables();
            if(typeof renderService==='function') renderService();
            if(typeof window.ichefUpdateAntiRushSignal==='function'){
                window.ichefUpdateAntiRushSignal();
            }
          }
        }catch(err){
          console.warn('[iCHEF] updateState:',err);
        }
      });
      socket.on('disconnect', function(){
        setLinkStatus('SYNCHRO 3s', true);
      });
      socket.on('connect_error', function(){
        setLinkStatus('SYNCHRO 3s', true);
      });
    }catch(err){
      console.warn('[iCHEF] Socket facultatif indisponible, polling conservé', err);
      setLinkStatus('SYNCHRO 3s', true);
    }
  }

  // Reprise immédiate après retour réseau / retour sur l'application.
  window.addEventListener('online', function(){ forceServerSync('online'); });
  window.addEventListener('offline', function(){ setLinkStatus('HORS LIGNE', false); });
  document.addEventListener('visibilitychange', function(){
    if(!document.hidden) forceServerSync('visible');
  });
  window.addEventListener('focus', function(){ forceServerSync('focus'); });

  // Garde-fou : si le polling principal a été interrompu, relance une lecture ponctuelle.
  setInterval(function(){
    if(document.hidden || !navigator.onLine) return;
    if(!lastServerSyncAt || Date.now() - lastServerSyncAt > 7000) forceServerSync('watchdog');
  }, 5000);

  function init(){
    setLinkStatus(navigator.onLine ? 'CONNEXION…' : 'HORS LIGNE', navigator.onLine);
    connectRealtime();
    forceServerSync('initial');
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
