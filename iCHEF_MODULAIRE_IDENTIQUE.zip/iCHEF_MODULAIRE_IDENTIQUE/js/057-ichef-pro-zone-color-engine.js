(function(){
"use strict";

function zcNorm(v){ return String(v==null?"":v).trim(); }

function zcHexToRgba(hex,alpha){
    let h=zcNorm(hex).replace('#','');
    if(!/^[0-9a-fA-F]{6}$/.test(h)) return 'rgba(255,255,255,0.025)';
    const r=parseInt(h.slice(0,2),16);
    const g=parseInt(h.slice(2,4),16);
    const b=parseInt(h.slice(4,6),16);
    return `rgba(${r},${g},${b},${alpha})`;
}

function zcTable(label){
    try{
        return (Array.isArray(tables)?tables:[]).find(t=>t && zcNorm(t.label)===zcNorm(label)) || null;
    }catch(_){ return null; }
}

function zcZoneForTable(table){
    if(!table) return null;
    try{
        const list=Array.isArray(zones)?zones:[];
        const cx=(Number(table.l)||0)+(Number(table.w)||80)/2;
        const cy=(Number(table.t)||0)+(Number(table.h)||120)/2;
        const room=zcNorm(table.room || currentRoom);

        return list.find(z=>{
            if(!z) return false;
            if(zcNorm(z.room)!==room) return false;
            const l=Number(z.l)||0;
            const top=Number(z.t)||0;
            const w=Number(z.w)||400;
            const h=Number(z.h)||300;
            return cx>=l && cx<=l+w && cy>=top && cy<=top+h;
        }) || null;
    }catch(_){ return null; }
}

function zcEnsureBadge(card){
    let badge=card.querySelector(':scope > .pro-table-zone-badge');
    if(!badge){
        badge=document.createElement('span');
        badge.className='pro-table-zone-badge';
        const badges=card.querySelector('.ichef-order-badges');
        if(badges) card.insertBefore(badge,badges);
        else card.appendChild(badge);
    }
    return badge;
}

function zcApplyCard(card){
    const label=zcNorm(card?.dataset?.table);
    if(!label) return;

    const table=zcTable(label);
    const zone=zcZoneForTable(table);
    const color=zcNorm(zone?.color) || '#64748b';
    const zoneLabel=zcNorm(zone?.label || zone?.name) || 'HORS ZONE';

    card.style.setProperty('--ichef-zone-color',color);
    card.style.setProperty('--ichef-zone-soft',zcHexToRgba(color,.12));
    card.dataset.zoneId=zcNorm(zone?.id);
    card.dataset.zoneLabel=zoneLabel;

    const badge=zcEnsureBadge(card);
    if(badge.textContent!==zoneLabel) badge.textContent=zoneLabel;
    badge.style.display=zone ? 'inline-flex' : 'none';
}

function zcRefresh(){
    /* STRICTEMENT bloc gauche */
    document.querySelectorAll('#pro-table-panel .pro-table-card[data-table]').forEach(zcApplyCard);
}

window.ichefRefreshProZoneColors=zcRefresh;

/* Mise à jour automatique : déplacement de table, changement de couleur,
   changement de salle ou synchronisation serveur. */
setInterval(()=>{if(!document.hidden && !document.body.classList.contains('edit-mode')) zcRefresh();},2500);
window.addEventListener('focus',zcRefresh);
document.addEventListener('visibilitychange',()=>{ if(!document.hidden) zcRefresh(); });

{
  const __ichefZoneRoot=document.getElementById('pro-table-panel');
  if(__ichefZoneRoot){let raf=0;new MutationObserver(()=>{if(raf)return;raf=requestAnimationFrame(()=>{raf=0;zcRefresh();});}).observe(__ichefZoneRoot,{childList:true,subtree:true});}
}

if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',()=>setTimeout(zcRefresh,400),{once:true});
}else{
    setTimeout(zcRefresh,400);
}

})();
