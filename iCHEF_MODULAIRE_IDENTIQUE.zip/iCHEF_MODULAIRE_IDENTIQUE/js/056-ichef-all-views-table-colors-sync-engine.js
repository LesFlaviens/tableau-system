(function(){
"use strict";

function norm(v){ return String(v == null ? "" : v).trim(); }

function todayKey(){
    const d=new Date();
    return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}

function reservationList(){
    try{
        if(Array.isArray(window.reservationsData)) return window.reservationsData;
    }catch(_){}
    try{
        const r=window.activeOrders?.RESERVATIONS_MASTER;
        if(Array.isArray(r?.data)) return r.data;
    }catch(_){}
    return [];
}

function reservationIsActive(r){
    const s=norm(r?.status || r?.reservationStatus).toLowerCase();
    return ![
        "rejected","cancelled","canceled","annule","annulee",
        "completed","done","noshow","no show"
    ].includes(s);
}

function reservedLabels(){
    const day=todayKey();
    const set=new Set();

    reservationList().forEach(r=>{
        if(!r || !reservationIsActive(r)) return;

        /* Les réservations sans date restent tolérées pour compatibilité,
           mais une date différente d'aujourd'hui ne colore pas le service actuel. */
        if(r.date && String(r.date)!==day) return;

        const label=norm(r.assignedTable || r.tableId || r.table);
        if(label) set.add(label);
    });

    return set;
}

function hasRealItems(order){
    const items=Array.isArray(order?.items) ? order.items : [];
    return items.some(i=>{
        if(!i || typeof i!=="object") return false;
        const name=norm(i.n ?? i.name ?? i.label ?? i.title ?? i.productName);
        const qty=Number(i.qty ?? i.quantity ?? 1);
        return !!name && Number.isFinite(qty) && qty>0;
    });
}

function isOccupied(label){
    let order=null;
    try{ order=window.activeOrders?.[label] || null; }catch(_){}

    if(!order) return false;

    /* Utilise d'abord le filtre anti-fantôme déjà présent dans iCHEF. */
    try{
        if(typeof window.isRealServiceOrder==="function"){
            return !!window.isRealServiceOrder(label,order);
        }
    }catch(_){}

    return hasRealItems(order);
}

function setCardState(el,label,reserved){
    const occupied=isOccupied(label);

    el.classList.toggle("ichef-occupied-live",occupied);
    el.classList.toggle("ichef-reserved-live",reserved && !occupied);

    /* On neutralise l'ancienne classe reserved basée sur une fausse commande. */
    if(!reserved) el.classList.remove("reserved");
}

function syncCards(){
    const reserved=reservedLabels();

    document.querySelectorAll(".pro-table-card[data-table]").forEach(card=>{
        const label=norm(card.dataset.table);
        if(label) setCardState(card,label,reserved.has(label));
    });

    document.querySelectorAll(".mobile-exact-table[data-table]").forEach(card=>{
        const label=norm(card.dataset.table);
        if(label) setCardState(card,label,reserved.has(label));
    });
}

function syncFloor(){
    const reserved=reservedLabels();

    document.querySelectorAll(".floor-plan .table-wrapper").forEach(w=>{
        const label=norm(
            w.dataset.id ||
            w.dataset.table ||
            w.dataset.tableId ||
            w.dataset.label
        );

        if(!label) return;

        const occupied=isOccupied(label);

        w.classList.toggle("ichef-live-occupied",occupied);
        w.classList.toggle("ichef-live-reserved",reserved.has(label) && !occupied);
    });
}

window.ichefSyncAllTableColors=function(){
    syncCards();
    syncFloor();
};

/* État serveur/socket ou DOM : actualisation rapide sans recréer les cartes. */
setInterval(()=>{if(!document.hidden && !document.body.classList.contains('edit-mode')) window.ichefSyncAllTableColors();},2200);

window.addEventListener("focus",window.ichefSyncAllTableColors);
document.addEventListener("visibilitychange",()=>{
    if(!document.hidden) window.ichefSyncAllTableColors();
});

if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",()=>{
        setTimeout(window.ichefSyncAllTableColors,400);
    },{once:true});
}else{
    setTimeout(window.ichefSyncAllTableColors,400);
}

/* Les vues sont créées dynamiquement : dès qu'une carte/table apparaît,
   on lui applique immédiatement la bonne couleur. */
{
  let __ichefColorRaf=0;
  const __ichefColorSchedule=()=>{if(__ichefColorRaf)return;__ichefColorRaf=requestAnimationFrame(()=>{__ichefColorRaf=0;window.ichefSyncAllTableColors();});};
  [document.getElementById('pro-table-panel'),document.getElementById('floor-plan')].filter(Boolean).forEach(root=>{
    new MutationObserver(__ichefColorSchedule).observe(root,{childList:true,subtree:true});
  });
}

})();
