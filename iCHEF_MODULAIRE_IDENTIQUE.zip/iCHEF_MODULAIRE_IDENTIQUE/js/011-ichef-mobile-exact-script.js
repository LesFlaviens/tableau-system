(function(){
  'use strict';
  const mq=()=>window.matchMedia('(max-width:600px)').matches;
  const $=(s,r=document)=>r.querySelector(s);

  function safeRooms(){try{return Array.isArray(rooms)&&rooms.length?rooms.filter(Boolean):['Salle Principale'];}catch(_){return ['Salle Principale'];}}
  function safeTables(){try{return Array.isArray(tables)?tables.filter(Boolean):[];}catch(_){return [];}}
  function orderOf(label){try{return activeOrders?.[label]||null;}catch(_){return null;}}
  function paxOf(t){
    const n=Number(t?.pax); if(Number.isFinite(n)&&n>0)return n;
    const m=String(orderOf(t?.label)?.observations||'').match(/🍽️\s*(\d+)/);return m?Number(m[1]):2;
  }
  function startOf(label){
    const o=orderOf(label);
    if(!o) return null;

    const items=(Array.isArray(o.items)?o.items:[]).filter(i=>{
      if(!i || typeof i!=='object') return false;
      const name=String(i.n ?? i.name ?? i.label ?? i.title ?? '').trim();
      const qty=Number(i.qty ?? i.quantity ?? 1);
      return !!name && Number.isFinite(qty) && qty>0;
    });

    /* Même règle que la vue ordinateur :
       aucune ligne de commande réelle = chrono impérativement à 00:00. */
    if(items.length===0) return null;

    if(Number.isFinite(Number(o.createdAt)) && Number(o.createdAt)>0){
      return Number(o.createdAt);
    }

    const vals=items
      .map(i=>Number(i?.itemId || i?.createdAt || i?.addedAt || 0))
      .filter(v=>Number.isFinite(v)&&v>0);

    return vals.length?Math.min(...vals):Date.now();
  }
  function elapsed(start){
    if(!start)return '00:00';const s=Math.max(0,Math.floor((Date.now()-start)/1000));
    const m=Math.floor(s/60),ss=s%60;return String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0');
  }
  function esc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}

  function ensureStatus(){
    if(!mq())return;
    let el=$('#mobile-exact-status');
    if(!el){el=document.createElement('div');el.id='mobile-exact-status';document.body.appendChild(el);}
    el.innerHTML='<div class="mes">CUISINE <strong id="mx-kitchen">ACTIF</strong></div><div class="mes">LIAISON <strong id="mx-link">SÉCURISÉE</strong></div><div class="mes">TABLES <strong id="mx-tables">0</strong></div><div class="mes">COUVERTS <strong id="mx-covers">0</strong></div><div class="mes">HEURE <strong id="mx-time">--:--</strong></div>';
  }
  function updateStatus(){
    if(!mq())return;
    const ts=safeTables();
    const t=$('#mx-tables'),c=$('#mx-covers'),h=$('#mx-time'),k=$('#mx-kitchen'),l=$('#mx-link');
    if(t)t.textContent=ts.length;
    if(c)c.textContent=ts.reduce((a,x)=>a+paxOf(x),0);
    if(h)h.textContent=new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
    if(k){let rush=false;try{rush=Number(currentRushLevel)>=4;}catch(_){}k.textContent=rush?'RUSH':'ACTIF';}
    if(l){l.textContent=navigator.onLine?'SÉCURISÉE':'HORS LIGNE';l.style.color=navigator.onLine?'#45ee5b':'#ffb13b';}
  }

  function ensureService(){
    if(!mq())return;
    let el=$('#mobile-exact-service');
    if(!el){
      el=document.createElement('section');el.id='mobile-exact-service';
      el.innerHTML='<button id="mobile-exact-room" type="button"></button><div id="mobile-exact-grid"></div>';
      document.body.appendChild(el);
      $('#mobile-exact-room').addEventListener('click',()=>{
        const rs=safeRooms();let idx=Math.max(0,rs.indexOf(typeof currentRoom!=='undefined'?currentRoom:rs[0]));
        idx=(idx+1)%rs.length;try{currentRoom=rs[idx];if(typeof renderRooms==='function')renderRooms();if(typeof renderFloor==='function')renderFloor();}catch(_){}
        renderService();
      });
    }
  }
  function renderService(){
    if(!mq()) return;
    ensureService();

    const room=(typeof currentRoom!=='undefined'&&currentRoom)
      ||safeRooms()[0]||'Salle Principale';

    const rb=$('#mobile-exact-room');
    if(rb && rb.textContent!==room) rb.textContent=room;

    const g=$('#mobile-exact-grid');
    if(!g) return;

    const list=safeTables().filter(t=>!room||!t.room||t.room===room);
    const wanted=new Set(list.map(t=>String(t.label||'')));

    g.querySelectorAll('.mobile-exact-table').forEach(btn=>{
      if(!wanted.has(String(btn.dataset.table||''))) btn.remove();
    });

    const empty=g.querySelector('.ichef-no-table');
    if(empty) empty.remove();

    if(!list.length){
      const d=document.createElement('div');
      d.className='ichef-no-table';
      d.style.cssText='grid-column:1/-1;color:#8e8e8e;text-align:center;padding:35px 10px';
      d.textContent='Aucune table';
      g.appendChild(d);
      return;
    }

    list.forEach(t=>{
      const label=String(t.label||'');
      let btn=Array.from(g.querySelectorAll('.mobile-exact-table'))
        .find(b=>String(b.dataset.table||'')===label);

      if(!btn){
        btn=document.createElement('button');
        btn.type='button';
        btn.className='mobile-exact-table';
        btn.dataset.table=label;
        btn.innerHTML=
          '<span class="num"></span>'+
          '<span class="pax"></span>'+
          '<span class="time">00:00</span>'+
          '<span class="ichef-order-badges"></span>';

        btn.addEventListener('click',()=>{
          const lab=btn.dataset.table;
          if(!lab) return;
          try{
            if(typeof handleTableOrderTap==='function'){
              handleTableOrderTap(lab,lab);
            }else if(typeof openOrder==='function'){
              openOrder(lab);
            }
          }catch(e){console.error(e)}
          setTimeout(()=>{
            const d=$('#order-drawer');
            if(d)d.classList.remove('order-ticket-focus');
          },20);
        });

        g.appendChild(btn);
      }

      const rawOrd=(typeof activeOrders!=='undefined'&&activeOrders)
        ?activeOrders[label]
        :null;
      const ord=(rawOrd && (
        typeof isRealServiceOrder!=='function' ||
        isRealServiceOrder(label,rawOrd)
      )) ? rawOrd : null;

      const meta=ord?getUnifiedOrderMeta(ord,label):null;
      const labels=meta?lifecycleLabels(meta):null;

      let selected=false;
      try{
        selected=typeof currentTableId!=='undefined' &&
          String(currentTableId)===label;
      }catch(_){}

      btn.classList.toggle('current',selected);
      btn.classList.toggle('service-counter',meta?.serviceMode==='COMPTOIR');
      btn.classList.toggle('service-server',!!meta && meta?.serviceMode!=='COMPTOIR');

      const num=btn.querySelector('.num');
      const pax=btn.querySelector('.pax');
      const time=btn.querySelector('.time');
      const badges=btn.querySelector('.ichef-order-badges');

      if(num && num.textContent!==label) num.textContent=label;

      const paxText='👥 '+paxOf(t);
      if(pax && pax.textContent!==paxText) pax.textContent=paxText;

      const st=startOf(label);
      const ms=st?Date.now()-st:0;
      const timeText=elapsed(st);
      if(time && time.textContent!==timeText) time.textContent=timeText;
      if(time){
        time.classList.toggle('late',ms>3600000);
        time.classList.toggle('warn',ms>1200000 && ms<=3600000);
      }

      if(badges){
        if(!meta){
          if(badges.childElementCount) badges.replaceChildren();
        }else{
          const payClass=meta.paymentStatus==='PAYE'
            ?'pay-paid'
            :(meta.paymentStatus==='PARTIEL'?'pay-partial':'pay-due');
          const prodClass=meta.productionStatus==='READY'
            ?'prod-ready'
            :meta.productionStatus==='PRODUCTION'
              ?'prod-production'
              :meta.productionStatus==='SERVED'
                ?'prod-served'
                :'prod-waiting';

          const signature=[
            meta.origin,labels.service,labels.pay,labels.prod,payClass,prodClass
          ].join('|');

          if(badges.dataset.signature!==signature){
            badges.dataset.signature=signature;
            badges.replaceChildren();

            [
              [meta.origin,meta.origin==='QR'?'origin-qr':'origin-pad'],
              [labels.service,''],
              [labels.pay,payClass],
              [labels.prod,prodClass]
            ].forEach(([txt,cls])=>{
              const s=document.createElement('span');
              s.className='ichef-order-badge '+cls;
              s.textContent=txt;
              badges.appendChild(s);
            });
          }
        }
      }
    });
  }

  function installSwipe(){
    const drawer=$('#order-drawer');if(!drawer||drawer.dataset.mxSwipe==='1')return;drawer.dataset.mxSwipe='1';
    let x0=null,y0=null;
    drawer.addEventListener('touchstart',e=>{if(!mq()||!drawer.classList.contains('open')||!e.touches[0])return;x0=e.touches[0].clientX;y0=e.touches[0].clientY;},{passive:true});
    drawer.addEventListener('touchend',e=>{
      if(!mq()||x0===null||!e.changedTouches[0])return;
      const dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;x0=y0=null;
      if(Math.abs(dx)<65||Math.abs(dx)<Math.abs(dy)*1.4)return;
      if(dx<0&&!drawer.classList.contains('order-ticket-focus')){drawer.classList.add('order-ticket-focus');try{if(typeof updateOrderMiniBar==='function')updateOrderMiniBar();}catch(_){} }
      else if(dx>0&&drawer.classList.contains('order-ticket-focus')){drawer.classList.remove('order-ticket-focus');try{if(typeof updateOrderMiniBar==='function')updateOrderMiniBar();}catch(_){} }
    },{passive:true});
  }

  function mobileCloseHook(){
    const drawer=$('#order-drawer');if(!drawer||drawer.dataset.mxClose==='1')return;drawer.dataset.mxClose='1';
    new MutationObserver(()=>{
      if(!mq())return;
      if(!drawer.classList.contains('open')){drawer.classList.remove('order-ticket-focus');renderService();}
    }).observe(drawer,{attributes:true,attributeFilter:['class']});
  }

  function updateMobileTableTimes(){
    if(!mq()) return;
    const g=$('#mobile-exact-grid');
    if(!g) return;

    g.querySelectorAll('.mobile-exact-table').forEach(btn=>{
      const label=btn.dataset.table;
      if(!label) return;

      const st=startOf(label);
      const time=btn.querySelector('.time');
      if(!time) return;

      const ms=st?Date.now()-st:0;
      time.textContent=elapsed(st);
      time.classList.toggle('late', ms>3600000);
      time.classList.toggle('warn', ms>1200000 && ms<=3600000);
    });
  }

  function init(){
    if(!mq())return;
    ensureStatus();ensureService();renderService();updateStatus();installSwipe();mobileCloseHook();

    /* Même correction sur mobile :
       ne jamais reconstruire toutes les cartes pour un simple chrono. */
    setInterval(()=>{
      if(mq()){
        updateStatus();
        updateMobileTableTimes();
      }
    },1000);

    window.addEventListener('online',updateStatus);
    window.addEventListener('offline',updateStatus);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
