(function(){
  "use strict";
  const launcher=document.getElementById('ichef-light-launcher');
  const menu=document.getElementById('ichef-light-menu');
  const state=document.getElementById('ichef-light-state');
  if(!launcher || !menu) return;

  function currentMode(){
    let saved='auto';
    try{saved=localStorage.getItem('ichef_display_contrast_mode_v1')||'auto';}catch(e){}
    return saved;
  }

  function render(){
    const mode=currentMode();
    menu.querySelectorAll('button[data-light-mode]').forEach(btn=>{
      btn.classList.toggle('active',btn.dataset.lightMode===mode);
    });
    launcher.classList.toggle('active',mode==='sun' || mode==='night');
    if(state){
      const labels={auto:'AUTO',sun:'ANTI-SOLEIL',normal:'NORMAL',night:'NUIT'};
      state.textContent='Mode : '+(labels[mode]||mode.toUpperCase());
    }
  }

  function closeMenu(){menu.classList.remove('open');}
  function toggleMenu(){
    menu.classList.toggle('open');
    render();
  }

  launcher.addEventListener('click',function(e){
    e.preventDefault(); e.stopPropagation(); toggleMenu();
  });

  menu.addEventListener('click',function(e){
    const btn=e.target.closest('button[data-light-mode]');
    if(!btn) return;
    e.preventDefault(); e.stopPropagation();
    const mode=btn.dataset.lightMode;
    if(typeof window.iChefSetSunPreference==='function'){
      window.iChefSetSunPreference(mode);
    }
    try{localStorage.setItem('ichef_display_contrast_mode_v1',mode);}catch(err){}
    render();
    setTimeout(closeMenu,120);
  });

  document.addEventListener('click',function(e){
    if(!e.target.closest('#ichef-light-compact')) closeMenu();
  });

  document.addEventListener('keydown',function(e){
    if(e.key==='Escape') closeMenu();
  });

  render();
})();
